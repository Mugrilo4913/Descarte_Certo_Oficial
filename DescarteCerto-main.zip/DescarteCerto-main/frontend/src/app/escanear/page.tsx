// Arquivo: src/app/escanear/page.tsx
"use client";

import { useState, useRef, useCallback } from "react";
import { Camera, Loader2, RefreshCcw, CheckCircle2, ImagePlus, Leaf, Info } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

interface ResumoDescarte {
  nome: string;
  categoria: string;
  instrucoes: string;
}

export default function PaginaEscanear() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [resultado, setResultado] = useState<ResumoDescarte | null>(null);
  const [erro, setErro] = useState<string | null>(null);

  const resetAll = useCallback(() => {
    setResultado(null);
    setErro(null);
    setImagePreview(null);
    setIsCameraOpen(false);
  }, []);

  const stopCamera = useCallback(() => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      const tracks = stream.getTracks();
      tracks.forEach((track) => track.stop());
    }
    setIsCameraOpen(false);
  }, []);

  const startCamera = async () => {
    resetAll();
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" }
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      setIsCameraOpen(true);
    } catch (err) {
      console.error("Erro ao acessar a câmera:", err);
      setErro("Permissão da câmera negada ou dispositivo não encontrado.");
    }
  };

  const processImage = async (base64Image: string) => {
    setIsScanning(true);
    setErro(null);
    stopCamera();

    try {
      const response = await fetch("/api/escanear", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ image: base64Image }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Erro na API");
      }

      setResultado(data);
    } catch (err: any) {
      setErro(err.message || "Ocorreu um erro ao identificar o objeto. Tente novamente.");
    } finally {
      setIsScanning(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    resetAll();
    const reader = new FileReader();

    reader.onload = async (event) => {
      const base64Image = event.target?.result as string;
      if (base64Image) {
        setImagePreview(base64Image);
        await processImage(base64Image);
      }
    };

    reader.readAsDataURL(file);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const captureAndScan = async () => {
    if (!videoRef.current || !canvasRef.current) return;

    const video = videoRef.current;
    const canvas = canvasRef.current;
    const context = canvas.getContext("2d");

    const MAX_WIDTH = 800;
    let width = video.videoWidth;
    let height = video.videoHeight;

    if (width > MAX_WIDTH) {
      height = Math.round((height * MAX_WIDTH) / width);
      width = MAX_WIDTH;
    }

    canvas.width = width;
    canvas.height = height;

    context?.drawImage(video, 0, 0, width, height);

    const imageDataUrl = canvas.toDataURL("image/jpeg", 0.5);

    setImagePreview(imageDataUrl);
    await processImage(imageDataUrl);
  };

  return (
    <div className="flex flex-col gap-10 max-w-[1100px] w-full pb-12 pt-6 px-4 mx-auto">
      <section className="space-y-3 text-center md:text-left">
        <h1 className="text-4xl md:text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-[#0F172A] to-[#18C982] tracking-tight pb-1">
          Escanear resíduo
        </h1>
        <p className="text-[#64748B] text-lg max-w-2xl">
         Envie uma foto para descobrir rapidamente a forma correta de separar e descartar.
        </p>
      </section>

      <section className="grid grid-cols-1 lg:grid-cols-2 gap-8 min-h-[500px]">
        {/* PAINEL ESQUERDO: CÂMERA / PREVIEW */}
        <Card className="bg-[#0B1120] border border-slate-800/50 rounded-[32px] overflow-hidden flex flex-col p-4 shadow-2xl shadow-[#18C982]/10 relative group transition-all duration-300">
          <div className="flex-1 rounded-[24px] overflow-hidden flex flex-col items-center justify-center relative w-full h-full min-h-[350px] bg-[#151E2E]">

            <input
              type="file"
              accept="image/*"
              className="hidden"
              ref={fileInputRef}
              onChange={handleFileUpload}
            />

            {/* Tela Inicial */}
            {!isCameraOpen && !isScanning && !resultado && !imagePreview && (
              <div className="border-2 border-dashed border-slate-600/40 hover:border-[#18C982]/50 transition-colors duration-300 rounded-[24px] w-full h-full flex flex-col items-center justify-center p-6 md:p-10">
                <div className="w-20 h-20 bg-slate-800/50 rounded-full flex items-center justify-center mb-6 shadow-inner">
                  <Camera size={36} className="text-[#18C982]" />
                </div>
                <p className="text-slate-300 text-center text-base mb-10 max-w-xs">
                  Escolha uma imagem da sua galeria.
                </p>

                <div className="flex flex-col sm:flex-row gap-4 w-full justify-center max-w-md">
                  {/* <Button
                    onClick={startCamera}
                    className="bg-[#18C982] hover:bg-[#14ad6f] text-white font-bold rounded-xl px-6 py-6 w-full sm:flex-1 shadow-lg shadow-[#18C982]/20 transition-all hover:-translate-y-1"
                  >
                    <Camera size={20} className="mr-2" />
                    Câmera
                  </Button> */}

                  <Button
                    onClick={() => fileInputRef.current?.click()}
                    variant="outline"
                    className="bg-slate-800/80 border-slate-700 hover:bg-slate-700 hover:border-slate-600 text-white font-bold rounded-xl px-6 py-6 w-full sm:flex-1 transition-all hover:-translate-y-1"
                  >
                    <ImagePlus size={20} className="mr-2" />
                    Galeria
                  </Button>
                </div>
              </div>
            )}

            {/* Vídeo / Câmera Ativa */}
            <video
              ref={videoRef}
              autoPlay
              playsInline
              className={`w-full h-full object-cover rounded-[24px] ${isCameraOpen ? 'block' : 'hidden'}`}
            />

            {/* Imagem capturada */}
            {imagePreview && !isCameraOpen && (
              <img
                src={imagePreview}
                alt="Preview do Resíduo"
                className="w-full h-full object-cover rounded-[24px]"
              />
            )}

            <canvas ref={canvasRef} className="hidden" />

            {/* Botão de Capturar */}
            {isCameraOpen && (
              <div className="absolute bottom-6 left-0 right-0 flex justify-center pb-4">
                <button
                  onClick={captureAndScan}
                  disabled={isScanning}
                  className="bg-[#18C982] hover:bg-[#14ad6f] text-white rounded-full w-20 h-20 flex items-center justify-center shadow-2xl ring-4 ring-white/20 hover:ring-white/40 transition-all duration-300 transform active:scale-95"
                >
                  <ScanFocusIcon />
                </button>
              </div>
            )}

            {/* Tela de Carregamento */}
            {isScanning && (
              <div className="absolute inset-0 bg-[#0B1120]/80 backdrop-blur-md flex flex-col items-center justify-center rounded-[24px] z-10 text-white">
                <div className="relative mb-6">
                  <div className="absolute inset-0 border-4 border-[#18C982]/20 rounded-full animate-ping" />
                  <div className="bg-[#18C982]/10 p-4 rounded-full">
                    <Loader2 size={40} className="animate-spin text-[#18C982]" />
                  </div>
                </div>
                <p className="font-medium text-lg tracking-wide">Analisando resíduo...</p>
                <p className="text-slate-400 text-sm mt-2">Nossa IA está identificando o material</p>
              </div>
            )}
          </div>
        </Card>

        {/* PAINEL DIREITO: RESULTADO */}
        <Card className="bg-white border border-slate-100 rounded-[32px] overflow-hidden flex flex-col p-8 md:p-10 shadow-xl shadow-slate-200/50 transition-all duration-500">
          {!resultado && !erro && (
            <div className="flex-1 flex flex-col items-center justify-center text-center space-y-6 opacity-70">
              <div className="w-24 h-24 bg-slate-50 rounded-full flex items-center justify-center border-2 border-slate-100 border-dashed">
                <Leaf size={40} className="text-slate-300" strokeWidth={1.5} />
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-bold text-slate-800">Aguardando identificação</h3>
                <p className="text-slate-500 text-base max-w-xs mx-auto">
                  Escaneie um item ao lado para ver as instruções de descarte.
                </p>
              </div>
            </div>
          )}

          {erro && (
            <div className="flex-1 flex flex-col items-center justify-center text-center text-red-500 space-y-6 animate-in fade-in">
              <div className="w-20 h-20 bg-red-50 rounded-full flex items-center justify-center">
                <Info size={32} className="text-red-500" />
              </div>
              <div className="space-y-2">
                <h3 className="text-lg font-bold">Não foi possível identificar</h3>
                <p className="text-red-400 text-sm max-w-xs mx-auto">{erro}</p>
              </div>
              <Button variant="outline" onClick={resetAll} className="mt-4 rounded-xl">
                Tentar novamente
              </Button>
            </div>
          )}

          {resultado && (
            <div className="flex-1 flex flex-col h-full animate-in fade-in slide-in-from-bottom-4 duration-700">
              <div className="bg-[#18C982]/10 text-[#14ad6f] w-fit px-4 py-1.5 rounded-full text-sm font-bold mb-6 flex items-center gap-2">
                <CheckCircle2 size={18} /> Identificado com Sucesso
              </div>

              <h2 className="text-3xl md:text-4xl font-extrabold text-slate-900 mb-3 tracking-tight">
                {resultado.nome}
              </h2>

              <div className="mb-8">
                <span className="inline-flex items-center gap-2 bg-slate-50 text-slate-600 px-4 py-2 rounded-xl text-sm font-semibold border border-slate-200">
                  <Leaf size={16} className="text-[#18C982]" />
                  Categoria: {resultado.categoria}
                </span>
              </div>

              {/* Box de Instruções Estilizado */}
              <div className="bg-gradient-to-br from-[#F8FAFC] to-[#F1F5F9] p-6 rounded-2xl border-l-4 border-l-[#18C982] shadow-sm flex-1">
                <h3 className="font-bold text-slate-800 mb-3 text-sm uppercase tracking-wider flex items-center gap-2">
                  <Info size={16} className="text-[#18C982]" />
                  Como descartar:
                </h3>
                <p className="text-slate-600 leading-relaxed text-base">
                  {resultado.instrucoes}
                </p>
              </div>

              <Button
                onClick={resetAll}
                variant="outline"
                className="mt-8 w-full py-6 rounded-xl font-bold text-slate-700 hover:text-slate-900 hover:bg-slate-50 border-slate-200 transition-colors"
              >
                <RefreshCcw size={18} className="mr-2" />
                Analisar outro resíduo
              </Button>
            </div>
          )}
        </Card>
      </section>
    </div>
  );
}

// Ícone customizado ajustado
const ScanFocusIcon = () => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="32"
    height="32"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2.5"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M8 5H6a2 2 0 0 0-2 2v2" />
    <path d="M16 5h2a2 2 0 0 1 2 2v2" />
    <path d="M4 15v2a2 2 0 0 0 2 2h2" />
    <path d="M20 15v2a2 2 0 0 1-2 2h-2" />
    <circle cx="12" cy="12" r="3" />
  </svg>
);