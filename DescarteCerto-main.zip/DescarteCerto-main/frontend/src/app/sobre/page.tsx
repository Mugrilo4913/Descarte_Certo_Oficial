"use client";

import { 
  Users, 
  MapPin, 
  Smartphone, 
  Globe, 
  Leaf, 
  BarChart3, 
  Lightbulb, 
  Camera, 
  Search, 
  BellRing, 
  ShieldCheck, 
  Building2, 
  Sparkles,
  Target,
  ArrowRight,
  FileText,
  Layers
} from "lucide-react";

import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function SobreNos() {
  return (
    <div className="mx-auto w-full max-w-6xl px-4 sm:px-6 lg:px-8 py-6 sm:py-10 space-y-12 text-slate-800">

      {/* Hero Header */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-50/60 via-slate-50 to-white p-6 sm:p-10 border border-emerald-100/70 shadow-sm">
        <div className="relative z-10 max-w-3xl space-y-3">
          <Badge className="bg-[#4B7E1B] text-white hover:bg-[#3d6616] px-3 py-1 rounded-full text-xs font-medium tracking-wide gap-1.5 shadow-sm inline-flex items-center">
            <Sparkles size={13} />
            Projeto de Extensão Universitária • CUFSA
          </Badge>

          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 tracking-tight leading-tight">
            Sobre o <span className="text-[#4B7E1B]">DescarteCerto</span>
          </h1>

          <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
            Unindo tecnologia, pesquisa acadêmica de campo e sustentabilidade urbana para 
            superar o déficit de informação e transformar a destinação de resíduos sólidos.
          </p>
        </div>

        {/* Círculo decorativo ao fundo */}
        <div className="absolute -right-16 -top-16 w-64 h-64 bg-[#98C270]/15 rounded-full blur-3xl pointer-events-none" />
      </section>

      {/* Quem Somos */}
      <section>
        <Card className="rounded-3xl border border-slate-200/80 bg-white shadow-sm overflow-hidden hover:shadow-md transition-shadow">
          <CardHeader className="pb-3 border-b border-slate-100 bg-slate-50/50">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 bg-[#D9E8CD] text-[#4B7E1B] rounded-2xl flex items-center justify-center shrink-0">
                <Users size={22} />
              </div>
              <div>
                <CardTitle className="text-lg sm:text-xl font-bold text-slate-900">
                  Quem Somos e a Origem do Projeto
                </CardTitle>
                <p className="text-xs text-slate-500 font-medium">Iniciativa acadêmica com impacto comunitário real</p>
              </div>
            </div>
          </CardHeader>

          <CardContent className="pt-5 text-slate-600 text-sm sm:text-base leading-relaxed space-y-4">
            <p>
              Somos um grupo de estudantes do curso de <strong>Ciência da Computação do Centro Universitário Fundação Santo André (CUFSA)</strong>. O <strong>DescarteCerto</strong> foi idealizado e desenvolvido no âmbito da nossa <strong>Ação Curricular de Extensão (ACEX) / Projeto Aplicado</strong>.
            </p>
            <p>
              Nosso objetivo fundamental foi aplicar metodologias ágeis e engenharia de software para construir uma solução digital acessível, respondendo diretamente às dores e barreiras enfrentadas pelos cidadãos no descarte cotidiano de resíduos domésticos.
            </p>
          </CardContent>
        </Card>
      </section>

      {/* O Problema & Pesquisa Local */}
      <section className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2">
          <div>
            <div className="flex items-center gap-2 text-[#4B7E1B] font-semibold text-xs tracking-wider uppercase mb-1">
              <BarChart3 size={16} /> Diagnóstico e Dados Reais
            </div>
            <h2 className="text-2xl font-bold text-slate-900">O Problema e a Nossa Pesquisa Local</h2>
          </div>
          <Badge variant="outline" className="border-slate-300 text-slate-600 self-start sm:self-auto text-xs py-1">
            Fonte: MUNIC/IBGE & Pesquisa Própria
          </Badge>
        </div>

        {/* Contexto Macroeconômico */}
        <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 sm:p-5 text-xs sm:text-sm text-slate-600 leading-relaxed space-y-2">
          <p>
            A gestão de resíduos sólidos convive com desafios crônicos de logística e comunicação. Conforme a <strong>Pesquisa de Informações Básicas Municipais (MUNIC) do IBGE (2023)</strong>, <strong>60,5%</strong> dos municípios brasileiros que contam com serviços de manejo declaram ter coleta seletiva.
          </p>
          <p>
            Entretanto, estudos de sustentabilidade urbana indicam que ecopontos e locais de entrega voluntária muitas vezes permanecem subutilizados simplesmente porque a população <strong>não conhece sua localização ou horário de funcionamento</strong>.
          </p>
        </div>

        {/* Grid de Estatísticas Locais - Vila Valparaíso */}
        <div className="space-y-3">
          <div className="flex items-center justify-between text-xs text-slate-500 font-medium">
            <span>Resultados do Estudo de Campo — Bairro Vila Valparaíso, Santo André (SP)</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Card 1 */}
            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm flex flex-col justify-between hover:-translate-y-1 transition-all">
              <div>
                <span className="text-3xl sm:text-4xl font-black text-[#4B7E1B] tracking-tight">65%</span>
                <p className="text-xs text-slate-600 mt-2 font-medium">
                  afirmam <strong>separar o lixo reciclável</strong> no dia a dia domiciliar.
                </p>
              </div>
              <div className="w-full bg-slate-100 h-1.5 rounded-full mt-4 overflow-hidden">
                <div className="bg-[#4B7E1B] h-full rounded-full" style={{ width: "65%" }} />
              </div>
            </div>

            {/* Card 2 */}
            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm flex flex-col justify-between hover:-translate-y-1 transition-all">
              <div>
                <span className="text-3xl sm:text-4xl font-black text-[#BC4700] tracking-tight">75%</span>
                <p className="text-xs text-slate-600 mt-2 font-medium">
                  consideram as informações sobre coleta na cidade <strong>mal organizadas</strong>.
                </p>
              </div>
              <div className="w-full bg-slate-100 h-1.5 rounded-full mt-4 overflow-hidden">
                <div className="bg-[#BC4700] h-full rounded-full" style={{ width: "75%" }} />
              </div>
            </div>

            {/* Card 3 */}
            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm flex flex-col justify-between hover:-translate-y-1 transition-all">
              <div>
                <span className="text-3xl sm:text-4xl font-black text-[#D97706] tracking-tight">75%</span>
                <p className="text-xs text-slate-600 mt-2 font-medium">
                  relatam grande <strong>dificuldade em encontrar informações oficiais</strong>.
                </p>
              </div>
              <div className="w-full bg-slate-100 h-1.5 rounded-full mt-4 overflow-hidden">
                <div className="bg-[#D97706] h-full rounded-full" style={{ width: "75%" }} />
              </div>
            </div>

            {/* Card 4 */}
            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm flex flex-col justify-between hover:-translate-y-1 transition-all">
              <div>
                <span className="text-3xl sm:text-4xl font-black text-[#1860B1] tracking-tight">45%</span>
                <p className="text-xs text-slate-600 mt-2 font-medium">
                  apenas <strong>sabem localizar</strong> o PEV ou cooperativa mais próxima.
                </p>
              </div>
              <div className="w-full bg-slate-100 h-1.5 rounded-full mt-4 overflow-hidden">
                <div className="bg-[#1860B1] h-full rounded-full" style={{ width: "45%" }} />
              </div>
            </div>
          </div>
        </div>

        {/* Box da Hipótese Científica */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-emerald-50 via-teal-50/40 to-slate-50 border-l-4 border-[#4B7E1B] rounded-r-2xl rounded-l-md shadow-sm">
          <div className="flex items-start gap-3">
            <Target className="text-[#4B7E1B] shrink-0 mt-0.5" size={20} />
            <div className="text-xs sm:text-sm text-slate-700 leading-relaxed">
              <strong className="text-slate-900 font-semibold">Hipótese Formulada:</strong> Para a comunidade analisada, 
              a <em>assimetria e falta de centralização da informação</em> estão diretamente associadas às falhas no descarte e triagem, atuando como o principal gargalo para a eficiência da coleta seletiva local.
            </div>
          </div>
        </div>
      </section>

      {/* A Solução Tecnológica */}
      <section className="space-y-6">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-[#4B7E1B] font-semibold text-xs tracking-wider uppercase">
            <Layers size={16} /> Engenharia de Software
          </div>
          <h2 className="text-2xl font-bold text-slate-900">A Solução Tecnológica</h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Card Principal - Dark Theme Moderno */}
          <Card className="lg:col-span-8 rounded-3xl bg-gradient-to-br from-[#29241F] to-[#3A342D] text-white border-none shadow-md overflow-hidden relative flex flex-col justify-between">
            <div className="absolute right-0 top-0 w-80 h-80 bg-[#98C270]/10 rounded-full blur-3xl pointer-events-none" />

            <CardHeader className="relative z-10 pb-2">
              <div className="flex items-center justify-between">
                <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center text-[#98C270]">
                  <Smartphone size={24} />
                </div>
                <Badge className="bg-[#98C270]/20 text-[#98C270] border-none font-medium text-xs">
                  PWA • Progressive Web App
                </Badge>
              </div>
              <CardTitle className="text-xl sm:text-2xl text-white font-bold mt-3">
                Plataforma Acessível & Geocodificada
              </CardTitle>
            </CardHeader>

            <CardContent className="relative z-10 space-y-5 text-xs sm:text-sm text-slate-300 leading-relaxed">
              <p>
                O sistema é acessado diretamente pelo navegador em qualquer dispositivo, dispensando downloads em lojas de aplicativos. O usuário digita o <strong>CEP</strong> e a ferramenta realiza uma <strong>geocodificação imediata</strong>, cruzando as coordenadas com a base de dados de rotas e pontos de descarte estruturada pela equipe.
              </p>

              {/* Grid interno de recursos */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div className="bg-white/5 backdrop-blur-sm p-3.5 rounded-2xl border border-white/10 flex gap-3 items-start">
                  <MapPin className="text-[#98C270] shrink-0 mt-0.5" size={18} />
                  <div>
                    <h4 className="text-white font-semibold text-xs">Mapeamento de PEVs</h4>
                    <p className="text-[11px] text-slate-400 mt-0.5">Localização exata de ecopontos e cooperativas mais próximas.</p>
                  </div>
                </div>

                <div className="bg-white/5 backdrop-blur-sm p-3.5 rounded-2xl border border-white/10 flex gap-3 items-start">
                  <Building2 className="text-[#98C270] shrink-0 mt-0.5" size={18} />
                  <div>
                    <h4 className="text-white font-semibold text-xs">Cronogramas Oficiais</h4>
                    <p className="text-[11px] text-slate-400 mt-0.5">Dias e horários atualizados de coleta baseados nos dados do SEMASA.</p>
                  </div>
                </div>

                <div className="bg-white/5 backdrop-blur-sm p-3.5 rounded-2xl border border-white/10 flex gap-3 items-start">
                  <FileText className="text-[#98C270] shrink-0 mt-0.5" size={18} />
                  <div>
                    <h4 className="text-white font-semibold text-xs">Guias & Fichas Educativas</h4>
                    <p className="text-[11px] text-slate-400 mt-0.5">Materiais recicláveis, orgânicos, eletrônicos e perigosos.</p>
                  </div>
                </div>

                <div className="bg-white/5 backdrop-blur-sm p-3.5 rounded-2xl border border-white/10 flex gap-3 items-start">
                  <Search className="text-[#98C270] shrink-0 mt-0.5" size={18} />
                  <div>
                    <h4 className="text-white font-semibold text-xs">Consulta Rápida por CEP</h4>
                    <p className="text-[11px] text-slate-400 mt-0.5">Acesso instantâneo sem necessidade de cadastro burocrático prévio.</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Card LGPD & Mapeamento de Ocorrências */}
          <Card className="lg:col-span-4 rounded-3xl bg-white border border-slate-200/90 shadow-sm flex flex-col justify-between p-6">
            <div className="space-y-4">
              <div className="w-12 h-12 bg-amber-50 rounded-2xl flex items-center justify-center text-amber-700">
                <Camera size={24} />
              </div>

              <div>
                <h3 className="text-lg font-bold text-slate-900 leading-snug">
                  Mapeamento de Descarte Irregular
                </h3>
                <p className="text-xs text-slate-500 mt-1">Colaboração comunitária monitorada</p>
              </div>

              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                A plataforma propõe uma funcionalidade para <strong>registro fotográfico de pontos críticos</strong> com acúmulo indevido de entulho ou resíduos.
              </p>

              <div className="bg-slate-50 border border-slate-200/80 p-3.5 rounded-2xl flex gap-2.5 items-start">
                <ShieldCheck className="text-slate-700 shrink-0 mt-0.5" size={18} />
                <p className="text-[11px] text-slate-600 leading-normal">
                  <strong>Adequação à LGPD:</strong> Desenvolvido respeitando os princípios de privacidade de dados, com finalidade restrita ao mapeamento interno e diagnóstico territorial.
                </p>
              </div>
            </div>
          </Card>
        </div>
      </section>

      {/* Validação, Futuro e ODS */}
      <section className="space-y-6">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-[#4B7E1B] font-semibold text-xs tracking-wider uppercase">
            <Globe size={16} /> Futuro & Sustentabilidade
          </div>
          <h2 className="text-2xl font-bold text-slate-900">Validação, Próximos Passos e ODS</h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {/* Card Validação & Roadmap */}
          <Card className="rounded-3xl bg-white border border-slate-200/80 shadow-sm p-6 flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-emerald-50 text-[#4B7E1B] flex items-center justify-center">
                  <BellRing size={18} />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-sm sm:text-base">Alta Intenção de Uso Declarada</h3>
                  <p className="text-xs text-slate-500">Validação receptiva pela comunidade local</p>
                </div>
              </div>

              <div className="space-y-3">
                <div className="bg-slate-50 border border-slate-100 p-3 rounded-2xl flex items-center justify-between">
                  <span className="text-xs text-slate-700 font-medium">Interesse em Guia Educativo de Separação</span>
                  <span className="text-sm font-bold text-[#4B7E1B] bg-emerald-50 px-2.5 py-0.5 rounded-lg border border-emerald-100">85%</span>
                </div>

                <div className="bg-slate-50 border border-slate-100 p-3 rounded-2xl flex items-center justify-between">
                  <span className="text-xs text-slate-700 font-medium">Acharam o Mapa de Descarte &quot;Muito Útil&quot;</span>
                  <span className="text-sm font-bold text-[#4B7E1B] bg-emerald-50 px-2.5 py-0.5 rounded-lg border border-emerald-100">83%</span>
                </div>

                <div className="bg-slate-50 border border-slate-100 p-3 rounded-2xl flex items-center justify-between">
                  <span className="text-xs text-slate-700 font-medium">Utilizariam Alertas de Dias e Horários</span>
                  <span className="text-sm font-bold text-[#4B7E1B] bg-emerald-50 px-2.5 py-0.5 rounded-lg border border-emerald-100">80%</span>
                </div>
              </div>
            </div>

            {/* Próximos Passos */}
            <div className="border-t border-slate-100 pt-4 text-xs text-slate-600 leading-relaxed space-y-1.5">
              <span className="font-semibold text-slate-900 block">Status Atual & Expansão:</span>
              <p>
                O sistema é um <strong>protótipo funcional em contexto acadêmico</strong>, validado inicialmente para o bairro Vila Valparaíso. A expansão para as demais regiões de Santo André e ABC Paulista depende de:
              </p>
              <ul className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-2 text-[11px] font-medium text-slate-700">
                <li className="bg-slate-50 p-2 rounded-xl border border-slate-100 text-center">Testes de usabilidade ampliados</li>
                <li className="bg-slate-50 p-2 rounded-xl border border-slate-100 text-center">Automação de base de dados</li>
                <li className="bg-slate-50 p-2 rounded-xl border border-slate-100 text-center">Parcerias institucionais</li>
              </ul>
            </div>
          </Card>

          {/* Card ODS da ONU */}
          <Card className="rounded-3xl bg-gradient-to-br from-[#85b557] to-[#4B7E1B] text-white border-none shadow-sm p-6 sm:p-7 flex flex-col justify-between relative overflow-hidden">
            <div className="absolute -bottom-10 -right-10 w-48 h-48 bg-white/10 rounded-full blur-2xl pointer-events-none" />

            <div className="space-y-4 relative z-10">
              <div className="w-12 h-12 bg-white/20 backdrop-blur-md rounded-2xl flex items-center justify-center text-white">
                <Globe size={24} />
              </div>

              <div>
                <h3 className="text-xl sm:text-2xl font-bold tracking-tight">Compromisso com os ODS da ONU</h3>
                <p className="text-xs sm:text-sm text-white/90 mt-1 leading-relaxed">
                  Conectando código a metas globais de desenvolvimento humano e sustentabilidade:
                </p>
              </div>

              <div className="space-y-3 pt-2">
                <div className="bg-white/15 backdrop-blur-md p-4 rounded-2xl border border-white/20">
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-xs uppercase tracking-wide text-white">ODS 11</span>
                    <Badge className="bg-white/20 hover:bg-white/20 text-white text-[10px] border-none">Cidades Sustentáveis</Badge>
                  </div>
                  <p className="text-xs text-white/90 leading-relaxed">
                    Apoio à infraestrutura de saneamento urbano e fortalecimento da cidadania ativa na conservação do espaço público.
                  </p>
                </div>

                <div className="bg-white/15 backdrop-blur-md p-4 rounded-2xl border border-white/20">
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-xs uppercase tracking-wide text-white">ODS 12</span>
                    <Badge className="bg-white/20 hover:bg-white/20 text-white text-[10px] border-none">Consumo Responsável</Badge>
                  </div>
                  <p className="text-xs text-white/90 leading-relaxed">
                    Disseminação de práticas educativas para triagem e redução do desperdício de materiais sólidos recicláveis e perigosos.
                  </p>
                </div>
              </div>
            </div>

            <div className="pt-4 text-[11px] text-white/80 flex items-center gap-1.5 relative z-10">
              <span>Tecnologia como instrumento de cidadania ecológica.</span>
            </div>
          </Card>
        </div>
      </section>

    </div>
  );
} 