"use client";

import { useState, useEffect, useMemo } from "react";
import dynamic from "next/dynamic";
import { 
  Search, 
  MapPin, 
  Monitor, 
  Droplet, 
  Wine, 
  Recycle,
  X,
  MapPinOff,
  Loader2,
  FileText,
  Wrench,
  Leaf,
  Cross,
  Radio,
  TreeDeciduous,
  AlertCircle,
  CheckCircle2
} from "lucide-react";

import { Button } from "@/components/ui/button";
import SidebarLocal from "@/components/blocks/map/sidebar";
import ListaLocais from "@/components/blocks/map/listalocais";

// Carregamento dinâmico do Leaflet para evitar erros de SSR
const MapaDinamico = dynamic(() => import("@/components/map/map"), {
  ssr: false,
  loading: () => (
    <div className="w-full h-[380px] sm:h-[480px] lg:h-[550px] bg-slate-100 animate-pulse rounded-2xl md:rounded-3xl flex flex-col items-center justify-center text-slate-400 gap-2 border border-slate-200">
      <div className="h-7 w-7 border-3 border-emerald-600 border-t-transparent animate-spin rounded-full" />
      <span className="text-xs md:text-sm font-medium text-slate-500">Carregando mapa interativo...</span>
    </div>
  ),
});


const mapearEstiloPorCategoria = (categoriaStr: string) => {
  const cat = categoriaStr?.toLowerCase() || "";

  if (cat.includes("eletrônico") || cat.includes("eletronico")) {
    return { icone: Monitor, corIcone: "text-indigo-600", bgIcone: "bg-indigo-100", borda: "border-indigo-200" };
  }
  if (cat.includes("madeira")) {
    return { icone: TreeDeciduous, corIcone: "text-amber-800", bgIcone: "bg-amber-100", borda: "border-amber-200" };
  }
  if (cat.includes("metal")) {
    return { icone: Wrench, corIcone: "text-amber-600", bgIcone: "bg-amber-50", borda: "border-amber-200" };
  }
  if (cat.includes("não reciclável") || cat.includes("naoreciclavel")) {
    return { icone: AlertCircle, corIcone: "text-slate-600", bgIcone: "bg-slate-100", borda: "border-slate-200" };
  }
  if (cat.includes("orgânico") || cat.includes("organico")) {
    return { icone: Leaf, corIcone: "text-emerald-700", bgIcone: "bg-emerald-100", borda: "border-emerald-200" };
  }
  if (cat.includes("papel")) {
    return { icone: FileText, corIcone: "text-blue-600", bgIcone: "bg-blue-50", borda: "border-blue-200" };
  }
  if (cat.includes("plástico") || cat.includes("plastico")) {
    return { icone: Droplet, corIcone: "text-cyan-600", bgIcone: "bg-cyan-50", borda: "border-cyan-200" };
  }
  if (cat.includes("radiação") || cat.includes("radiacao")) {
    return { icone: Radio, corIcone: "text-purple-600", bgIcone: "bg-purple-100", borda: "border-purple-200" };
  }
  if (cat.includes("saúde") || cat.includes("saude")) {
    return { icone: Cross, corIcone: "text-rose-600", bgIcone: "bg-rose-100", borda: "border-rose-200" };
  }
  if (cat.includes("vidro")) {
    return { icone: Wine, corIcone: "text-teal-700", bgIcone: "bg-teal-50", borda: "border-teal-200" };
  }
  return { icone: Recycle, corIcone: "text-green-600", bgIcone: "bg-green-50", borda: "border-green-200" };
};

// Cálculo de distância
function calcularDistancia(lat1: number, lon1: number, lat2: number, lon2: number) {
  const R = 6371;
  const dLat = (lat2 - lat1) * (Math.PI / 180);
  const dLon = (lon2 - lon1) * (Math.PI / 180);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * (Math.PI / 180)) * Math.cos(lat2 * (Math.PI / 180)) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

// Categorias para os filtros
const FILTROS_RAPIDOS = [
  { id: "todas", label: "Todos", icone: Recycle },
  { id: "eletrônicos", label: "Eletrônicos", icone: Monitor },
  { id: "madeira", label: "Madeira", icone: TreeDeciduous },
  { id: "metal", label: "Metal", icone: Wrench },
  { id: "não reciclável", label: "Não Reciclável", icone: AlertCircle },
  { id: "orgânicos", label: "Orgânicos", icone: Leaf },
  { id: "papel", label: "Papel", icone: FileText },
  { id: "plástico", label: "Plástico", icone: Droplet },
  { id: "radiação", label: "Radiação", icone: Radio },
  { id: "saúde domiciliar", label: "Saúde Domiciliar", icone: Cross },
  { id: "vidro", label: "Vidro", icone: Wine },
];

export default function MapaPage() {
  const [localSelecionado, setLocalSelecionado] = useState<any | null>(null);
  const [locais, setLocais] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [termoBusca, setTermoBusca] = useState("");
  const [categoriaAtiva, setCategoriaAtiva] = useState("todas");
  const [statusLocalizacao, setStatusLocalizacao] = useState<{ tipo: "sucesso" | "erro"; texto: string } | null>(null);
  const [posicaoUsuario, setPosicaoUsuario] = useState<{ lat: number; lng: number; endereco: string } | null>(null);

  // Carrega pontos de coleta da API
  useEffect(() => {
    async function buscarLocais() {
      try {
        setLoading(true);
        const resposta = await fetch("/api/pontos-coleta");
        const json = await resposta.json();

        if (json.success && Array.isArray(json.data)) {
          const locaisMapeados = json.data.map((local: any) => {
            const catPrincipal = local.categorias?.split(",")[0]?.trim() || "Geral";
            const estilo = mapearEstiloPorCategoria(catPrincipal);

            return {
              id: local.id,
              nome: local.nome,
              categoria: catPrincipal,
              todasCategorias: local.categorias || "",
              endereco: `${local.endereco || ""} ${local.bairro ? `- ${local.bairro}` : ""}`.trim(),
              latitude: Number(local.latitude),
              longitude: Number(local.longitude),
              status: local.horario ? "Aberto para descarte" : "Consulte os horários",
              statusCor: "text-emerald-700",
              icone: estilo.icone,
              corIcone: estilo.corIcone,
              bgIcone: estilo.bgIcone,
              horario: local.horario,
              descricao: local.observacoes || "Ponto de coleta credenciado para descarte consciente.",
              aceita: local.categorias
                ? local.categorias.split(",").map((c: string) => c.trim())
                : ["Geral"],
            };
          });

          setLocais(locaisMapeados);
        }
      } catch (error) {
        console.error("Erro ao obter pontos de coleta:", error);
      } finally {
        setLoading(false);
      }
    }

    buscarLocais();
  }, []);

  // Filtro 
  const locaisFiltradosEOrdenados = useMemo(() => {
    const filtrados = locais.filter((local) => {
      const matchTexto =
        !termoBusca ||
        local.nome.toLowerCase().includes(termoBusca.toLowerCase()) ||
        local.endereco.toLowerCase().includes(termoBusca.toLowerCase()) ||
        local.todasCategorias.toLowerCase().includes(termoBusca.toLowerCase());

      const matchCategoria =
        categoriaAtiva === "todas" ||
        local.aceita.some((cat: string) => cat.toLowerCase().includes(categoriaAtiva.toLowerCase()));

      return matchTexto && matchCategoria;
    });

    if (posicaoUsuario) {
      return [...filtrados].sort((a, b) => {
        const distA = calcularDistancia(posicaoUsuario.lat, posicaoUsuario.lng, a.latitude, a.longitude);
        const distB = calcularDistancia(posicaoUsuario.lat, posicaoUsuario.lng, b.latitude, b.longitude);
        return distA - distB;
      });
    }

    return filtrados;
  }, [locais, termoBusca, categoriaAtiva, posicaoUsuario]);

  const limparFiltros = () => {
    setTermoBusca("");
    setCategoriaAtiva("todas");
  };

  return (
    <div className="flex flex-col w-full pb-16 min-h-screen text-slate-800 antialiased">
      <div className="max-w-[1440px] w-full mx-auto px-3 sm:px-6 md:px-8 mt-2 sm:mt-6 flex flex-col gap-6">

        {/* CABEÇALHO */}
        <header className="space-y-1">
          <h1 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-slate-900 tracking-tight">
            Mapa de Pontos de Coleta
          </h1>
          <p className="text-slate-600 text-xs sm:text-sm md:text-base max-w-2xl">
            Encontre o local adequado para descartar materiais recicláveis, eletrônicos e outros resíduos próximos de você.
          </p>
        </header>

        <section className="bg-white rounded-3xl p-4 sm:p-5 shadow-sm border border-slate-200/80 space-y-4">
          <div className="flex flex-col sm:flex-row gap-2.5 items-stretch sm:items-center justify-between">
            
            <div className="relative flex-1">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" size={18} />
              <input
                type="text"
                value={termoBusca}
                onChange={(e) => setTermoBusca(e.target.value)}
                placeholder="Buscar pelo nome do ponto de coleta..."
                className="w-full h-11 pl-10 pr-9 rounded-2xl border border-slate-200 bg-slate-50/70 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#8CB861]/30 focus:border-[#8CB861] text-xs sm:text-sm font-medium transition-all placeholder:text-slate-400"
              />
              {termoBusca && (
                <button
                  type="button"
                  onClick={() => setTermoBusca("")}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1"
                >
                  <X size={15} />
                </button>
              )}
            </div>


          </div>

          {/* Feedback do GPS */}
          {statusLocalizacao && (
            <div
              className={`p-3 rounded-2xl text-xs sm:text-sm flex items-center justify-between gap-2 animate-in fade-in duration-300 ${
                statusLocalizacao.tipo === "sucesso"
                  ? "bg-emerald-50 border border-emerald-200 text-emerald-800"
                  : "bg-red-50 border border-red-200 text-red-700"
              }`}
            >
              <div className="flex items-center gap-2">
                {statusLocalizacao.tipo === "sucesso" ? (
                  <CheckCircle2 size={17} className="shrink-0 text-emerald-600" />
                ) : (
                  <AlertCircle size={17} className="shrink-0 text-red-500" />
                )}
                <span className="font-medium">{statusLocalizacao.texto}</span>
              </div>
              

            </div>
          )}

          {/* FILTROS RESPONSIVOS */}
          <div className="pt-3 border-t border-slate-100 flex flex-col gap-2.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                Filtrar por tipo de resíduo:
              </span>
              {(termoBusca || categoriaAtiva !== "todas") && (
                <button
                  type="button"
                  onClick={limparFiltros}
                  className="text-xs font-semibold text-rose-600 hover:text-rose-700 hover:underline transition-colors"
                >
                  Limpar filtros
                </button>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
              {FILTROS_RAPIDOS.map((filtro) => {
                const Icone = filtro.icone;
                const ativo = categoriaAtiva === filtro.id;

                return (
                  <button
                    key={filtro.id}
                    type="button"
                    onClick={() => setCategoriaAtiva(filtro.id)}
                    className={`flex items-center gap-1.5 px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-xl sm:rounded-full text-xs font-semibold transition-all duration-200 border cursor-pointer ${
                      ativo
                        ? "bg-slate-900 text-white border-slate-900 shadow-xs"
                        : "bg-slate-50 hover:bg-slate-100 text-slate-600 border-slate-200/80 active:scale-95"
                    }`}
                  >
                    <Icone size={14} className={ativo ? "text-emerald-400" : "text-slate-500"} />
                    <span>{filtro.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </section>

        {/* CONTADOR E STATUS */}
        <div className="flex items-center justify-between text-xs sm:text-sm text-slate-500 px-1">
          <span>
            Exibindo <strong className="text-slate-900">{locaisFiltradosEOrdenados.length}</strong>{" "}
            {locaisFiltradosEOrdenados.length === 1 ? "ponto de coleta" : "pontos de coleta"}
            {posicaoUsuario && " (mais próximos primeiro)"}
          </span>
          {posicaoUsuario && (
            <span className="inline-flex items-center gap-1 text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full font-medium text-xs border border-emerald-200/50">
              <MapPin size={12} /> GPS Ativo
            </span>
          )}
        </div>

        {/* MAPA E LISTA */}
        <div className="flex flex-col xl:flex-row gap-6 relative items-start">
          <div className="flex-1 w-full flex flex-col gap-6">

            <main className="w-full bg-white p-2 sm:p-2.5 rounded-3xl shadow-sm border border-slate-200/80 overflow-hidden relative">
              <div className="w-full rounded-2xl overflow-hidden min-h-[380px] sm:min-h-[480px] lg:min-h-[550px]">
                <MapaDinamico
                  locais={locaisFiltradosEOrdenados}
                  localSelecionado={localSelecionado}
                  onSelect={setLocalSelecionado}
                />
              </div>
            </main>

            {!loading && locaisFiltradosEOrdenados.length === 0 && (
              <div className="w-full p-10 bg-white border border-slate-200 rounded-3xl flex flex-col items-center justify-center text-center shadow-xs">
                <div className="p-3 bg-slate-100 rounded-full mb-3 text-slate-400">
                  <MapPinOff size={30} />
                </div>
                <h3 className="font-bold text-slate-900 text-base">Nenhum ponto de coleta localizado</h3>
                <p className="text-xs sm:text-sm text-slate-500 max-w-sm mt-1">
                  Não encontramos ecopontos com os filtros informados. Tente buscar por outro termo ou selecione todas as categorias.
                </p>
                <Button onClick={limparFiltros} variant="outline" size="sm" className="mt-4 rounded-xl text-xs">
                  Redefinir busca
                </Button>
              </div>
            )}

            {loading ? (
              <div className="w-full flex justify-center py-12">
                <div className="animate-spin rounded-full h-8 w-8 border-2 border-[#8CB861] border-t-transparent"></div>
              </div>
            ) : (
              <ListaLocais
                locais={locaisFiltradosEOrdenados}
                localSelecionado={localSelecionado}
                onSelect={setLocalSelecionado}
              />
            )}
          </div>

          <SidebarLocal
            local={localSelecionado}
            onClose={() => setLocalSelecionado(null)}
          />
        </div>

      </div>
    </div>
  );
}