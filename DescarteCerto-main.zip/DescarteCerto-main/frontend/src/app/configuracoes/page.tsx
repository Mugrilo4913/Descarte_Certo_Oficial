"use client";

import { useState, useEffect } from "react";
import {
  User as UserIcon,
  Shield,
  LogOut,
  MapPin,
  Camera,
  Settings,
  Trash2,
  AlertTriangle,
  Lock,
  ArrowLeft,
  Loader2,
  CheckCircle2,
  KeyRound,
  Search
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/context/AuthContext";
import Link from "next/link";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

export default function ConfiguracoesPage() {
  const { user, isLoading, logout, updateUser, deleteAccount } = useAuth();

  // Estados Perfil
  const [nome, setNome] = useState("");
  const [email, setEmail] = useState("");
  const [cep, setCep] = useState("");
  const [infoCep, setInfoCep] = useState<string | null>(null);

  // Estados Senha
  const [senhaAtual, setSenhaAtual] = useState("");
  const [novaSenha, setNovaSenha] = useState("");
  const [confirmarNovaSenha, setConfirmarNovaSenha] = useState("");

  const [salvandoPerfil, setSalvandoPerfil] = useState(false);
  const [salvandoSenha, setSalvandoSenha] = useState(false);
  const [buscandoCep, setBuscandoCep] = useState(false);

  const [mensagemPerfil, setMensagemPerfil] = useState<{ tipo: "sucesso" | "erro"; texto: string } | null>(null);
  const [mensagemSenha, setMensagemSenha] = useState<{ tipo: "sucesso" | "erro"; texto: string } | null>(null);

  useEffect(() => {
    if (user) {
      setNome(user.nome || "");
      setEmail(user.email || "");
      setCep(user.cep || "");
      if (user.cep) consultarViaCep(user.cep);
    }
  }, [user]);

  const consultarViaCep = async (cepEntrada: string) => {
    const limpo = cepEntrada.replace(/\D/g, "");
    if (limpo.length === 8) {
      setBuscandoCep(true);
      try {
        const res = await fetch(`https://viacep.com.br/ws/${limpo}/json/`);
        const d = await res.json();
        if (!d.erro) {
          setInfoCep(`${d.logradouro ? d.logradouro + ", " : ""}${d.bairro ? d.bairro + " - " : ""}${d.localidade}/${d.uf}`);
        } else {
          setInfoCep("CEP não localizado");
        }
      } catch {
        setInfoCep(null);
      } finally {
        setBuscandoCep(false);
      }
    }
  };

  const handleCepInput = (val: string) => {
    const raw = val.replace(/\D/g, "").slice(0, 8);
    const formatado = raw.replace(/^(\d{5})(\d)/, "$1-$2");
    setCep(formatado);
    if (raw.length === 8) {
      consultarViaCep(raw);
    } else {
      setInfoCep(null);
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-[400px]">
        <Loader2 className="animate-spin text-emerald-600" size={36} />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="max-w-[480px] mx-auto mt-20 p-8 bg-white rounded-3xl shadow-sm text-center flex flex-col items-center gap-4 border border-slate-100">
        <div className="w-16 h-16 bg-red-50 text-red-600 rounded-2xl flex items-center justify-center">
          <Lock size={28} />
        </div>
        <h2 className="text-2xl font-bold text-slate-900">Acesso Restrito</h2>
        <p className="text-sm text-slate-500">
          Você precisa estar conectado à sua conta para acessar as preferências e perfil.
        </p>
        <Link href="/login">
          <Button className="rounded-xl flex items-center gap-2 mt-2 bg-[#18C982] hover:bg-[#15b072] text-white font-bold">
            Ir para o Login <ArrowLeft size={16} className="rotate-180" />
          </Button>
        </Link>
      </div>
    );
  }

  // Atualizar dados de perfil no BD
  const handleSalvarPerfil = async () => {
    setMensagemPerfil(null);
    setSalvandoPerfil(true);

    try {
      const res = await fetch("/api/auth/perfil", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nome, email, cep }),
      });

      const data = await res.json();

      if (res.ok && data.success) {
        if (updateUser) updateUser({ nome, email, cep });
        setMensagemPerfil({ tipo: "sucesso", texto: "Dados atualizados com sucesso no sistema!" });
      } else {
        setMensagemPerfil({ tipo: "erro", texto: data.message || "Erro ao atualizar dados." });
      }
    } catch {
      setMensagemPerfil({ tipo: "erro", texto: "Falha de comunicação com o servidor." });
    } finally {
      setSalvandoPerfil(false);
    }
  };

  // Alterar senha
  const handleAlterarSenha = async (e: React.FormEvent) => {
    e.preventDefault();
    setMensagemSenha(null);

    if (novaSenha.length < 6) {
      setMensagemSenha({ tipo: "erro", texto: "A nova senha deve ter no mínimo 6 caracteres." });
      return;
    }
    if (novaSenha !== confirmarNovaSenha) {
      setMensagemSenha({ tipo: "erro", texto: "A confirmação de senha não confere." });
      return;
    }

    setSalvandoSenha(true);

    try {
      const res = await fetch("/api/auth/senha", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ senhaAtual, novaSenha }),
      });

      const data = await res.json();

      if (res.ok && data.success) {
        setMensagemSenha({ tipo: "sucesso", texto: "Senha redefinida com sucesso!" });
        setSenhaAtual("");
        setNovaSenha("");
        setConfirmarNovaSenha("");
      } else {
        setMensagemSenha({ tipo: "erro", texto: data.message || "Erro ao alterar senha." });
      }
    } catch {
      setMensagemSenha({ tipo: "erro", texto: "Erro ao conectar com o servidor." });
    } finally {
      setSalvandoSenha(false);
    }
  };

  const handleExcluirConta = async () => {
    const confirmou = window.confirm(
      "Tem certeza que deseja excluir sua conta permanentemente? Esta ação é irreversível."
    );
    if (!confirmou) return;

    const res = await deleteAccount();
    if (!res?.success) {
      alert(res?.message || "Falha ao excluir conta.");
    }
  };

  return (
    <div className="max-w-[900px] w-full mx-auto pb-16 pt-4 px-4 sm:px-6 space-y-8 animate-in fade-in duration-500">
      
      {/* Cabeçalho */}
      <div className="flex flex-col sm:flex-row items-center sm:items-start text-center sm:text-left gap-4">
        <div className="p-3.5 bg-emerald-50 text-[#18C982] rounded-2xl border border-emerald-100">
          <Settings size={28} />
        </div>
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight text-slate-900">Configurações</h1>
          <p className="text-slate-500 text-sm mt-1">
            Gerencie seu cadastro, preferências de localização e credenciais de segurança.
          </p>
        </div>
      </div>

      <Tabs defaultValue="conta" className="w-full space-y-6">
        <TabsList className="grid w-full grid-cols-2 bg-slate-200/60 p-1.5 rounded-2xl h-14">
          <TabsTrigger
            value="conta"
            className="flex h-full items-center justify-center gap-2 rounded-xl text-slate-600 data-[state=active]:bg-white data-[state=active]:text-slate-900 data-[state=active]:shadow-sm font-bold text-sm transition-all"
          >
            <UserIcon size={18} />
            Meu Perfil
          </TabsTrigger>

          <TabsTrigger
            value="seguranca"
            className="flex h-full items-center justify-center gap-2 rounded-xl text-slate-600 data-[state=active]:bg-white data-[state=active]:text-slate-900 data-[state=active]:shadow-sm font-bold text-sm transition-all"
          >
            <Shield size={18} />
            Segurança & Acesso
          </TabsTrigger>
        </TabsList>

        {/* ================= ABA 1: MEU PERFIL ================= */}
        <TabsContent value="conta" className="space-y-6">
          <Card className="rounded-[28px] border-slate-200/80 shadow-sm overflow-hidden bg-white">
            <CardHeader className="pb-4 pt-6 px-6 sm:px-8">
              <CardTitle className="text-xl font-bold text-slate-900">Informações Pessoais</CardTitle>
              <CardDescription>
                Mantenha suas informações sincronizadas com os pontos de coleta recomendados.
              </CardDescription>
            </CardHeader>

            <CardContent className="space-y-6 px-6 sm:px-8 pb-6">
              {mensagemPerfil && (
                <div
                  className={`p-4 rounded-xl text-xs sm:text-sm font-medium flex items-center gap-3 ${
                    mensagemPerfil.tipo === "sucesso"
                      ? "bg-emerald-50 text-emerald-800 border border-emerald-200"
                      : "bg-red-50 text-red-700 border border-red-200"
                  }`}
                >
                  {mensagemPerfil.tipo === "sucesso" ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                  ) : (
                    <AlertTriangle className="w-5 h-5 text-red-500 shrink-0" />
                  )}
                  <span>{mensagemPerfil.texto}</span>
                </div>
              )}

              {/* Avatar do Usuário */}
              <div className="flex items-center gap-4 p-4 bg-slate-50 rounded-2xl border border-slate-100">
                <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-[#18C982] to-[#8CB861] flex items-center justify-center text-white text-2xl font-bold shadow-sm uppercase">
                  {nome ? nome.charAt(0) : "U"}
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-sm">{nome || "Usuário"}</h3>
                  <p className="text-xs text-slate-500">{email}</p>
                </div>
              </div>

              {/* Campos do Formulário */}
              <div className="grid sm:grid-cols-2 gap-5">
                <div className="space-y-1.5">
                  <Label htmlFor="nome" className="text-xs font-bold text-slate-700 uppercase">
                    Nome Completo
                  </Label>
                  <Input
                    id="nome"
                    value={nome}
                    onChange={(e) => setNome(e.target.value)}
                    className="h-12 rounded-xl bg-slate-50 border-slate-200 focus:bg-white"
                  />
                </div>

                <div className="space-y-1.5">
                  <Label htmlFor="email" className="text-xs font-bold text-slate-700 uppercase">
                    E-mail
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="h-12 rounded-xl bg-slate-50 border-slate-200 focus:bg-white"
                  />
                </div>
              </div>

              {/* CEP com Busca Automática */}
              <div className="space-y-1.5 sm:max-w-[60%]">
                <Label htmlFor="cep" className="text-xs font-bold text-slate-700 uppercase">
                  CEP Padrão (Localização para Coleta)
                </Label>
                <div className="flex gap-2">
                  <Input
                    id="cep"
                    value={cep}
                    onChange={(e) => handleCepInput(e.target.value)}
                    placeholder="00000-000"
                    maxLength={9}
                    className="h-12 rounded-xl bg-slate-50 border-slate-200 focus:bg-white"
                  />
                  <Button
                    type="button"
                    onClick={() => consultarViaCep(cep)}
                    disabled={buscandoCep}
                    variant="outline"
                    className="h-12 w-12 rounded-xl shrink-0 border-slate-200 hover:bg-slate-100"
                  >
                    {buscandoCep ? <Loader2 size={18} className="animate-spin text-emerald-600" /> : <Search size={18} />}
                  </Button>
                </div>
                {infoCep && (
                  <p className="text-xs font-medium text-emerald-700 mt-1 flex items-center gap-1.5">
                    <MapPin size={13} /> {infoCep}
                  </p>
                )}
              </div>
            </CardContent>

            <CardFooter className="border-t border-slate-100 px-6 sm:px-8 py-4 bg-slate-50/50 flex justify-end">
              <Button
                onClick={handleSalvarPerfil}
                disabled={salvandoPerfil}
                className="bg-[#18C982] hover:bg-[#15b072] text-white rounded-xl h-11 px-8 font-bold shadow-sm"
              >
                {salvandoPerfil ? (
                  <>
                    <Loader2 size={16} className="animate-spin mr-2" /> Salvando...
                  </>
                ) : (
                  "Salvar Dados"
                )}
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        {/* ================= ABA 2: SEGURANÇA E ACESSO ================= */}
        <TabsContent value="seguranca" className="space-y-6">
          
          {/* Alterar Senha */}
          <Card className="rounded-[28px] border-slate-200/80 shadow-sm overflow-hidden bg-white">
            <CardHeader className="pb-4 pt-6 px-6 sm:px-8">
              <div className="flex items-center gap-2 text-slate-900">
                <KeyRound size={20} className="text-[#18C982]" />
                <CardTitle className="text-xl font-bold">Alterar Senha</CardTitle>
              </div>
              <CardDescription>
                Atualize sua senha periodicamente para manter sua conta protegida.
              </CardDescription>
            </CardHeader>
            <form onSubmit={handleAlterarSenha}>
              <CardContent className="space-y-4 px-6 sm:px-8 pb-6">
                {mensagemSenha && (
                  <div
                    className={`p-4 rounded-xl text-xs sm:text-sm font-medium flex items-center gap-3 ${
                      mensagemSenha.tipo === "sucesso"
                        ? "bg-emerald-50 text-emerald-800 border border-emerald-200"
                        : "bg-red-50 text-red-700 border border-red-200"
                    }`}
                  >
                    {mensagemSenha.tipo === "sucesso" ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                    ) : (
                      <AlertTriangle className="w-5 h-5 text-red-500 shrink-0" />
                    )}
                    <span>{mensagemSenha.texto}</span>
                  </div>
                )}

                <div className="space-y-1.5">
                  <Label htmlFor="senhaAtual" className="text-xs font-bold text-slate-700 uppercase">
                    Senha Atual
                  </Label>
                  <Input
                    id="senhaAtual"
                    type="password"
                    value={senhaAtual}
                    onChange={(e) => setSenhaAtual(e.target.value)}
                    className="h-12 rounded-xl bg-slate-50 border-slate-200"
                    required
                  />
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <Label htmlFor="novaSenha" className="text-xs font-bold text-slate-700 uppercase">
                      Nova Senha
                    </Label>
                    <Input
                      id="novaSenha"
                      type="password"
                      value={novaSenha}
                      onChange={(e) => setNovaSenha(e.target.value)}
                      className="h-12 rounded-xl bg-slate-50 border-slate-200"
                      required
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="confirmarNovaSenha" className="text-xs font-bold text-slate-700 uppercase">
                      Confirmar Nova Senha
                    </Label>
                    <Input
                      id="confirmarNovaSenha"
                      type="password"
                      value={confirmarNovaSenha}
                      onChange={(e) => setConfirmarNovaSenha(e.target.value)}
                      className="h-12 rounded-xl bg-slate-50 border-slate-200"
                      required
                    />
                  </div>
                </div>
              </CardContent>
              <CardFooter className="border-t border-slate-100 px-6 sm:px-8 py-4 bg-slate-50/50 flex justify-end">
                <Button
                  type="submit"
                  disabled={salvandoSenha}
                  className="bg-slate-900 hover:bg-slate-800 text-white rounded-xl h-11 px-6 font-bold text-xs uppercase tracking-wide"
                >
                  {salvandoSenha ? <Loader2 size={16} className="animate-spin mr-2" /> : "Atualizar Senha"}
                </Button>
              </CardFooter>
            </form>
          </Card>

          {/* Permissões do Navegador */}
          <Card className="rounded-[28px] border-slate-200/80 shadow-sm overflow-hidden bg-white">
            <CardHeader className="pb-4 pt-6 px-6 sm:px-8">
              <CardTitle className="text-lg font-bold text-slate-900">Permissões de Dispositivo</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 px-6 sm:px-8 pb-6">
              <div className="flex items-center justify-between p-4 rounded-2xl bg-slate-50 border border-slate-100">
                <div className="flex gap-3.5 items-center">
                  <div className="bg-white p-2.5 rounded-xl border border-slate-200/60 text-[#18C982]">
                    <MapPin size={20} />
                  </div>
                  <div>
                    <Label className="text-sm font-bold text-slate-900">Localização e GPS</Label>
                    <p className="text-xs text-slate-500">Usado para ordenar os ecopontos mais próximos de você.</p>
                  </div>
                </div>
                <Switch defaultChecked className="data-[state=checked]:bg-[#18C982]" />
              </div>

              <div className="flex items-center justify-between p-4 rounded-2xl bg-slate-50 border border-slate-100">
                <div className="flex gap-3.5 items-center">
                  <div className="bg-white p-2.5 rounded-xl border border-slate-200/60 text-[#18C982]">
                    <Camera size={20} />
                  </div>
                  <div>
                    <Label className="text-sm font-bold text-slate-900">Câmera</Label>
                    <p className="text-xs text-slate-500">Utilizada para o leitor de resíduos por Inteligência Artificial.</p>
                  </div>
                </div>
                <Switch defaultChecked className="data-[state=checked]:bg-[#18C982]" />
              </div>
            </CardContent>
          </Card>

          {/* Zona de Encerramento e Exclusão */}
          <Card className="rounded-[28px] border-red-200/70 shadow-sm overflow-hidden bg-white">
            <CardHeader className="bg-red-50/40 border-b border-red-100/60 pb-4 pt-5 px-6 sm:px-8">
              <div className="flex items-center gap-2 text-red-600">
                <AlertTriangle size={18} />
                <CardTitle className="text-base font-bold">Ações da Conta</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="pt-6 px-6 sm:px-8 pb-6 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h4 className="font-bold text-slate-900 text-sm">Encerrar Sessão</h4>
                  <p className="text-xs text-slate-500">Desconecta sua conta com segurança deste dispositivo.</p>
                </div>
                <Button
                  onClick={logout}
                  variant="outline"
                  className="rounded-xl border-slate-200 hover:bg-slate-100 font-bold text-slate-700"
                >
                  <LogOut size={16} className="mr-2" /> Sair
                </Button>
              </div>

              <Separator />

              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h4 className="font-bold text-red-600 text-sm">Excluir Conta</h4>
                  <p className="text-xs text-slate-500">Apaga permanentemente seu cadastro e histórico de descarte.</p>
                </div>
                <Button
                  onClick={handleExcluirConta}
                  variant="destructive"
                  className="rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold"
                >
                  <Trash2 size={16} className="mr-2" /> Excluir Permanentemente
                </Button>
              </div>
            </CardContent>
          </Card>

        </TabsContent>
      </Tabs>
    </div>
  );
}