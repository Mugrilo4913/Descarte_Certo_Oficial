"use client";

import Link from "next/link";
import { ArrowLeft, Leaf, Sprout, Clock } from "lucide-react";
import { AccordionItem } from "@/components/ui/accordionItem"; 

export default function OrganicosPage() {
  // RESÍDUOS ORGÂNICOS
  const info = {
    nome: "Resíduos Orgânicos",
    corBase: "text-[#6D5E41]",
    corFundoIcone: "bg-[#F6F4EE]",
    icone: <Leaf size={40} className="text-[#6D5E41]" />,
    descricao: "Resíduos constituídos predominantemente por materiais de origem biológica, como restos de alimentos e resíduos vegetais.",
    processo: "Compostagem (Tratamento Biológico)",
    decomposicao: "2 a 6 semanas (em compostagem)",
    
    subcategorias: [
      {
        sigla: "CRU",
        nomeCompleto: "Cascas, Talos e Frutas Crúas",
        oQueE: "Restos de alimentos vegetais sem cozimento ou temperos de sal e óleo.",
        aplicacao: "Cascas de banana, maçã, batata, cenoura, talos de verduras e sementes.",
        comoSeparar: "Perfeitos para composteiras caseiras e minhocários. Mantenha em pote fechado na cozinha antes de destinar.",
        imagem: "/images/organicos/organico-frutas.jpg"
      },
      {
        sigla: "CAF",
        nomeCompleto: "Borra de Café e Chá",
        oQueE: "Resíduos do preparo de bebidas quentes contendo matéria orgânica rica em nitrogênio.",
        aplicacao: "Borra de café com filtro de papel e saquinhos de chá naturais (sem grampos).",
        comoSeparar: "Podem ir diretamente para a composteira ou minhocário doméstico, além de servirem como adubo direto no solo.",
        imagem: "/images/organicos/organico-cafe.jpg"
      },
      {
        sigla: "COZ",
        nomeCompleto: "Restos de Comida Cozida e Refeições",
        oQueE: "Alimentos preparados, temperados ou com óleos de cozinha residual.",
        aplicacao: "Sobras de arroz, feijão, massas, legumes cozidos e pães amanhecidos.",
        comoSeparar: "Evite colocar em minhocários caseiros pequenos. Destine à coleta de orgânicos municipal ou composteiras termofílicas.",
        imagem: "/images/organicos/organico-cozidos.jpg"
      },
      {
        sigla: "JAR",
        nomeCompleto: "Resíduos de Jardim e Podas",
        oQueE: "Matéria vegetal seca e verde resultante do manejo de plantas e gramados.",
        aplicacao: "Folhas secas, grama cortada, pequenos galhos triturados e flores murchas.",
        comoSeparar: "Folhas secas servem como 'matéria castanha' essencial na compostagem para equilibrar a umidade e o oxigênio.",
        imagem: "/images/organicos/organico-jardim.jpg"
      },
      {
        sigla: "CAR",
        nomeCompleto: "Ossos, Carnes e Proteínas",
        oQueE: "Resíduos de origem animal oriundos do preparo ou sobras de refeições.",
        aplicacao: "Aparas de carne, gordura vegetal/animal, ossos pequenos e espinhas de peixe.",
        comoSeparar: "Não coloque em composteiras comuns para não atrair insetos ou roedores. Embale bem no lixo orgânico da prefeitura.",
        imagem: "/images/organicos/organico-carne.jpg"
      }
    ],

    // Regras gerais de separação
    regrasGerais: [
      "Identifique o que é orgânico: restos de frutas, cascas, verduras, alimentos preparados, borra de café, folhas e podas vegetais.",
      "Diferencie reciclagem de compostagem: a destinação ideal dos resíduos orgânicos ocorre via processos biológicos (compostagem), gerando adubo natural.",
      "Mantenha separado do lixo seco: não misture resíduos orgânicos com papéis limpos, plásticos ou vidros para evitar a contaminação dos recicláveis.",
      "Atenção ao acondicionamento: para descarte na coleta municipal ou composteiras domésticas, escorra os líquidos em excesso."
    ]
  };

  return (
    <div className="flex flex-col max-w-[900px] w-full mx-auto pb-12 pt-4 px-4 bg-white min-h-screen">
      
      {/* Botão Voltar */}
      <div className="mb-8">
        <Link href="/categorias" className="flex items-center gap-2 text-gray-500 hover:text-gray-900 transition-colors text-sm font-medium w-fit">
          <ArrowLeft size={18} />
          Voltar para categorias
        </Link>
      </div>

      {/* Cabeçalho da Categoria */}
      <section className="flex flex-col md:flex-row gap-6 items-start md:items-center mb-10">
        <div className={`w-24 h-24 ${info.corFundoIcone} rounded-2xl flex items-center justify-center shrink-0`}>
          {info.icone}
        </div>
        <div>
          <h1 className="text-3xl font-extrabold text-gray-900 mb-2">{info.nome}</h1>
          <p className="text-gray-600 text-sm leading-relaxed max-w-2xl">
            {info.descricao}
          </p>
        </div>
      </section>

      {/* Badges de Informação */}
      <section className="flex flex-col sm:flex-row gap-8 mb-12 border-y border-gray-100 py-6">
        <div className="flex items-start gap-3">
          <Sprout className="text-amber-800 shrink-0 mt-1" size={24} />
          <div>
            <h4 className="font-bold text-gray-900 text-sm">{info.processo}</h4>
            <p className="text-xs text-gray-500">Transformação em adubo e condicionador de solo</p>
          </div>
        </div>
        <div className="flex items-start gap-3">
          <Clock className="text-amber-800 shrink-0 mt-1" size={24} />
          <div>
            <h4 className="font-bold text-gray-900 text-sm">Tempo de decomposição</h4>
            <p className="text-xs text-gray-500">{info.decomposicao}</p>
          </div>
        </div>
      </section>

      {/* Abas Retráteis (Accordion) */}
      <section className="mb-10 space-y-4">
        <h2 className="text-xl font-bold text-gray-900 mb-6">Tipos de resíduos orgânicos e destinação</h2>
        
        {info.subcategorias.map((sub) => (
          <AccordionItem
            key={sub.sigla}
            sigla={sub.sigla}
            titulo={sub.nomeCompleto}
            resumo={sub.aplicacao}
            corTexto={info.corBase}
            oQueE={sub.oQueE}
            usos={sub.aplicacao}
            comoSeparar={sub.comoSeparar}
            imagem={sub.imagem}
          />
        ))}
      </section>

      {/* Regras Gerais de Separação */}
      <section>
        <h2 className="text-xl font-bold text-gray-900 mb-4">Como separar e destinar corretamente</h2>
        <div className="bg-[#F8F9FA] rounded-3xl p-6 md:p-8">
          <ul className="space-y-4">
            {info.regrasGerais.map((regra, i) => (
              <li key={i} className="flex gap-4 items-start">
                <div className="w-8 h-8 rounded-full bg-[#E9ECEF] flex items-center justify-center shrink-0 mt-0.5">
                  <span className={`font-bold text-sm ${info.corBase}`}>{i + 1}</span>
                </div>
                <p className="text-gray-600 text-sm leading-relaxed pt-1">{regra}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>

    </div>
  );
}