"use client";

import Link from "next/link";
import { ArrowLeft, Cross, ShieldAlert, AlertTriangle } from "lucide-react";
import { AccordionItem } from "@/components/ui/accordionItem"; 

export default function SaudePage() {
  // RESÍDUOS DE SAÚDE / HOSPITALAR
  const info = {
    nome: "Resíduos de Saúde Domiciliar",
    corBase: "text-red-600",
    corFundoIcone: "bg-gray-100 border border-gray-200",
    icone: <Cross size={40} className="text-red-600" />,
    descricao: "Materiais provenientes de cuidados de saúde em casa, como medicamentos vencidos, seringas e agulhas, que exigem descarte seguro para evitar acidentes e contaminação.",
    processo: "Tratamento e Destinação Especializada",
    alerta: "Nunca descarte na lixeira comum ou no vaso sanitário",
    

    subcategorias: [
      {
        sigla: "SER",
        nomeCompleto: "Seringas e Agulhas Usadas (Perfurocortantes)",
        oQueE: "Insumos perfurocortantes utilizados na aplicação de insulina, anticoagulantes ou outros tratamentos contínuos.",
        aplicacao: "Tratamento caseiro de diabetes, aplicação de medicamentos injetáveis e soros.",
        comoSeparar: "Armazene em recipiente rígido de plástico grosso (ex: embalagem de amaciante ou PET resistente) com tampa rosqueada. Nunca jogue solto no lixo.",
        imagem: "/images/saudedomiciliar/saude-seringas.jpg"
      },
      {
        sigla: "COM",
        nomeCompleto: "Medicamentos Vencidos (Comprimidos e Cápsulas)",
        oQueE: "Sólidos farmacêuticos fora da validade ou cuja sobra de tratamento não será mais utilizada.",
        aplicacao: "Cartelas de comprimidos, cápsulas soltas e drágeas mantidas na farmácia caseira.",
        comoSeparar: "Mantenha o remédio na embalagem primária (blister) e entregue em postos de coleta em farmácias ou UBS. Nunca jogue na pia ou vaso sanitário.",
        imagem: "/images/saudedomiciliar/saude-comprimidos.jpg"
      },
      {
        sigla: "XAR",
        nomeCompleto: "Medicamentos Líquidos (Xaropes, Gotas e Pomadas)",
        oQueE: "Soluções farmacêuticas líquidas, cremes ou géis medicinais em frascos ou bisnagas.",
        aplicacao: "Xaropes para tosse, colírios, gotas nasais, pomadas dermatológicas e soluções orais.",
        comoSeparar: "Não despeje o conteúdo no ralo da pia. Leve os frascos bem fechados aos pontos de coleta credenciados.",
        imagem: "/images/saudedomiciliar/saude-xaropes.jpg"
      },
      {
        sigla: "CUR",
        nomeCompleto: "Curativos, Gazes e Ataduras Usadas",
        oQueE: "Materiais têxteis ou de algodão impregnados com sangue, secreções ou fluidos corporais.",
        aplicacao: "Tratamento de feridas domésticas, pós-operatórios e trocas de curativos diários.",
        comoSeparar: "Coloque em saco plástico duplo bem fechado e identifique. Em caso de doenças contagiosas, busque orientação na UBS.",
        imagem: "/images/saudedomiciliar/saude-curativos.jpg"
      },
      {
        sigla: "LUV",
        nomeCompleto: "Luvas de Procedimento e Máscaras Descartáveis",
        oQueE: "Equipamentos de proteção individual (EPIs) de látex, nitrilo ou TNT usados em cuidados de saúde.",
        aplicacao: "Atendimento a acamados, trocas de fraldas geriátricas e proteção respiratória.",
        comoSeparar: "Descarte no lixo comum de rejeitos (não reciclável), bem ensacados para evitar contato direto dos coletores.",
        imagem: "/images/saudedomiciliar/saude-luvas.jpg"
      },
      {
        sigla: "LAN",
        nomeCompleto: "Lancetas de Glicemia e Tiras Reagentes",
        oQueE: "Pequenas lâminas perfurantes e fitas usadas para medição de glicose no sangue.",
        aplicacao: "Monitoramento diário de taxas de açúcar por diabéticos.",
        comoSeparar: "Guarde as lancetas no mesmo recipiente rígido das agulhas (perfurocortantes). As fitas podem ir para o plástico rígido de descarte seguro.",
        imagem: "/images/saudedomiciliar/saude-lancetas.jpg"
      },
      {
        sigla: "AMP",
        nomeCompleto: "Ampolas de Vidro de Medicamentos",
        oQueE: "Pequenos recipientes de vidro quebráveis contendo doses de remédios injetáveis.",
        aplicacao: "Doses unitárias de vitaminas, anestésicos e analgésicos concentrados.",
        comoSeparar: "Guarde dentro do frasco plástico rígido de perfurocortantes para evitar cortes ou acidentes ao quebrar.",
        imagem: "/images/saudedomiciliar/saude-ampolas.jpg"
      },
      {
        sigla: "BOL",
        nomeCompleto: "Bolsas de Soro, Coleta e Cateteres",
        oQueE: "Dispositivos plásticos de infusão, drenagem ou coleta de fluidos corporais.",
        aplicacao: "Tratamentos caseiros de hemodiálise, sondas urinárias e soro fisiológico.",
        comoSeparar: "Esvazie completamente os líquidos em local adequado e acondicione a bolsa plástica em saco reforçado para coleta especial.",
        imagem: "/images/saudedomiciliar/saude-bolsas.jpg"
      },
      {
        sigla: "TER",
        nomeCompleto: "Termômetros Quebrados e Dispositivos de Medição",
        oQueE: "Aparelhos de medição de sinais vitais, especialmente termômetros antigos com mercúrio.",
        aplicacao: "Aferição de febre e medição de pressão arterial.",
        comoSeparar: "Termômetros de mercúrio quebrados exigem cuidado extra com os vapores tóxicos. Recolha os restos com luvas e leve à UBS.",
        imagem: "/images/saudedomiciliar/saude-termometro.jpg"
      },
      {
        sigla: "AER",
        nomeCompleto: "Inaladores, Bombinhas de Asma e Nebulizadores",
        oQueE: "Dispositivos em spray ou aerossol contendo resíduos de broncodilatadores.",
        aplicacao: "Tratamento de asma, bronquite e crises respiratórias.",
        comoSeparar: "Leve os frascos de bombinhas vazios ou vencidos aos coletores de medicamentos em farmácias.",
        imagem: "/images/saudedomiciliar/saude-bombinhas.jpg"
      }
    ],

    // Passos/Regras de segurança de descarte
    regrasGerais: [
      "Perfurocortantes (Seringas e Agulhas): armazene em recipiente rígido, resistente a furos e com tampa rosqueada (como embalagem de amaciante ou PET grossa). Nunca jogue agulhas soltas.",
      "Medicamentos Vencidos: não jogue remédios (comprimidos, xaropes ou pomadas) na lixeira comum nem na pia/vaso sanitário, pois contaminam o solo e os rios.",
      "Curativos e Materiais Contaminados: gazes, ataduras e luvas usadas devem ser embaladas em saco plástico duplo antes do descarte, separadas dos recicláveis secos.",
      "Pontos de Entrega (UBS e Farmácias): leve os medicamentos e o garrafão de perfurocortantes a Unidades Básicas de Saúde (UBS) ou farmácias com coletores de logística reversa."
    ]
  };

  return (
    <div className="flex flex-col max-w-[900px] w-full mx-auto pb-12 pt-4 px-4 bg-white min-h-screen">
      
      {/* Botão Voltar */}
      <div className="mb-8">
        <Link href="/categorias" className="flex items-center gap-2 text-gray-500 hover:text-gray-900 transition-colors text-sm font-medium w-fit">
          <ArrowLeft size={18} />
          Voltar para categorias
        </Link>
      </div>

      {/* Cabeçalho */}
      <section className="flex flex-col md:flex-row gap-6 items-start md:items-center mb-10">
        <div className={`w-24 h-24 ${info.corFundoIcone} rounded-2xl flex items-center justify-center shrink-0 shadow-xs`}>
          {info.icone}
        </div>
        <div>
          <h1 className="text-3xl font-extrabold text-gray-900 mb-2">{info.nome}</h1>
          <p className="text-gray-600 text-sm leading-relaxed max-w-2xl">
            {info.descricao}
          </p>
        </div>
      </section>

      {/* Badges */}
      <section className="flex flex-col sm:flex-row gap-8 mb-12 border-y border-gray-100 py-6">
        <div className="flex items-start gap-3">
          <ShieldAlert className="text-red-600 shrink-0 mt-1" size={24} />
          <div>
            <h4 className="font-bold text-gray-900 text-sm">{info.processo}</h4>
            <p className="text-xs text-gray-500">Coleta especial por empresas autorizadas da saúde</p>
          </div>
        </div>
        <div className="flex items-start gap-3">
          <AlertTriangle className="text-amber-600 shrink-0 mt-1" size={24} />
          <div>
            <h4 className="font-bold text-gray-900 text-sm">Atenção ao Meio Ambiente</h4>
            <p className="text-xs text-gray-500">{info.alerta}</p>
          </div>
        </div>
      </section>

      {/* Abas Retráteis (Accordion) */}
      <section className="mb-10 space-y-4">
        <h2 className="text-xl font-bold text-gray-900 mb-6">Tipos de resíduos de saúde e como separar</h2>
        
        {info.subcategorias.map((sub) => (
          <AccordionItem
            key={sub.sigla}
            sigla={sub.sigla}
            titulo={sub.nomeCompleto}
            resumo={sub.aplicacao}
            corTexto={info.corBase}
            oQueE={sub.oQueE}
            usos={sub.aplicacao}
            comoSeparar={sub.comoSeparar}
            imagem={sub.imagem}
          />
        ))}
      </section>

      {/* Regras Gerais de Separação e Descarte */}
      <section>
        <h2 className="text-xl font-bold text-gray-900 mb-4">Como descartar de forma segura em casa</h2>
        <div className="bg-[#F8F9FA] rounded-3xl p-6 md:p-8">
          <ul className="space-y-4">
            {info.regrasGerais.map((regra, i) => (
              <li key={i} className="flex gap-4 items-start">
                <div className="w-8 h-8 rounded-full bg-red-50 flex items-center justify-center shrink-0 mt-0.5 border border-red-100">
                  <span className={`font-bold text-sm ${info.corBase}`}>{i + 1}</span>
                </div>
                <p className="text-gray-600 text-sm leading-relaxed pt-1">{regra}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>

    </div>
  );
}