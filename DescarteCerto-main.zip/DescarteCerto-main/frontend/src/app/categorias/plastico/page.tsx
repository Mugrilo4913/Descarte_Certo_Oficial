"use client";

import Link from "next/link";
import { ArrowLeft, Recycle, Milk, Clock } from "lucide-react";
import { AccordionItem } from "@/components/ui/accordionItem";

export default function PlasticoPage() {
  const info = {
    nome: "Plástico",
    corBase: "text-[#b03f3f]",
    corFundoIcone: "bg-[#ff9696]/20",
    descricao: "Os plásticos constituem uma categoria ampla de materiais com diferentes características químicas e propriedades físicas. Clique nos tipos abaixo para ver detalhes de uso, separação e imagens.",
    reciclavel: "Parcialmente (conforme infraestrutura)",
    decomposicao: "Mais de 100 anos na natureza",

    // Lista completa dos 7 tipos de plástico
    subcategorias: [
      {
        sigla: "PET",
        num: 1,
        nomeCompleto: "Politereftalato de etileno",
        oQueE: "Plástico transparente, leve e rígido, amplamente utilizado em embalagens descartáveis.",
        aplicacao: "Garrafas de refrigerante, água, potes de maionese, bandejas de frutas e óleos de cozinha.",
        comoSeparar: "Esvazie completamente, retire o excesso de líquido e amasse a garrafa para reduzir o volume.",
        imagem: "/images/pexels-mateusz-feliksik-1896604-11789722.jpg"
      },
      {
        sigla: "PEAD",
        num: 2,
        nomeCompleto: "Polietileno de alta densidade",
        oQueE: "Plástico opaco e muito resistente contra vazamentos de químicos e humidade.",
        aplicacao: "Frascos de produtos de limpeza, shampoo, amaciador, potes de gelado e tubos rígidos.",
        comoSeparar: "Faça uma lavagem simples se houver resíduos de produtos químicos antes de descartar.",
        imagem: "/images/pexels-shvetsa-5217896.jpg"
      },
      {
        sigla: "PVC",
        num: 3,
        nomeCompleto: "Policloreto de vinila",
        oQueE: "Plástico leve, durável e altamente resistente ao tempo e à corrosão.",
        aplicacao: "Tubos, canos, mangueiras, cortinas de casa de banho e embalagens do tipo blister.",
        comoSeparar: "Verifique a aceitação da recolha seletiva local, pois o PVC não deve ser misturado a garrafas comuns.",
        imagem: "/images/roger-starnes-sr-uSfiDo13ois-unsplash.jpg"
      },
      {
        sigla: "PEBD",
        num: 4,
        nomeCompleto: "Polietileno de baixa densidade",
        oQueE: "Plástico bastante flexível, leve e impermeável.",
        aplicacao: "Sacos de supermercado, películas plásticas protetoras e sacos de pão/alimentos.",
        comoSeparar: "Junte vários sacos limpos num único volume antes de colocar no contentor seco.",
        imagem: "/images/umesh-r-desai-64TIGsbzDoc-unsplash.jpg"
      },
      {
        sigla: "PP",
        num: 5,
        nomeCompleto: "Polipropileno",
        oQueE: "Plástico rígido e resistente a variações térmicas (pode ir ao congelador/micro-ondas).",
        aplicacao: "Tampas, potes de margarina/iogurte, copos rígidos e recipientes reutilizáveis.",
        comoSeparar: "Remova rótulos de papel e excesso de gordura/alimentos do pote.",
        imagem: "/images/Polipropileno.jpg"
      },
      {
        sigla: "PS",
        num: 6,
        nomeCompleto: "Poliestireno (Esferovite)",
        oQueE: "Plástico rígido quando compacto ou leve e isolante quando expandido.",
        aplicacao: "Copos descartáveis, talheres de plástico, caixas de CD e cuvetes de esferovite.",
        comoSeparar: "Limpe restos de alimentos das cuvetes sem as partir em pedaços pequenos.",
        imagem: "/images/pexels-ron-lach-7829819.jpg"
      },
      {
        sigla: "OUTROS",
        num: 7,
        nomeCompleto: "Outros plásticos / Multicamadas",
        oQueE: "Polímeros misturados, acrílicos ou embalagens laminadas com alumínio.",
        aplicacao: "Embalagens de batatas fritas/café, garrafas rígidas de água, biberões e eletrodomésticos.",
        comoSeparar: "Possui reciclabilidade restrita; consulte cooperativas locais ou destine ao lixo comum.",
        imagem: "/images/pexels-ali-dashti-506667798-17181359.jpg"
      }
    ],

    regrasGerais: [
      "Esvazie todas as embalagens e retire o excesso de produtos.",
      "Realize uma lavagem simples seguida de secagem quando houver gordura ou restos orgânicos.",
      "Separe contaminantes para preservar a qualidade da matéria-prima."
    ]
  };

  return (
    <div className="flex flex-col max-w-[900px] w-full mx-auto pb-12 pt-4 px-4 bg-white min-h-screen">
      
      {/* Botão Voltar */}
      <div className="mb-8">
        <Link href="/categorias" className="flex items-center gap-2 text-gray-500 hover:text-gray-900 transition-colors text-sm font-medium w-fit">
          <ArrowLeft size={18} />
          Voltar para categorias
        </Link>
      </div>

      {/* Cabeçalho da Categoria */}
      <section className="flex flex-col md:flex-row gap-6 items-start md:items-center mb-10">
        <div className={`w-24 h-24 ${info.corFundoIcone} rounded-2xl flex items-center justify-center shrink-0`}>
          <Milk size={40} className="text-[#b03f3f]" />
        </div>
        <div>
          <h1 className="text-3xl font-extrabold text-gray-900 mb-2">{info.nome}</h1>
          <p className="text-gray-600 text-sm leading-relaxed max-w-2xl">
            {info.descricao}
          </p>
        </div>
      </section>

      {/* Badges de Informação */}
      <section className="flex flex-col sm:flex-row gap-8 mb-12 border-y border-gray-100 py-6">
        <div className="flex items-start gap-3">
          <Recycle className="text-green-500 shrink-0 mt-1" size={24} />
          <div>
            <h4 className="font-bold text-gray-900 text-sm">{info.reciclavel}</h4>
            <p className="text-xs text-gray-500">Clique nos itens abaixo para conferir os detalhes</p>
          </div>
        </div>
        <div className="flex items-start gap-3">
          <Clock className="text-green-500 shrink-0 mt-1" size={24} />
          <div>
            <h4 className="font-bold text-gray-900 text-sm">Tempo de decomposição</h4>
            <p className="text-xs text-gray-500">{info.decomposicao}</p>
          </div>
        </div>
      </section>

      {/* Seção de Tipos Diferentes (Accordion Retrátil Reutilizável) */}
      <section className="mb-10 space-y-4">
        <h2 className="text-xl font-bold text-gray-900 mb-6">Tipos de materiais e como separar</h2>
        
        {info.subcategorias.map((sub) => (
          <AccordionItem
            key={sub.sigla}
            sigla={sub.sigla}
            titulo={sub.nomeCompleto}
            resumo={sub.aplicacao}
            corTexto={info.corBase}
            oQueE={sub.oQueE}
            usos={sub.aplicacao}
            comoSeparar={sub.comoSeparar}
            imagem={sub.imagem}
          />
        ))}
      </section>

      {/* Regras Gerais de Separação */}
      <section>
        <h2 className="text-xl font-bold text-gray-900 mb-4">Como separar corretamente em casa</h2>
        <div className="bg-white border border-gray-100 shadow-sm rounded-3xl p-6">
          <ul className="space-y-3">
            {info.regrasGerais.map((regra, i) => (
              <li key={i} className="flex items-center gap-3 text-sm text-gray-600">
                <div className={`w-2 h-2 rounded-full ${info.corBase} bg-current`} />
                {regra}
              </li>
            ))}
          </ul>
        </div>
      </section>

    </div>
  );
}