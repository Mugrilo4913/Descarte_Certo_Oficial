"use client";

import Link from "next/link";
import { ArrowLeft, Trash2, ShieldAlert, Clock } from "lucide-react";
import { AccordionItem } from "@/components/ui/accordionItem"; // Componente de abas retráteis

export default function NaoReciclaveisPage() {
  // CONFIGURAÇÃO DA CATEGORIA: NÃO RECICLÁVEIS E REJEITOS
  const info = {
    nome: "Não Recicláveis e Rejeitos",
    corBase: "text-[#6C757D]", // Cinza oficial do CONAMA (Resolução 275/2001)
    corFundoIcone: "bg-[#E9ECEF]",
    icone: <Trash2 size={40} className="text-[#6C757D]" />,
    descricao: "Resíduos que não possuem possibilidade de recuperação ou reciclagem nas condições técnicas e econômicas atuais, devendo ser destinados ao aterro sanitário.",
    processo: "Disposição Final (Aterro Sanitário)",
    decomposicao: "Variável (Conforme o tipo de material)",
    
    // Top 3 Não-Recicláveis de cada categoria (7 categorias = 21 itens de rejeitos)
    subcategorias: [
      // 1. PLÁSTICOS
      {
        sigla: "P-ESP",
        nomeCompleto: "Esponjas de Lavar Louça",
        oQueE: "Feitas de poliuretano e fibras sintéticas entrelaçadas contaminadas por sabão e sujeira.",
        aplicacao: "Limpeza diária de louças, pias e superfícies da cozinha.",
        comoSeparar: "Não possuem viabilidade técnica de reciclagem na coleta comum. Descarte no lixo comum de rejeitos.",
        imagem: "/images/nao-reciclavel-esponja.png"
      },
      {
        sigla: "P-ADES",
        nomeCompleto: "Fitas Adesivas e Durex",
        oQueE: "Filmes plásticos recobertos por cola adesiva de alta fixação sintética.",
        aplicacao: "Fechamento de caixas, trabalhos escolares e empacotamento.",
        comoSeparar: "A cola contamina as máquinas de reciclagem de plástico. Descarte na lixeira de rejeitos cinza.",
        imagem: "/images/nao-reciclavel-durex.png"
      },
      {
        sigla: "P-EMB",
        nomeCompleto: "Embalagens Plastificadas e Metalizadas (Snacks)",
        oQueE: "Plásticos laminados compostos por mistura de filme plástico e alumínio (BOPP).",
        aplicacao: "Sacos de salgadinhos, batatas palha, biscoitos e embalagens de café.",
        comoSeparar: "Devido à fusão de plástico com metal, são extremamente difíceis de separar na triagem. Vão para o lixo comum.",
        imagem: "/images/nao-reciclavel-salgadinho.png"
      },

      // 2. VIDROS
      {
        sigla: "V-CER",
        nomeCompleto: "Louças, Cerâmicas e Porcelanas",
        oQueE: "Materiais cerâmicos com ponto de fusão muito superior ao vidro comum soda-cálcico.",
        aplicacao: "Pratos quebrados, xícaras, canecas de porcelana e pisos cerâmicos.",
        comoSeparar: "Se misturados ao vidro comum, estragam o lote inteiro no forno. Embale em papelão e descarte no lixo comum.",
        imagem: "/images/nao-reciclavel-ceramica.png"
      },
      {
        sigla: "V-ESP",
        nomeCompleto: "Espelhos e Vidros Reflexivos",
        oQueE: "Vidros planos que recebem uma camada de tinta e metais como prata e alumínio no verso.",
        aplicacao: "Espelhos de banheiro, guarda-roupas e decoração.",
        comoSeparar: "A camada química metálica impede a fusão no processo de reciclagem de vidros de garrafas. Descarte no lixo comum.",
        imagem: "/images/nao-reciclavel-espelho.png"
      },
      {
        sigla: "V-PYR",
        nomeCompleto: "Vidros Temperados e Pirex (Pyrex)",
        oQueE: "Vidros refratários com adição de boro desenvolvidos para resistir a altas temperaturas.",
        aplicacao: "Travessas de ir ao forno, tampas de panela de vidro e copos temperados.",
        comoSeparar: "Não derretem na mesma temperatura das garrafas de vidro. Embale os cacos e coloque no lixo comum.",
        imagem: "/images/nao-reciclavel-pyrex.png"
      },

      // 3. PAPÉIS
      {
        sigla: "PA-HIG",
        nomeCompleto: "Papel Higiênico e Lenços de Papel",
        oQueE: "Papéis sanitários de fibra curta contaminados por fluidos e matéria orgânica.",
        aplicacao: "Higiene pessoal do banheiro e limpeza de mucosa nasal.",
        comoSeparar: "Nunca vão para a reciclagem. Devem ir direto para o lixo do banheiro bem ensacados.",
        imagem: "/images/nao-reciclavel-papel-higienico.png"
      },
      {
        sigla: "PA-ENG",
        nomeCompleto: "Papéis Engordurados ou Engraxados",
        oQueE: "Papéis e papelões que absorveram óleo, gorduras de comida ou graxa.",
        aplicacao: "Fundo de caixas de pizza engorduradas, guardanapos sujos de comida e embalagens de hambúrguer.",
        comoSeparar: "A gordura impede a aglutinação das fibras de papel na água durante a reciclagem. Descarte a parte engordurada no lixo comum.",
        imagem: "/images/nao-reciclavel-papel-engordurado.png"
      },
      {
        sigla: "PA-CAR",
        nomeCompleto: "Papel Carbono, Térmico e Fotografias",
        oQueE: "Papéis revestidos com ceras químicas, reagentes de BPA ou filmes plásticos fotográficos.",
        aplicacao: "Comprovantes de cartão de crédito/extratos, notas fiscais térmicas e fotos impressas.",
        comoSeparar: "Os compostos químicos inviabilizam o reprocessamento de papel limpo. Descarte na lixeira cinza.",
        imagem: "/images/nao-reciclavel-papel-termico.png"
      },

      // 4. METAIS
      {
        sigla: "M-PAL",
        nomeCompleto: "Esponjas de Aço (Palha de Aço)",
        oQueE: "Fios extremamente finos de aço carbono que oxidam e enferrujam rapidamente.",
        aplicacao: "Limpeza pesada de panelas, grelhas e remoção de incrustações.",
        comoSeparar: "Desagregam-se e viram ferrugem na água de lavagem da triagem. Descarte no lixo comum.",
        imagem: "/images/nao-reciclavel-palha-aco.png"
      },
      {
        sigla: "M-TIN",
        nomeCompleto: "Latas de Tinta e Solventes com Resíduo Seco",
        oQueE: "Recipientes metálicos impregnados com restos de tintas acrílicas ou esmaltes sintéticos secos.",
        aplicacao: "Sobras de tinta de pintura de paredes e reformas residenciais.",
        comoSeparar: "Resíduos de solventes e tintas secas contaminam a fundição de sucata limpa. Devem ser levados a ecopontos de tinta ou rejeitos.",
        imagem: "/images/nao-reciclavel-lata-tinta.png"
      },
      {
        sigla: "M-LAMIN",
        nomeCompleto: "Embalagens de Alumínio Contaminadas",
        oQueE: "Marmitex ou papéis alumínio crostados com restos incrustados de comida queimada.",
        aplicacao: "Sobras de assados em papel alumínio e quentinhas de marmita.",
        comoSeparar: "Se não puderem ser lavadas, a matéria orgânica queima nos fornos gerando gases poluentes. Descarte no lixo comum.",
        imagem: "/images/nao-reciclavel-marmitex-sujo.png"
      },

      // 5. MADEIRA
      {
        sigla: "MA-TRAT",
        nomeCompleto: "Madeiras Tratadas com Inseticidas (CCA/PCP)",
        oQueE: "Madeiras quimicamente tratadas em autoclaves contra cupins e umidade.",
        aplicacao: "Mourões de cerca, cruzetas de poste e madeira compensada naval.",
        comoSeparar: "Não podem ser queimadas ou compostadas devido aos venenos pesados impregnados. Vão para aterros específicos de rejeitos.",
        imagem: "/images/nao-reciclavel-madeira-tratada.png"
      },
      {
        sigla: "MA-PIN",
        nomeCompleto: "Madeira Pintada com Tintas a Óleo e Vernizes",
        oQueE: "Peças revestidas por camadas espessas de tintas sintéticas, laqueados ou resinas.",
        aplicacao: "Portas antigas pintadas, móveis laqueados trincados e dejetos de demolição.",
        comoSeparar: "Inviabilizam o reuso de cavacos limpos para biomassa. Devem ir para caçambas de entulho e aterro civil.",
        imagem: "/images/nao-reciclavel-madeira-pintada.png"
      },
      {
        sigla: "MA-COMP",
        nomeCompleto: "Compensados Podres ou Mofados com Cupim",
        oQueE: "Placas de aglomerado/MDF degradadas pela umidade e atacadas por pragas.",
        aplicacao: "Móveis velhos de MDF estufados por água da chuva.",
        comoSeparar: "A cola sintética deteriorada e os fungos impedem qualquer trituração segura. Encaminhe ao cata-treco ou aterro.",
        imagem: "/images/nao-reciclavel-mdf-podre.png"
      },

      // 6. ORGÂNICOS
      {
        sigla: "O-ABS",
        nomeCompleto: "Fraldas Descartáveis e Absorventes",
        oQueE: "Produtos plásticos com géis superabsorventes contaminados por urina e sangue.",
        aplicacao: "Higiene de bebês, adultos acamados e ciclo menstrual.",
        comoSeparar: "Não entram em composteiras nem na reciclagem seca. Vão diretamente para o lixo comum bem fechados.",
        imagem: "/images/nao-reciclavel-fraldas.png"
      },
      {
        sigla: "O-PET",
        nomeCompleto: "Fezes de Animais de Estimação e Areia de Gato",
        oQueE: "Excrementos de cães e gatos misturados a minerais de areia sanitária ou sílica.",
        aplicacao: "Limpeza diária de caixas de areia de gatos e fezes de cães.",
        comoSeparar: "Podem conter parasitas (como toxoplasmose). Nunca coloque em composteiras caseiras; embale bem e descarte no lixo comum.",
        imagem: "/images/nao-reciclavel-areia-gato.png"
      },
      {
        sigla: "O-CIN",
        nomeCompleto: "Cinzas de Churrasqueira e Cigarro",
        oQueE: "Resíduos da queima de carvão vegetal com gordura animal ou filtros de cigarro com nicotina.",
        aplicacao: "Sobras de carvão de churrasco e bitucas de cigarro de cinzeiros.",
        comoSeparar: "Filtros de cigarro contêm plásticos e compostos tóxicos. Cinzas de churrasco engorduradas devem ir bem frias para o lixo comum.",
        imagem: "/images/nao-reciclavel-cinzas.png"
      },

      // 7. SAÚDE
      {
        sigla: "S-INF",
        nomeCompleto: "Materiais de Doenças Contagiosas (Infectantes)",
        oQueE: "Resíduos biológicos provenientes do isolamento de doentes com infecções transmissíveis.",
        aplicacao: "Máscaras, gazes e lenços usados por pessoas com doenças infecciosas graves em casa.",
        comoSeparar: "Devam ser embalados em saco vermelho/branco duplo reforçado e lacrado para coleta especial ou lixo de rejeito controlado.",
        imagem: "/images/nao-reciclavel-infectante.png"
      },
      {
        sigla: "S-PRES",
        nomeCompleto: "Preservativos e Dispositivos de Contracepção",
        oQueE: "Itens de látex e silicone contaminados por fluidos corporais.",
        aplicacao: "Saúde sexual e contracepção.",
        comoSeparar: "Envolva em papel higiênico e descarte exclusivamente na lixeira do banheiro (lixo comum).",
        imagem: "/images/nao-reciclavel-preservativo.png"
      },
      {
        sigla: "S-AFI",
        nomeCompleto: "Lâminas de Barbear e Estiletes Descartáveis",
        oQueE: "Lâminas metálicas amoladas usadas em cuidados pessoais ou artesanato.",
        aplicacao: "Barbeadores descartáveis de plástico/metal e lâminas de corte.",
        comoSeparar: "Guarde dentro de um recipiente plástico rígido ou lata antes de colocar no lixo comum para proteger os garis de acidentes.",
        imagem: "/images/nao-reciclavel-lamina.png"
      }
    ],

    // Regras gerais adaptadas do documento oficial
    regrasGerais: [
      "Papéis sanitários e de higiene: papel higiênico, lenços de papel, guardanapos engordurados, fraldas descartáveis e absorventes vão diretamente para o lixo comum.",
      "Materiais contaminados por engorduramento: papéis e embalagens sujos de comida ou óleo perdem a reciclabilidade e viram rejeitos.",
      "Plásticos e vidros especiais não recicláveis: fitas adesivas, esponjas, espelhos, cerâmicas, louças e pirex não entram na coleta seletiva convencional.",
      "Acondicionamento correto: embale bem os sacos para evitar vazamento de líquidos ou odores e coloque na lixeira cinza para a coleta domiciliar municipal."
    ]
  };

  return (
    <div className="flex flex-col max-w-[900px] w-full mx-auto pb-12 pt-4 px-4 bg-white min-h-screen">
      
      {/* Botão Voltar */}
      <div className="mb-8">
        <Link href="/categorias" className="flex items-center gap-2 text-gray-500 hover:text-gray-900 transition-colors text-sm font-medium w-fit">
          <ArrowLeft size={18} />
          Voltar para categorias
        </Link>
      </div>

      {/* Cabeçalho */}
      <section className="flex flex-col md:flex-row gap-6 items-start md:items-center mb-10">
        <div className={`w-24 h-24 ${info.corFundoIcone} rounded-2xl flex items-center justify-center shrink-0 shadow-xs`}>
          {info.icone}
        </div>
        <div>
          <h1 className="text-3xl font-extrabold text-gray-900 mb-2">{info.nome}</h1>
          <p className="text-gray-600 text-sm leading-relaxed max-w-2xl">
            {info.descricao}
          </p>
        </div>
      </section>

      {/* Badges */}
      <section className="flex flex-col sm:flex-row gap-8 mb-12 border-y border-gray-100 py-6">
        <div className="flex items-start gap-3">
          <ShieldAlert className="text-gray-600 shrink-0 mt-1" size={24} />
          <div>
            <h4 className="font-bold text-gray-900 text-sm">{info.processo}</h4>
            <p className="text-xs text-gray-500">Coleta domiciliar regular da prefeitura</p>
          </div>
        </div>
        <div className="flex items-start gap-3">
          <Clock className="text-gray-600 shrink-0 mt-1" size={24} />
          <div>
            <h4 className="font-bold text-gray-900 text-sm">Tempo de decomposição</h4>
            <p className="text-xs text-gray-500">{info.decomposicao}</p>
          </div>
        </div>
      </section>

      {/* Abas Retráteis (Accordion com Top 3 não recicláveis por categoria) */}
      <section className="mb-10 space-y-4">
        <h2 className="text-xl font-bold text-gray-900 mb-6">Materiais não recicláveis por categoria (Lixeira Cinza)</h2>
        
        {info.subcategorias.map((sub) => (
          <AccordionItem
            key={sub.sigla}
            sigla={sub.sigla}
            titulo={sub.nomeCompleto}
            resumo={sub.aplicacao}
            corTexto={info.corBase}
            oQueE={sub.oQueE}
            usos={sub.aplicacao}
            comoSeparar={sub.comoSeparar}
            imagem={sub.imagem}
          />
        ))}
      </section>

      {/* Regras Gerais de Descarte */}
      <section>
        <h2 className="text-xl font-bold text-gray-900 mb-4">O que entra na lixeira cinza e como descartar</h2>
        <div className="bg-[#F8F9FA] rounded-3xl p-6 md:p-8">
          <ul className="space-y-4">
            {info.regrasGerais.map((regra, i) => (
              <li key={i} className="flex gap-4 items-start">
                <div className="w-8 h-8 rounded-full bg-[#E9ECEF] flex items-center justify-center shrink-0 mt-0.5 border border-gray-200">
                  <span className={`font-bold text-sm ${info.corBase}`}>{i + 1}</span>
                </div>
                <p className="text-gray-600 text-sm leading-relaxed pt-1">{regra}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>

    </div>
  );
}