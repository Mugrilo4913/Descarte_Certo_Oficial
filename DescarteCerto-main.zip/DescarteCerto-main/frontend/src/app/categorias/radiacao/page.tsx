"use client";

import Link from "next/link";
import { ArrowLeft, Radio, ShieldAlert, Clock, PhoneCall } from "lucide-react";
import { AccordionItem } from "@/components/ui/accordionItem";

export default function RadioativoPage() {
  // RESÍDUOS RADIOATIVOS
  const info = {
    nome: "Resíduos Radioativos",
    corBase: "text-[#7E5AA9]",
    corFundoIcone: "bg-[#F5EEF8]",
    icone: <Radio size={40} className="text-[#7E5AA9]" />,
    descricao: "Resíduos que apresentam características de radiação e exigem gerenciamento e procedimentos extremamente específicos de contenção.",
    processo: "Manejo Especializado e Normatizado",
    decomposicao: "Variável (Decaimento radioativo)",

    subcategorias: [
      {
        sigla: "MED",
        nomeCompleto: "Resíduos de Medicina Nuclear e Radioterapia",
        oQueE: "Insumos, seringas, frascos e materiais contaminados com radioisótopos durante exames e tratamentos de saúde.",
        aplicacao: "Tratamentos hospitalares, cintilografias, exames de PET scan e tratamentos radioterápicos.",
        comoSeparar: "Devem ser segregados em recipientes blindados especiais dentro do próprio hospital para decaimento da radiação.",
        imagem: "/images/radiacao/radioativo-medicina.jpg"
      },
      {
        sigla: "DET",
        nomeCompleto: "Detectores de Fumaça Iônicos Antigos",
        oQueE: "Equipamentos antigos (décadas de 1970 a 1990) que contêm uma microcápsula de Amerício-241.",
        aplicacao: "Sistemas de alarme de incêndio em edifícios residenciais e comerciais antigos.",
        comoSeparar: "Nunca abra ou desmonte a cápsula interna. O descarte deve ser feito via logística reversa especializada com o fabricante.",
        imagem: "/images/radiacao/radioativo-detectores.jpg"
      },
      {
        sigla: "PAR",
        nomeCompleto: "Pára-raios Radioativos (Radioisotópicos)",
        oQueE: "Pára-raios instalados até 1989 no topo de prédios contendo Césio-137 ou Amerício-241.",
        aplicacao: "Proteção contra descargas elétricas em edifícios antigos (proibidos por lei no Brasil).",
        comoSeparar: "Sua remoção e transporte só podem ser feitos por empresas credenciadas junto à CNEN com laudo técnico.",
        imagem: "/images/radiacao/radioativo-pararaios.jpg"
      },
      {
        sigla: "IND",
        nomeCompleto: "Fontes Seladas e Equipamentos Industriais",
        oQueE: "Fontes radioativas seladas usadas em medidores de densidade e gammagrafia de soldas.",
        aplicacao: "Inspeção de tubulações, controle de qualidade de aço e medição de espessura.",
        comoSeparar: "Exigem inventário rigoroso e devem ser entregues diretamente aos depósitos autorizados da CNEN ao final da vida útil.",
        imagem: "/images/radiacao/radioativo-industrial.jpg"
      },
      {
        sigla: "REL",
        nomeCompleto: "Mostradores e Bússolas Antigas (Rádio/Trítio)",
        oQueE: "Objetos antigos (anos 1920 a 1960) pintados com tinta luminescente que brilha no escuro.",
        aplicacao: "Relógios de pulso antigos, bússolas militares vintage e manômetros de aviação.",
        comoSeparar: "Não abra o vidro para não inalar ou tocar no pó da tinta. Guarde o objeto selado e consulte órgãos de controle.",
        imagem: "/images/radiacao/radioativo-relogio.jpg"
      }
    ],

    // Protocolos de O Que Fazer
    instrucoesSeguranca: [
      {
        titulo: "NUNCA jogue no lixo comum ou na coleta seletiva",
        desc: "Esses materiais não podem ir para o lixo doméstico, aterros municipais ou cooperativas de reciclagem."
      },
      {
        titulo: "NÃO tente abrir, quebrar ou desmontar",
        desc: "A estrutura externa do aparelho bloqueia a radiação. Abrir a peça pode liberar pós ou gases contaminantes por inalação."
      },
      {
        titulo: "Isole a peça em local seguro",
        desc: "Se possuir um objeto suspeito ou antigo em casa, guarde-o numa caixa bem fechada, longe de locais com grande circulação de pessoas."
      }
    ],

    // Órgãos para contatar
    contatosOficiais: [
      {
        orgao: "CNEN (Comissão Nacional de Energia Nuclear)",
        funcao: "Órgão federal regulador responsável pela gestão, orientação e recolhimento de rejeitos radioativos no Brasil."
      },
      {
        orgao: "Corpo de Bombeiros (193) ou Defesa Civil (199)",
        funcao: "Acione imediatamente caso encontre um objeto abandonado com o símbolo internacional de radioatividade (trevo de três pás)."
      },
      {
        orgao: "Empresas Especializadas Credenciadas",
        funcao: "Para remoções estruturais complexas (como a retirada de pára-raios radioativos em edifícios)."
      }
    ]
  };

  return (
    <div className="flex flex-col max-w-[900px] w-full mx-auto pb-12 pt-4 px-4 bg-white min-h-screen">
      
      {/* Botão Voltar */}
      <div className="mb-8">
        <Link href="/categorias" className="flex items-center gap-2 text-gray-500 hover:text-gray-900 transition-colors text-sm font-medium w-fit">
          <ArrowLeft size={18} />
          Voltar para categorias
        </Link>
      </div>

      {/* Cabeçalho */}
      <section className="flex flex-col md:flex-row gap-6 items-start md:items-center mb-10">
        <div className={`w-24 h-24 ${info.corFundoIcone} rounded-2xl flex items-center justify-center shrink-0`}>
          {info.icone}
        </div>
        <div>
          <h1 className="text-3xl font-extrabold text-gray-900 mb-2">{info.nome}</h1>
          <p className="text-gray-600 text-sm leading-relaxed max-w-2xl">
            {info.descricao}
          </p>
        </div>
      </section>

      {/* Badges */}
      <section className="flex flex-col sm:flex-row gap-8 mb-12 border-y border-gray-100 py-6">
        <div className="flex items-start gap-3">
          <ShieldAlert className="text-purple-700 shrink-0 mt-1" size={24} />
          <div>
            <h4 className="font-bold text-gray-900 text-sm">{info.processo}</h4>
            <p className="text-xs text-gray-500">Isolamento e controle rigoroso de segurança</p>
          </div>
        </div>
        <div className="flex items-start gap-3">
          <Clock className="text-purple-700 shrink-0 mt-1" size={24} />
          <div>
            <h4 className="font-bold text-gray-900 text-sm">Tempo de decaimento</h4>
            <p className="text-xs text-gray-500">{info.decomposicao}</p>
          </div>
        </div>
      </section>

      {/* Abas Retráteis (Accordion) */}
      <section className="mb-10 space-y-4">
        <h2 className="text-xl font-bold text-gray-900 mb-6">Origem dos resíduos e objetos de atenção</h2>
        
        {info.subcategorias.map((sub) => (
          <AccordionItem
            key={sub.sigla}
            sigla={sub.sigla}
            titulo={sub.nomeCompleto}
            resumo={sub.aplicacao}
            corTexto={info.corBase}
            oQueE={sub.oQueE}
            usos={sub.aplicacao}
            comoSeparar={sub.comoSeparar}
            imagem={sub.imagem}
          />
        ))}
      </section>

      {/* Como Proceder (O Que Fazer) */}
      <section className="mb-10">
        <h2 className="text-xl font-bold text-gray-900 mb-4">Como proceder e o que fazer</h2>
        <div className="bg-[#F8F9FA] rounded-3xl p-6 md:p-8">
          <div className="space-y-6">
            {info.instrucoesSeguranca.map((item, index) => (
              <div key={index} className="flex gap-4">
                <div className="w-8 h-8 rounded-full bg-[#F5EEF8] flex items-center justify-center shrink-0 mt-0.5">
                  <span className={`font-bold text-sm ${info.corBase}`}>{index + 1}</span>
                </div>
                <div>
                  <h3 className="font-bold text-gray-900 text-sm mb-1">{item.titulo}</h3>
                  <p className="text-gray-600 text-sm leading-relaxed">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Quem Chamar */}
      <section>
        <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
          <PhoneCall size={22} className="text-[#7E5AA9]" />
          Quem contatar
        </h2>
        <div className="bg-[#F5EEF8] border border-purple-100 rounded-3xl p-6 md:p-8 space-y-4">
          {info.contatosOficiais.map((contato, i) => (
            <div key={i} className="bg-white p-4 rounded-2xl border border-purple-100 shadow-2xs">
              <h3 className="font-bold text-gray-900 text-sm mb-1">{contato.orgao}</h3>
              <p className="text-gray-600 text-xs leading-relaxed">{contato.funcao}</p>
            </div>
          ))}
        </div>
      </section>

    </div>
  );
}