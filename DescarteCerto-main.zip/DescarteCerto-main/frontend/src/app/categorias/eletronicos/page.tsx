"use client";

import Link from "next/link";
import { ArrowLeft, Battery, ShieldAlert, Clock } from "lucide-react";
import { AccordionItem } from "@/components/ui/accordionItem"; // Import do seu componente reutilizável

export default function PilhasEEletronicosPage() {
  const info = {
    nome: "Eletrônicos",
    corBase: "text-[#BC4700]",
    corFundoIcone: "bg-[#F7D2B5]",
    icone: <Battery size={40} className="text-[#BC4700]" />,
    descricao: "Materiais que exigem atenção específica devido à presença de metais pesados, plásticos e componentes eletrônicos que não devem ser misturados ao lixo comum.",
    processo: "Logística Reversa Obrigatória",
    decomposicao: "De 500 anos a indeterminado",
    
    // Lista dos eletrônicos e pilhas organizados para as abas retráteis
    subcategorias: [
      {
        sigla: "CEL",
        nomeCompleto: "Smartphones e Celulares",
        oQueE: "Dispositivos móveis com placas de circuito integrado, metais nobres e baterias de íons de lítio.",
        aplicacao: "Comunicação, fotos e navegação.",
        comoSeparar: "Faça o backup, remova o chip e restaure aos padrões de fábrica antes de entregar no posto de coleta.",
        imagem: "/images/eletronico/eletronico-celular.jpg"
      },
      {
        sigla: "PIL",
        nomeCompleto: "Pilhas e Baterias Portáteis",
        oQueE: "Resíduos perigosos com metais pesados (cádmio, chumbo, níquel) e soluções eletrolíticas.",
        aplicacao: "Controles remotos, brinquedos, relógios e fechaduras digitais.",
        comoSeparar: "Armazene em local seco em casa e leve a coletores de pilhas (laranja) em supermercados ou farmácias.",
        imagem: "/images/eletronico/eletronico-pilhas.jpg"
      },
      {
        sigla: "CAB",
        nomeCompleto: "Carregadores e Cabos",
        oQueE: "Fios de cobre revestidos de plástico flexível (PVC/PE) e pequenos transformadores.",
        aplicacao: "Alimentação e transferência de dados entre aparelhos.",
        comoSeparar: "Enrole sem dobrar com força os conectores e destine à caixa de pequenos eletrônicos.",
        imagem: "/images/eletronico/eletronico-cabos.jpg"
      },
      {
        sigla: "FON",
        nomeCompleto: "Fones de Ouvido (Com e Sem Fio)",
        oQueE: "Acessórios eletrônicos contendo minúsculos alto-falantes e microbaterias de lítio.",
        aplicacao: "Reprodução de áudio e chamadas.",
        comoSeparar: "Modelos sem fio devem ser descartados com a caixinha recarregável (case) intacta para evitar perfuração da bateria.",
        imagem: "/images/eletronico/eletronico-fones.jpg"
      },
      {
        sigla: "NOT",
        nomeCompleto: "Notebooks e Tablets",
        oQueE: "Computadores portáteis com tela LCD/LED, baterias seladas e placas de circuito.",
        aplicacao: "Trabalho, estudos e navegação.",
        comoSeparar: "Nunca tente remover a bateria interna colada em casa. Entregue o aparelho inteiro no ecoponto.",
        imagem: "/images/eletronico/eletronico-notebook.jpg"
      },
      {
        sigla: "PER",
        nomeCompleto: "Periféricos (Teclados, Mouses e Roteadores)",
        oQueE: "Equipamentos de informática compostos de plástico rígido (ABS/PS) e circuitos.",
        aplicacao: "Navegação e entrada de dados no computador.",
        comoSeparar: "Junte os cabos ao aparelho e entregue em postos de logística reversa de linha verde.",
        imagem: "/images/eletronico/eletronico-perifericos.jpg"
      },
      {
        sigla: "ELET",
        nomeCompleto: "Pequenos Eletrodomésticos",
        oQueE: "Liquidificadores, batedeiras e secadores contendo motores de cobre e carcaça plástica.",
        aplicacao: "Preparo de alimentos e cuidados pessoais.",
        comoSeparar: "Separe partes de vidro trincadas (como jarras) e entregue a estrutura elétrica no ecoponto.",
        imagem: "/images/eletronico/eletronico-eletro.jpg"
      }
    ],

    regrasGerais: [
      "NUNCA descarte em lixeiras coloridas da coleta seletiva convencional nem no lixo comum.",
      "Mantenha os aparelhos inteiros: não desmonte carcaças nem quebre pilhas para evitar vazamento de substâncias tóxicas.",
      "Procure pontos de Logística Reversa em lojas de eletrônicos, supermercados, assistências técnicas ou ecopontos da prefeitura."
    ]
  };

  return (
    <div className="flex flex-col max-w-[900px] w-full mx-auto pb-12 pt-4 px-4 bg-white min-h-screen">
      
      {/* Botão Voltar */}
      <div className="mb-8">
        <Link href="/categorias" className="flex items-center gap-2 text-gray-500 hover:text-gray-900 transition-colors text-sm font-medium w-fit">
          <ArrowLeft size={18} />
          Voltar para categorias
        </Link>
      </div>

      {/* Cabeçalho da Categoria */}
      <section className="flex flex-col md:flex-row gap-6 items-start md:items-center mb-10">
        <div className={`w-24 h-24 ${info.corFundoIcone} rounded-2xl flex items-center justify-center shrink-0`}>
          {info.icone}
        </div>
        <div>
          <h1 className="text-3xl font-extrabold text-gray-900 mb-2">{info.nome}</h1>
          <p className="text-gray-600 text-sm leading-relaxed max-w-2xl">
            {info.descricao}
          </p>
        </div>
      </section>

      {/* Badges de Informação */}
      <section className="flex flex-col sm:flex-row gap-8 mb-12 border-y border-gray-100 py-6">
        <div className="flex items-start gap-3">
          <ShieldAlert className="text-[#BC4700] shrink-0 mt-1" size={24} />
          <div>
            <h4 className="font-bold text-gray-900 text-sm">{info.processo}</h4>
            <p className="text-xs text-gray-500">Recuperação de peças e destinação segura de metais</p>
          </div>
        </div>
        <div className="flex items-start gap-3">
          <Clock className="text-[#BC4700] shrink-0 mt-1" size={24} />
          <div>
            <h4 className="font-bold text-gray-900 text-sm">Tempo de decomposição</h4>
            <p className="text-xs text-gray-500">{info.decomposicao}</p>
          </div>
        </div>
      </section>

      {/* Abas Retráteis (Accordion) */}
      <section className="mb-10 space-y-4">
        <h2 className="text-xl font-bold text-gray-900 mb-6">Tipos de eletrônicos e como separar</h2>
        
        {info.subcategorias.map((sub) => (
          <AccordionItem
            key={sub.sigla}
            sigla={sub.sigla}
            titulo={sub.nomeCompleto}
            resumo={sub.aplicacao}
            corTexto={info.corBase}
            oQueE={sub.oQueE}
            usos={sub.aplicacao}
            comoSeparar={sub.comoSeparar}
            imagem={sub.imagem}
          />
        ))}
      </section>

      {/* Regras Gerais de Separação */}
      <section>
        <h2 className="text-xl font-bold text-gray-900 mb-4">Regras essenciais para o descarte</h2>
        <div className="bg-white border border-gray-100 shadow-sm rounded-3xl p-6">
          <ul className="space-y-3">
            {info.regrasGerais.map((regra, i) => (
              <li key={i} className="flex items-center gap-3 text-sm text-gray-600">
                <div className={`w-2 h-2 rounded-full ${info.corBase} bg-current shrink-0`} />
                {regra}
              </li>
            ))}
          </ul>
        </div>
      </section>

    </div>
  );
}