"use client";

import Link from "next/link";
import { ArrowLeft, Wrench, Recycle, Clock } from "lucide-react";
import { AccordionItem } from "@/components/ui/accordionItem"; // Componente de abas retráteis

export default function MetaisPage() {
  // CONFIGURAÇÃO DA CATEGORIA: METAIS
  const info = {
    nome: "Metais",
    corBase: "text-[#D9A406]", // Amarelo oficial do CONAMA (Resolução 275/2001)
    corFundoIcone: "bg-[#FEF9E7]",
    icone: <Wrench size={40} className="text-[#D9A406]" />,
    descricao: "Os metais possuem altíssimo potencial de recuperação, reduzindo significativamente a necessidade de extração de matérias-primas virgens.",
    processo: "100% Reciclável (Alumínio e Aço)",
    decomposicao: "100 a mais de 500 anos",
    
    // Top 10 Subcategorias de metais recicláveis do dia a dia
    subcategorias: [
      {
        sigla: "ALU",
        nomeCompleto: "Latas de Alumínio (Bebidas)",
        oQueE: "Um dos materiais mais reciclados do mundo, com ciclo de reaproveitamento extremamente rápido.",
        aplicacao: "Latas de refrigerante, cerveja, sucos, chás e água tônica.",
        comoSeparar: "Esvazie completamente e amasse a lata para otimizar espaço de armazenamento na coleta amarela.",
        imagem: "/images/metal-latas-aluminio.png"
      },
      {
        sigla: "AÇO",
        nomeCompleto: "Latas de Aço / Flandres (Conservas)",
        oQueE: "Embalagens rígidas magnéticas de aço estanhado altamente recicláveis.",
        aplicacao: "Latas de molho de tomate, milho, ervilha, sardinha, leite em pó e tintas.",
        comoSeparar: "Retire os resíduos de alimentos com água e empurre a tampa serrilhada cortante para dentro da lata.",
        imagem: "/images/metal-latas-aco.png"
      },
      {
        sigla: "AER",
        nomeCompleto: "Frascos de Aerosol de Alumínio e Aço",
        oQueE: "Tubos metálicos pressurizados usados para cosméticos e produtos de limpeza.",
        aplicacao: "Desodorantes spray, chantilly, tintas em spray e inseticidas.",
        comoSeparar: "Use o produto até o fim até esvaziar a pressão. Retire a tampa plástica e não fure ou amasse a lata.",
        imagem: "/images/metal-aerosol.png"
      },
      {
        sigla: "TAM",
        nomeCompleto: "Tampas Metálicas e Lacre de Garrafas",
        oQueE: "Pequenas peças de aço ou alumínio de vedação de garrafas e potes.",
        aplicacao: "Tampas de garrafas de vidro (cerveja/refrigerante), tampas de potes de geleia e lacres.",
        comoSeparar: "Junte as tampas menores dentro de uma lata de aço maior para que não se percam na triagem.",
        imagem: "/images/metal-tampas.png"
      },
      {
        sigla: "PAN",
        nomeCompleto: "Panelas e Utensílios de Cozinha Velhos",
        oQueE: "Utensílios metálicos de alumínio, inox ou ferro fundido em desuso.",
        aplicacao: "Panelas velhas, assadeiras, talheres de inox, escorredores e formas de bolo.",
        comoSeparar: "Remova cabos de baquelite ou plástico se possível e destine à coleta seletiva ou sucateiros.",
        imagem: "/images/metal-panelas.png"
      },
      {
        sigla: "FOL",
        nomeCompleto: "Papel Alumínio e Marmitex",
        oQueE: "Lâminas finas e flexíveis de alumínio de uso doméstico.",
        aplicacao: "Folhas de papel alumínio para assados e embalagens quentinhas/marmitex.",
        comoSeparar: "Retire os restos de alimentos e modele o alumínio em formato de bola limpa antes de descartar.",
        imagem: "/images/metal-papel-aluminio.png"
      },
      {
        sigla: "FER",
        nomeCompleto: "Ferragens e Ferramentas Manuais",
        oQueE: "Peças metálicas pesadas e ferramentas de aço ou ferro fundido.",
        aplicacao: "Pregos, parafusos, dobradiças, chaves antigas, alicates e martelos velhos.",
        comoSeparar: "Junte peças pequenas em recipientes fechados para evitar acidentes com os catadores.",
        imagem: "/images/metal-ferragens.png"
      },
      {
        sigla: "ESQ",
        nomeCompleto: "Esquadrias e Perfis de Alumínio",
        oQueE: "Estruturas leves de alumínio usadas na construção e reformas residenciais.",
        aplicacao: "Sobra de trilhos de cortina, perfis de janelas, portões quebrados e boxes.",
        comoSeparar: "Remova vidros ou borrachas presas e encaminhe para ecopontos ou cooperativas de reciclagem.",
        imagem: "/images/metal-esquadrias.png"
      },
      {
        sigla: "TUB",
        nomeCompleto: "Tubos de Alumínio (Pomadas e Pastas)",
        oQueE: "Embalagens maleáveis de alumínio usadas na indústria farmacêutica e alimentícia.",
        aplicacao: "Tubos de pomadas medicinais, extrato de tomate em bisnaga e tintas de cabelo.",
        comoSeparar: "Esvazie o conteúdo ao máximo espremendo o tubo, retire a tampa de plástico e descarte o alumínio.",
        imagem: "/images/metal-tubos.png"
      },
      {
        sigla: "CAB",
        nomeCompleto: "Fios e Cabos de Cobre/Alumínio",
        oQueE: "Condutores elétricos metálicos com ou sem isolamento emborrachado.",
        aplicacao: "Fios elétricos de reformas, cabos de extensão e fiação interna de eletrodomésticos.",
        comoSeparar: "Não há necessidade de descascar a borracha em casa; as usinas de reciclagem separam os materiais por trituração.",
        imagem: "/images/metal-fios.png"
      }
    ],

    // Regras gerais adaptadas do documento oficial
    regrasGerais: [
      "Identifique os materiais metálicos: latas de alumínio, latas de aço, tampas, panelas, fios e ferragens.",
      "Esvazie e retire resíduos: retire o excesso de alimentos com uma limpeza simples usando pouca água para evitar maus odores e insetos.",
      "Cuidados com tampas cortantes: para latas de conservas com tampas afiadas, dobre a tampa para dentro da lata para proteger os trabalhadores de cortes.",
      "Amasse e destine: amasse latas de alumínio para otimizar espaço e destine à lixeira amarela, cooperativas ou ecopontos."
    ]
  };

  return (
    <div className="flex flex-col max-w-[900px] w-full mx-auto pb-12 pt-4 px-4 bg-white min-h-screen">
      
      {/* Botão Voltar */}
      <div className="mb-8">
        <Link href="/categorias" className="flex items-center gap-2 text-gray-500 hover:text-gray-900 transition-colors text-sm font-medium w-fit">
          <ArrowLeft size={18} />
          Voltar para categorias
        </Link>
      </div>

      {/* Cabeçalho */}
      <section className="flex flex-col md:flex-row gap-6 items-start md:items-center mb-10">
        <div className={`w-24 h-24 ${info.corFundoIcone} rounded-2xl flex items-center justify-center shrink-0`}>
          {info.icone}
        </div>
        <div>
          <h1 className="text-3xl font-extrabold text-gray-900 mb-2">{info.nome}</h1>
          <p className="text-gray-600 text-sm leading-relaxed max-w-2xl">
            {info.descricao}
          </p>
        </div>
      </section>

      {/* Badges */}
      <section className="flex flex-col sm:flex-row gap-8 mb-12 border-y border-gray-100 py-6">
        <div className="flex items-start gap-3">
          <Recycle className="text-[#D9A406] shrink-0 mt-1" size={24} />
          <div>
            <h4 className="font-bold text-gray-900 text-sm">{info.processo}</h4>
            <p className="text-xs text-gray-500">Retorno infinito à cadeia produtiva por fundição</p>
          </div>
        </div>
        <div className="flex items-start gap-3">
          <Clock className="text-[#D9A406] shrink-0 mt-1" size={24} />
          <div>
            <h4 className="font-bold text-gray-900 text-sm">Tempo de decomposição</h4>
            <p className="text-xs text-gray-500">{info.decomposicao}</p>
          </div>
        </div>
      </section>

      {/* Abas Retráteis (Accordion) */}
      <section className="mb-10 space-y-4">
        <h2 className="text-xl font-bold text-gray-900 mb-6">Tipos de metais recicláveis e como separar</h2>
        
        {info.subcategorias.map((sub) => (
          <AccordionItem
            key={sub.sigla}
            sigla={sub.sigla}
            titulo={sub.nomeCompleto}
            resumo={sub.aplicacao}
            corTexto={info.corBase}
            oQueE={sub.oQueE}
            usos={sub.aplicacao}
            comoSeparar={sub.comoSeparar}
            imagem={sub.imagem}
          />
        ))}
      </section>

      {/* Regras Gerais de Separação */}
      <section>
        <h2 className="text-xl font-bold text-gray-900 mb-4">Como separar e destinar corretamente</h2>
        <div className="bg-[#F8F9FA] rounded-3xl p-6 md:p-8">
          <ul className="space-y-4">
            {info.regrasGerais.map((regra, i) => (
              <li key={i} className="flex gap-4 items-start">
                <div className="w-8 h-8 rounded-full bg-[#FEF9E7] flex items-center justify-center shrink-0 mt-0.5">
                  <span className={`font-bold text-sm ${info.corBase}`}>{i + 1}</span>
                </div>
                <p className="text-gray-600 text-sm leading-relaxed pt-1">{regra}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>

    </div>
  );
}