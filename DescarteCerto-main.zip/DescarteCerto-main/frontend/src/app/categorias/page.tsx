"use client";

import Link from "next/link";
import {
  ArrowRight,
  Battery,
  FileText,
  Wine,
  Leaf,
  TreeDeciduous,
  Milk,
  Cross,
  Trash2,
  Radio,
  Wrench
} from "lucide-react";

import { Card, CardContent } from "../../components/ui/card";

// Mapeamento de categorias com cores baseadas no Tailwind para contraste perfeito
const categorias = [
  { id: "plastico", nome: "Plástico", icon: Milk, theme: "bg-red-50 hover:bg-red-100 text-red-600 border-red-200", fill: "none" },
  { id: "eletronicos", nome: "Eletrônicos", icon: Battery, theme: "bg-orange-50 hover:bg-orange-100 text-orange-600 border-orange-200", fill: "currentColor" },
  { id: "madeira", nome: "Madeira", icon: TreeDeciduous, theme: "bg-stone-50 hover:bg-stone-100 text-stone-600 border-stone-200", fill: "currentColor" },
  { id: "vidro", nome: "Vidro", icon: Wine, theme: "bg-emerald-50 hover:bg-emerald-100 text-emerald-600 border-emerald-200", fill: "currentColor" },
  { id: "papel", nome: "Papel", icon: FileText, theme: "bg-blue-50 hover:bg-blue-100 text-blue-600 border-blue-200", fill: "currentColor" },
  { id: "organicos", nome: "Orgânicos", icon: Leaf, theme: "bg-amber-50 hover:bg-amber-100 text-amber-600 border-amber-200", fill: "currentColor" },
  { id: "metal", nome: "Metal", icon: Wrench, theme: "bg-yellow-50 hover:bg-yellow-100 text-yellow-600 border-yellow-200", fill: "currentColor" },
  { id: "radiacao", nome: "Lixo Radioativo", icon: Radio, theme: "bg-purple-50 hover:bg-purple-100 text-purple-600 border-purple-200", fill: "currentColor" },
  { id: "saudeDomiciliar", nome: "Resíduos de Saúde", icon: Cross, theme: "bg-rose-50 hover:bg-rose-100 text-rose-600 border-rose-200", fill: "currentColor" },
  { id: "naoreciclavel", nome: "Não Recicláveis", icon: Trash2, theme: "bg-gray-100 hover:bg-gray-200 text-gray-700 border-gray-300", fill: "currentColor" }
];

export default function Categorias() {
  return (
    <div className="flex flex-col gap-10 max-w-[900px] mx-auto w-full pb-16 pt-8 px-4 md:px-0">
      
      {/* Cabeçalho da página */}
      <section className="space-y-4 text-center md:text-left">
        <h1 className="text-4xl md:text-5xl font-black text-gray-900 tracking-tight">
          Categorias de <span className="text-emerald-600">Descarte</span>
        </h1>
        <p className="text-gray-500 text-base md:text-lg max-w-2xl">
          Escolha uma categoria para descobrir a forma correta e consciente de realizar o descarte. O meio ambiente agradece.
        </p>
      </section>

      {/* Grid com os cards */}
      <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-6">
        {categorias.map((cat) => (
          <Link href={`/categorias/${cat.id}`} key={cat.id} className="group outline-none">
            <Card
              className={`
                relative h-48 border transition-all duration-300 ease-out rounded-3xl cursor-pointer overflow-hidden
                ${cat.theme}
                hover:shadow-lg hover:shadow-black/5 hover:-translate-y-1.5
                group-focus-visible:ring-4 group-focus-visible:ring-gray-300 group-focus-visible:ring-offset-2
              `}
            >
              <CardContent className="p-6 flex flex-col h-full w-full justify-end relative z-10">
                
                {/* Ícone de Marca D'água no fundo (Decorativo) */}
                <div className="absolute -right-4 -top-4 opacity-[0.08] pointer-events-none transition-transform duration-500 group-hover:scale-110 group-hover:rotate-6">
                  <cat.icon className="w-40 h-40" />
                </div>

               {/* Ícone Principal Centralizado */}
                {/* Aumentamos o pb-6 para pb-14 para empurrar o ícone mais para cima */}
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none pb-14">
                  <div className="bg-white/60 backdrop-blur-md p-4 rounded-full shadow-sm transition-transform duration-500 ease-out group-hover:scale-110 group-hover:-translate-y-2">
                    <cat.icon
                      className="w-10 h-10 transition-colors duration-300"
                      fill={cat.fill}
                      strokeWidth={1.5}
                    />
                  </div>
                </div>

                {/* Rodapé do Card: Texto e Seta */}
                {/* Adicionei 'relative z-10' por segurança para garantir que o texto fique acima do fundo */}
                <div className="relative z-10 flex justify-between items-center w-full mt-auto bg-white/40 backdrop-blur-sm p-2 rounded-2xl border border-white/50">
                  <span className="font-bold text-gray-900 text-sm md:text-base tracking-tight ml-2">
                    {cat.nome}
                  </span>

                  {/* Seta Animada */}
                  <div className="bg-white p-2.5 rounded-xl shadow-sm transition-all duration-300 group-hover:bg-gray-900 group-hover:text-white group-hover:translate-x-1">
                    <ArrowRight className="w-4 h-4 transition-colors" />
                  </div>
                </div>

              </CardContent>
            </Card>
          </Link>
        ))}
      </section>
    </div>
  );
}