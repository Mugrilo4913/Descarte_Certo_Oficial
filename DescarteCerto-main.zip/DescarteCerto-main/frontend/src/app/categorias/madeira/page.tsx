"use client";

import Link from "next/link";
import { ArrowLeft, Trees, TreeDeciduous, Clock } from "lucide-react";
import { AccordionItem } from "@/components/ui/accordionItem"; // Componente reutilizável de abas

export default function MadeiraPage() {
  // CONFIGURAÇÃO DA CATEGORIA: MADEIRA
  const info = {
    nome: "Madeira",
    corBase: "text-[#2B2B2B]", // Cor preta oficial do CONAMA (Resolução 275/2001)
    corFundoIcone: "bg-[#EAEAEA]",
    icone: <TreeDeciduous size={40} className="text-[#2B2B2B]" />,
    descricao: "Resíduos de madeira incluem restos de construções, pallets, caixas e móveis descartados que possuem potencial de reuso e reciclagem.",
    processo: "Reutilização / Trituração e Valorização",
    decomposicao: "13 a 15 anos (madeira natural)",
    
    // Subcategorias para as abas retráteis
    subcategorias: [
      {
        sigla: "PAL",
        nomeCompleto: "Pallets e Caixas de Madeira",
        oQueE: "Estruturas de madeira natural sem verniz ou tinta, muito usadas no transporte de cargas e frutas.",
        aplicacao: "Transporte de mercadorias, caixas de hortifrúti e estruturas de apoio.",
        comoSeparar: "Remova pregos, parafusos ou grampos expostos se possível e encaminhe a Ecopontos ou cooperativas de reuso.",
        imagem: "/images/madeira-pallets.png"
      },
      {
        sigla: "MDF",
        nomeCompleto: "Painéis de Madeira Processada (MDF / MDP)",
        oQueE: "Placas feitas de fibras ou partículas de madeira prensadas com resina sintética.",
        aplicacao: "Móveis planejados, guarda-roupas, estantes, portas internas e prateleiras.",
        comoSeparar: "Desmonte as peças e retire dobradiças, puxadores e ferragens antes de destinar à Coleta de Volumosos.",
        imagem: "/images/madeira-mdf.png"
      },
      {
        sigla: "MAC",
        nomeCompleto: "Móveis e Peças em Madeira Maciça",
        oQueE: "Peças de madeira pura e densa (como peroba, ipê ou pinus) sem prensagem de resinas.",
        aplicacao: "Mesas, cadeiras antigas, portas de entrada, janelas e caixilhos.",
        comoSeparar: "Podem ser restaurados ou doados. Caso danificados, leve a ecopontos para trituração e reuso como biomassa.",
        imagem: "/images/madeira-macica.png"
      },
      {
        sigla: "OBR",
        nomeCompleto: "Madeiras de Construção Civil",
        oQueE: "Tábuas, sarrafos, andaimes e vigas usados no cimbramento de fôrmas e estruturas de obras.",
        aplicacao: "Fôrmas de concreto, andaimes, escoras e estruturas temporárias de obras.",
        comoSeparar: "Separe das sobras de concreto ou argamassa e retire pregos. Destine a caçambas de entulho ou ecopontos da prefeitura.",
        imagem: "/images/madeira-obras.png"
      },
      {
        sigla: "TRAT",
        nomeCompleto: "Madeiras Tratadas e Pintadas",
        oQueE: "Madeiras revestidas com vernizes, tintas a óleo, laqueamento ou conservantes químicos.",
        aplicacao: "Decks de piscina, pergolados, cercas externas e portas laqueadas.",
        comoSeparar: "Não devem ser queimadas para churrasco ou aquecimento devido à liberação de vapores tóxicos. Encaminhe ao ecoponto.",
        imagem: "/images/madeira-tratada.png"
      },
      {
        sigla: "SER",
        nomeCompleto: "Serragem, Cavacos e Pó de Serra",
        oQueE: "Partículas finas ou lascas de madeira geradas durante o corte, lixamento e aplainamento.",
        aplicacao: "Resíduos de projetos de marcenaria, carpintaria caseira ou corte de tábuas.",
        comoSeparar: "Armazene em sacos plásticos secos para evitar espalhar com o vento. Pode ser usado em compostagem ou forração vegetal.",
        imagem: "/images/madeira-serragem.png"
      }
    ],

    // Passos/Regras gerais preservando o texto oficial
    regrasGerais: [
      "Remova pregos, parafusos, dobradiças e peças metálicas antes do envio para facilitar a trituração ou reuso.",
      "Separe madeiras limpas de tratadas: madeiras pintadas ou com verniz exigem atenção por conterem substâncias químicas.",
      "Nunca queime madeiras tratadas em fogueiras ou lareiras caseiras.",
      "Por conta do volume, encaminhe para ecopontos municipais ou serviços de recolhimento de entulhos e volumosos da sua cidade."
    ]
  };

  return (
    <div className="flex flex-col max-w-[900px] w-full mx-auto pb-12 pt-4 px-4 bg-white min-h-screen">
      
      {/* Botão Voltar */}
      <div className="mb-8">
        <Link href="/categorias" className="flex items-center gap-2 text-gray-500 hover:text-gray-900 transition-colors text-sm font-medium w-fit">
          <ArrowLeft size={18} />
          Voltar para categorias
        </Link>
      </div>

      {/* Cabeçalho */}
      <section className="flex flex-col md:flex-row gap-6 items-start md:items-center mb-10">
        <div className={`w-24 h-24 ${info.corFundoIcone} rounded-2xl flex items-center justify-center shrink-0`}>
          {info.icone}
        </div>
        <div>
          <h1 className="text-3xl font-extrabold text-gray-900 mb-2">{info.nome}</h1>
          <p className="text-gray-600 text-sm leading-relaxed max-w-2xl">
            {info.descricao}
          </p>
        </div>
      </section>

      {/* Badges */}
      <section className="flex flex-col sm:flex-row gap-8 mb-12 border-y border-gray-100 py-6">
        <div className="flex items-start gap-3">
          <Trees className="text-gray-800 shrink-0 mt-1" size={24} />
          <div>
            <h4 className="font-bold text-gray-900 text-sm">{info.processo}</h4>
            <p className="text-xs text-gray-500">Transformação em cavacos, MDF ou biomassa</p>
          </div>
        </div>
        <div className="flex items-start gap-3">
          <Clock className="text-gray-800 shrink-0 mt-1" size={24} />
          <div>
            <h4 className="font-bold text-gray-900 text-sm">Tempo de decomposição</h4>
            <p className="text-xs text-gray-500">{info.decomposicao}</p>
          </div>
        </div>
      </section>

      {/* Abas Retráteis (Accordion) */}
      <section className="mb-10 space-y-4">
        <h2 className="text-xl font-bold text-gray-900 mb-6">Tipos de materiais e como separar</h2>
        
        {info.subcategorias.map((sub) => (
          <AccordionItem
            key={sub.sigla}
            sigla={sub.sigla}
            titulo={sub.nomeCompleto}
            resumo={sub.aplicacao}
            corTexto={info.corBase}
            oQueE={sub.oQueE}
            usos={sub.aplicacao}
            comoSeparar={sub.comoSeparar}
            imagem={sub.imagem}
          />
        ))}
      </section>

      {/* Regras Gerais de Separação */}
      <section>
        <h2 className="text-xl font-bold text-gray-900 mb-4">Como separar e destinar corretamente</h2>
        <div className="bg-[#F8F9FA] rounded-3xl p-6 md:p-8">
          <ul className="space-y-4">
            {info.regrasGerais.map((regra, i) => (
              <li key={i} className="flex gap-4 items-start">
                <div className="w-8 h-8 rounded-full bg-[#EAEAEA] flex items-center justify-center shrink-0 mt-0.5">
                  <span className={`font-bold text-sm ${info.corBase}`}>{i + 1}</span>
                </div>
                <p className="text-gray-600 text-sm leading-relaxed pt-1">{regra}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>

    </div>
  );
}