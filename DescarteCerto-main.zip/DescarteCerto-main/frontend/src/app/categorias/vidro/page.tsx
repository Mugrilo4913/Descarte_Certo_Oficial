"use client";

import Link from "next/link";
import { ArrowLeft, Wine, ShieldAlert, Clock } from "lucide-react";
import { AccordionItem } from "@/components/ui/accordionItem";

export default function VidroPage() {
  // VIDRO
  const info = {
    nome: "Vidro",
    corBase: "text-[#4B7E1B]",
    corFundoIcone: "bg-[#D9E8CD]",
    icone: <Wine size={40} className="text-[#96AC3F]" />,
    descricao: "O vidro é um material com elevado potencial de reaproveitamento e reciclagem infinita, principalmente quando proveniente de embalagens.",
    processo: "100% Reciclável (Infinitas vezes)",
    decomposicao: "Mais de 4.000 anos na natureza",
    
    subcategorias: [
      {
        sigla: "GAR",
        nomeCompleto: "Garrafas de Bebidas",
        oQueE: "Recipientes de vidro transparente, âmbar ou verde projetados para envasar líquidos diversos.",
        aplicacao: "Garrafas de cerveja, vinhos, refrigerantes, sucos e água mineral.",
        comoSeparar: "Esvazie completamente o conteúdo, retire as tampas metálicas ou plásticas e coloque no coletor verde.",
        imagem: "/images/vidro/vidro-garrafas.jpg"
      },
      {
        sigla: "POT",
        nomeCompleto: "Potes de Alimentos e Conservas",
        oQueE: "Embalagens de vidro mais espesso desenvolvidas para preservar alimentos em conserva ou molhos.",
        aplicacao: "Potes de maionese, molho de tomate, azeites, geleias, papinhas e conservas.",
        comoSeparar: "Faça uma enxágua simples para retirar o excesso de alimento, remova a tampa de metal de rosca e descarte.",
        imagem: "/images/vidro/vidro-potes.jpg"
      },
      {
        sigla: "COS",
        nomeCompleto: "Frascos de Perfumes e Cosméticos",
        oQueE: "Pequenos recipientes de vidro trabalhado ou colorido usados na indústria de beleza e cuidados.",
        aplicacao: "Frascos de perfumes, colônias, cremes hidratantes em pote de vidro e óleos corporais.",
        comoSeparar: "Certifique-se de que o frasco está totalmente vazio e retire borrifadores/válvulas plásticas ou metálicas.",
        imagem: "/images/vidro/vidro-cosmeticos.jpg"
      },
      {
        sigla: "MED",
        nomeCompleto: "Vidros de Remédios e Xaropes",
        oQueE: "Pequenos frascos âmbar ou transparentes que protegem compostos farmacêuticos contra a luz.",
        aplicacao: "Frascos de xaropes, soluções medicinais líquidas, gotas e suplementos.",
        comoSeparar: "Remova o batoque ou dosador plástico da boca do vidro e lave levemente para retirar resíduos do medicamento.",
        imagem: "/images/vidro/vidro-remedios.jpg"
      },
      {
        sigla: "PLA",
        nomeCompleto: "Vidros Planos Limpos (Sobras)",
        oQueE: "Pedaços ou chapas de vidro plano comum transparente provenientes de cortes limpos.",
        aplicacao: "Retalhos de vidraçaria, vidros de porta-retratos e prateleiras de vidro comum.",
        comoSeparar: "Se houver bordas cortantes, embale com cuidado em papelão reforçado antes de levar ao ecoponto.",
        imagem: "/images/vidro/vidro-plano.jpg"
      },
      {
        sigla: "DOM",
        nomeCompleto: "Utensílios Domésticos Inteiros",
        oQueE: "Peças utilitárias de uso diário na cozinha feitas de vidro soda-cálcico comum.",
        aplicacao: "Copos americanos, jarras de suco e travessas simples que não vão ao forno.",
        comoSeparar: "Se estiverem inteiros e em bom estado, dê preferência à doação. Se descartados, certifique-se de que não são temperados/Pyrex.",
        imagem: "/images/vidro/vidro-utensilios.jpg"
      }
    ],

    // Regras gerais adaptadas da pesquisa oficial
    regrasGerais: [
      "Identifique vidros de embalagens: garrafas, potes de alimentos, frascos de cosméticos e remédios são próprios para o coletor verde.",
      "Esvazie e retire resíduos: o descarte deve ocorrer após a retirada dos restos presentes no interior para evitar odores e insetos.",
      "Cuidados com vidro quebrado: embale os cacos em caixas de papelão, garrafas PET cortadas ou jornal antes de descartar para evitar acidentes com garis e catadores."
    ]
  };

  return (
    <div className="flex flex-col max-w-[900px] w-full mx-auto pb-12 pt-4 px-4 bg-white min-h-screen">
      
      {/* Botão Voltar */}
      <div className="mb-8">
        <Link href="/categorias" className="flex items-center gap-2 text-gray-500 hover:text-gray-900 transition-colors text-sm font-medium w-fit">
          <ArrowLeft size={18} />
          Voltar para categorias
        </Link>
      </div>

      {/* Cabeçalho da Categoria */}
      <section className="flex flex-col md:flex-row gap-6 items-start md:items-center mb-10">
        <div className={`w-24 h-24 ${info.corFundoIcone} rounded-2xl flex items-center justify-center shrink-0`}>
          {info.icone}
        </div>
        <div>
          <h1 className="text-3xl font-extrabold text-gray-900 mb-2">{info.nome}</h1>
          <p className="text-gray-600 text-sm leading-relaxed max-w-2xl">
            {info.descricao}
          </p>
        </div>
      </section>

      {/* Badges de Informação */}
      <section className="flex flex-col sm:flex-row gap-8 mb-12 border-y border-gray-100 py-6">
        <div className="flex items-start gap-3">
          <ShieldAlert className="text-emerald-700 shrink-0 mt-1" size={24} />
          <div>
            <h4 className="font-bold text-gray-900 text-sm">{info.processo}</h4>
            <p className="text-xs text-gray-500">Não perde qualidade no processo de fusão</p>
          </div>
        </div>
        <div className="flex items-start gap-3">
          <Clock className="text-emerald-700 shrink-0 mt-1" size={24} />
          <div>
            <h4 className="font-bold text-gray-900 text-sm">Tempo de decomposição</h4>
            <p className="text-xs text-gray-500">{info.decomposicao}</p>
          </div>
        </div>
      </section>

      {/* Abas Retráteis (Accordion) */}
      <section className="mb-10 space-y-4">
        <h2 className="text-xl font-bold text-gray-900 mb-6">Tipos de vidro recicláveis e como separar</h2>
        
        {info.subcategorias.map((sub) => (
          <AccordionItem
            key={sub.sigla}
            sigla={sub.sigla}
            titulo={sub.nomeCompleto}
            resumo={sub.aplicacao}
            corTexto={info.corBase}
            oQueE={sub.oQueE}
            usos={sub.aplicacao}
            comoSeparar={sub.comoSeparar}
            imagem={sub.imagem}
          />
        ))}
      </section>

      {/* Regras Gerais de Separação */}
      <section>
        <h2 className="text-xl font-bold text-gray-900 mb-4">Como separar e destinar corretamente</h2>
        <div className="bg-[#F8F9FA] rounded-3xl p-6 md:p-8">
          <ul className="space-y-4">
            {info.regrasGerais.map((regra, i) => (
              <li key={i} className="flex gap-4 items-start">
                <div className="w-8 h-8 rounded-full bg-[#E9ECEF] flex items-center justify-center shrink-0 mt-0.5">
                  <span className={`font-bold text-sm ${info.corBase}`}>{i + 1}</span>
                </div>
                <p className="text-gray-600 text-sm leading-relaxed pt-1">{regra}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>

    </div>
  );
}