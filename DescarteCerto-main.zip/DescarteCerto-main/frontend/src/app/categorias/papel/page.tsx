"use client";

import Link from "next/link";
import { ArrowLeft, FileText, Recycle, Clock } from "lucide-react";
import { AccordionItem } from "@/components/ui/accordionItem"; // Componente de abas retráteis

export default function PapelPage() {
  // CONFIGURAÇÃO DA CATEGORIA: PAPEL
  const info = {
    nome: "Papel",
    corBase: "text-[#3B87D7]", // Azul oficial do código de cores (CONAMA 275/2001)
    corFundoIcone: "bg-[#EEF4FC]",
    icone: <FileText size={40} className="text-[#3B87D7]" />,
    descricao: "O papel e o papelão constituem materiais amplamente presentes nos resíduos sólidos urbanos e possuem grande potencial de recuperação.",
    reciclavel: "100% reciclável",
    decomposicao: "3 a 6 meses na natureza",
    
    // Top 10 Subcategorias de papel reciclável
    subcategorias: [
      {
        sigla: "OND",
        nomeCompleto: "Caixas de Papelão Ondulado",
        oQueE: "Papel estruturado com camada interna ondulada de alta resistência mecânica.",
        aplicacao: "Caixas de entregas de e-commerce, encomendas, eletrodomésticos e mudanças.",
        comoSeparar: "Desmonte as caixas para achatar e reduzir o volume. Retire fitas adesivas plásticas grandes e grampos.",
        imagem: "/images/papel-ondulado.png"
      },
      {
        sigla: "CAD",
        nomeCompleto: "Cadernos, Livros e Agendas",
        oQueE: "Conjuntos de folhas de papel offset ou sulfite unidos por espirais, grampos ou lombadas coladas.",
        aplicacao: "Cadernos escolares antigos, livros em desuso, agendas e blocos de anotações.",
        comoSeparar: "Remova as espirais metálicas ou plásticas laterais. Capas duras de papelão podem ser mantidas junto ao papel.",
        imagem: "/images/papel-cadernos.png"
      },
      {
        sigla: "SUL",
        nomeCompleto: "Folhas de Sulfite (Papel A4)",
        oQueE: "Papel branco ou colorido sem pauta, utilizado principalmente para escrita e impressões.",
        aplicacao: "Documentos, impressões de trabalhos, rascunhos de escritório e folhas de desenho.",
        comoSeparar: "Podem ir direto para a coleta seletiva secos. Se possível, remova clipes ou grampos grandes.",
        imagem: "/images/papel-sulfite.png"
      },
      {
        sigla: "JOR",
        nomeCompleto: "Jornais e Revistas",
        oQueE: "Papel imprensa leve ou papel couché com acabamento brilhante.",
        aplicacao: "Jornais diários, periódicos, revistas de entretenimento e catálogos informativos.",
        comoSeparar: "Junte em pilhas e amarre ou coloque em sacos de papel. Mantenha totalmente secos.",
        imagem: "/images/papel-jornais.png"
      },
      {
        sigla: "MED",
        nomeCompleto: "Caixas de Medicamentos e Cosméticos",
        oQueE: "Papel cartão de gramatura leve a média com impressão externa.",
        aplicacao: "Embalagens de remédios, creme dental, sabonetes e caixas de cosméticos.",
        comoSeparar: "Desmonte as caixas dobrando as abas laterais para que fiquem totalmente planas.",
        imagem: "/images/papel-cartucho.png"
      },
      {
        sigla: "ALI",
        nomeCompleto: "Embalagens de Alimentos Secos",
        oQueE: "Papel cartão duplex ou triplex projetado para proteger alimentos secos.",
        aplicacao: "Caixas de cereais matinais, biscoitos, misturas para bolo e caixas de pizza limpas.",
        comoSeparar: "Certifique-se de que estão isentas de restos de alimentos ou gordura. Partes engorduradas devem ir para o lixo comum.",
        imagem: "/images/papel-alimentos.png"
      },
      {
        sigla: "SAC",
        nomeCompleto: "Sacolas de Papel (Kraft e Varejo)",
        oQueE: "Sacolas resistentes feitas de fibra de papel pardo ou colorido.",
        aplicacao: "Sacolas de lojas de roupas, calçados e entregas de restaurantes.",
        comoSeparar: "Remova alças de corda sintética ou plástica e fitas adesivas antes de dobrar para o descarte.",
        imagem: "/images/papel-sacolas.png"
      },
      {
        sigla: "ENV",
        nomeCompleto: "Envelopes de Papel (Comum e Pardo)",
        oQueE: "Invólucros de papel utilizados para envio de correspondências e faturas.",
        aplicacao: "Envelopes de cartas, cobranças bancárias e envelopes manilha de escritório.",
        comoSeparar: "Retire visores de plástico transparente e etiquetas plásticas autocolantes.",
        imagem: "/images/papel-envelopes.png"
      },
      {
        sigla: "PAN",
        nomeCompleto: "Panfletos e Encartes Promocionais",
        oQueE: "Impressos publicitários de grande tiragem produzidos em papel couché ou offset.",
        aplicacao: "Encartes de ofertas de supermercados, folhetos comerciais e catálogos.",
        comoSeparar: "Certifique-se de que não contêm laminação plástica excessiva (que não rasga com facilidade).",
        imagem: "/images/papel-panfletos.png"
      },
      {
        sigla: "RAS",
        nomeCompleto: "Papel de Rascunho e Blocos",
        oQueE: "Pequenos papéis e anotações diversas utilizados no dia a dia.",
        aplicacao: "Lembretes autocolantes, blocos de anotações e papéis de rascunho de recados.",
        comoSeparar: "Junte pequenos papéis soltos num saco de papel maior para não se dispersarem na triagem.",
        imagem: "/images/papel-rascunho.png"
      }
    ],

    // Regras gerais adaptadas do documento oficial
    regrasGerais: [
      "Mantenha limpo e seco: a separação correta exige que o papel seja mantido livre de resíduos orgânicos e líquidos.",
      "Desmonte as caixas: caixas de papelão devem ser achatadas para reduzir o volume e facilitar o transporte.",
      "Atenção à contaminação: materiais contaminados por gordura (ex: fundo engordurado de caixas de pizza) são considerados rejeitos. Recicle apenas as partes limpas.",
      "O que NÃO reciclar: papel higiénico, lenços, papéis plastificados, fotografias e fitas adesivas não são adequados para a reciclagem convencional."
    ]
  };

  return (
    <div className="flex flex-col max-w-[900px] w-full mx-auto pb-12 pt-4 px-4 bg-white min-h-screen">
      
      {/* Botão Voltar */}
      <div className="mb-8">
        <Link href="/categorias" className="flex items-center gap-2 text-gray-500 hover:text-gray-900 transition-colors text-sm font-medium w-fit">
          <ArrowLeft size={18} />
          Voltar para categorias
        </Link>
      </div>

      {/* Cabeçalho da Categoria */}
      <section className="flex flex-col md:flex-row gap-6 items-start md:items-center mb-10">
        <div className={`w-24 h-24 ${info.corFundoIcone} rounded-2xl flex items-center justify-center shrink-0`}>
          {info.icone}
        </div>
        <div>
          <h1 className="text-3xl font-extrabold text-gray-900 mb-2">{info.nome}</h1>
          <p className="text-gray-600 text-sm leading-relaxed max-w-2xl">
            {info.descricao}
          </p>
        </div>
      </section>

      {/* Badges de Informação */}
      <section className="flex flex-col sm:flex-row gap-8 mb-12 border-y border-gray-100 py-6">
        <div className="flex items-start gap-3">
          <Recycle className="text-emerald-600 shrink-0 mt-1" size={24} />
          <div>
            <h4 className="font-bold text-gray-900 text-sm">{info.reciclavel}</h4>
            <p className="text-xs text-gray-500">Quando limpo e separado corretamente</p>
          </div>
        </div>
        <div className="flex items-start gap-3">
          <Clock className="text-emerald-600 shrink-0 mt-1" size={24} />
          <div>
            <h4 className="font-bold text-gray-900 text-sm">Tempo de decomposição</h4>
            <p className="text-xs text-gray-500">{info.decomposicao}</p>
          </div>
        </div>
      </section>

      {/* Abas Retráteis (Accordion) */}
      <section className="mb-10 space-y-4">
        <h2 className="text-xl font-bold text-gray-900 mb-6">Tipos de papel recicláveis e como separar</h2>
        
        {info.subcategorias.map((sub) => (
          <AccordionItem
            key={sub.sigla}
            sigla={sub.sigla}
            titulo={sub.nomeCompleto}
            resumo={sub.aplicacao}
            corTexto={info.corBase}
            oQueE={sub.oQueE}
            usos={sub.aplicacao}
            comoSeparar={sub.comoSeparar}
            imagem={sub.imagem}
          />
        ))}
      </section>

      {/* Regras Gerais de Separação */}
      <section>
        <h2 className="text-xl font-bold text-gray-900 mb-4">Como separar e destinar corretamente</h2>
        <div className="bg-[#F8F9FA] rounded-3xl p-6 md:p-8">
          <ul className="space-y-4">
            {info.regrasGerais.map((regra, i) => (
              <li key={i} className="flex gap-4 items-start">
                <div className="w-8 h-8 rounded-full bg-[#E9ECEF] flex items-center justify-center shrink-0 mt-0.5">
                  <span className={`font-bold text-sm ${info.corBase}`}>{i + 1}</span>
                </div>
                <p className="text-gray-600 text-sm leading-relaxed pt-1">{regra}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>

    </div>
  );
}