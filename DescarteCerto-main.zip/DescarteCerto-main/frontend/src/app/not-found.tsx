"use client"; // Necessário para usar useRouter

export default function NotFound() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-background text-foreground p-6">
      <p>Page not found</p> 
    </div>
  );
}