// src/app/layout.tsx
import "./globals.css";
import { Inter } from "next/font/google";
import Sidebar from "@/components/blocks/sidebar/header";
import { Toaster } from "@/components/ui/toast";
import { AuthProvider } from "@/context/AuthContext";
import { TopBar } from "@/components/blocks/header/TopBar";
import { Welcome } from "@/components/blocks/welcome/welcome";

const inter = Inter({ subsets: ["latin"] });

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="pt-BR">
      <body className={`${inter.className} bg-[#dddfd7] text-gray-900 antialiased min-h-screen`}>
        <AuthProvider>
          <Sidebar />
          
          <main className="transition-all duration-300 pt-16 md:pt-0 md:pl-[260px] min-h-screen flex flex-col">
            {/* Barra superior no canto direito com login / perfil */}
            <TopBar />

            <div className="p-4 sm:p-6 md:p-8 mx-auto w-full flex-1">
              {children}
            </div>
          </main>

          {/* Modal de boas-vindas na primeira visita */}
          <Welcome />

          <Toaster />
        </AuthProvider>
      </body>
    </html>
  );
}