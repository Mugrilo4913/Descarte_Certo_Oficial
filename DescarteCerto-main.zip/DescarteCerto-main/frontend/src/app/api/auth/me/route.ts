import { NextRequest, NextResponse } from "next/server";
import { pool } from "../../../lib/db";
import { getUserIdFromRequest } from "../../../lib/auth_server";

export async function GET(req: NextRequest) {
  try {
    const userId = getUserIdFromRequest(req);

    if (!userId) {
      return NextResponse.json(
        { success: false, message: "Não autenticado." },
        { status: 401 }
      );
    }

    const [rows]: any = await pool.query(
      `SELECT u.id, u.nome, u.email, c.cep 
       FROM usuarios u 
       LEFT JOIN ceps c ON u.id = c.usuario_id 
       WHERE u.id = ? LIMIT 1`,
      [userId]
    );

    if (rows.length === 0) {
      return NextResponse.json(
        { success: false, message: "Usuário não encontrado." },
        { status: 404 }
      );
    }

    const u = rows[0];
    return NextResponse.json({
      success: true,
      user: {
        id: u.id,
        nome: u.nome,
        email: u.email,
        cep: u.cep || "",
      },
    });
  } catch (error) {
    return NextResponse.json(
      { success: false, message: "Erro ao buscar dados." },
      { status: 500 }
    );
  }
}