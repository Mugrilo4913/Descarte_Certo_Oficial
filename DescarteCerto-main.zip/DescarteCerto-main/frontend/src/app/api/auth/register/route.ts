import { NextRequest, NextResponse } from "next/server";
import { pool } from "../../../lib/db";
import bcrypt from "bcryptjs";

export async function POST(req: NextRequest) {
  try {
    const { nome, email, senha, cep } = await req.json();

    if (!nome || !email || !senha) {
      return NextResponse.json(
        { success: false, message: "Preencha todos os campos obrigatórios." },
        { status: 400 }
      );
    }

    // Verifica se e-mail já existe
    const [existentes]: any = await pool.query(
      "SELECT id FROM usuarios WHERE email = ? LIMIT 1",
      [email]
    );

    if (existentes.length > 0) {
      return NextResponse.json(
        { success: false, message: "Este e-mail já está em uso." },
        { status: 409 }
      );
    }

    const hash = await bcrypt.hash(senha, 10);

    // Insere usuário
    const [result]: any = await pool.query(
      "INSERT INTO usuarios (nome, email, senha_hash) VALUES (?, ?, ?)",
      [nome, email, hash]
    );

    const novoUserId = result.insertId;

    // Se informou CEP, salva na tabela ceps
    if (cep) {
      await pool.query(
        "INSERT INTO ceps (usuario_id, cep) VALUES (?, ?)",
        [novoUserId, cep]
      );
    }

    return NextResponse.json({
      success: true,
      message: "Conta criada com sucesso! Faça login.",
    });
  } catch (error: any) {
    console.error("Erro no cadastro:", error);
    return NextResponse.json(
      { success: false, message: "Erro ao cadastrar usuário." },
      { status: 500 }
    );
  }
}