import { NextRequest, NextResponse } from "next/server";
import { pool } from "../../../lib/db";
import { getUserIdFromRequest } from "../../../lib/auth_server";

export async function DELETE(req: NextRequest) {
  try {
    const userId = getUserIdFromRequest(req);

    if (!userId) {
      return NextResponse.json({ success: false, message: "Não autorizado." }, { status: 401 });
    }

    // O ON DELETE CASCADE na FK do banco já exclui os registros da tabela `ceps` automaticamente
    await pool.query("DELETE FROM usuarios WHERE id = ?", [userId]);

    const response = NextResponse.json({ success: true, message: "Conta excluída." });
    response.cookies.set("token", "", { maxAge: 0, path: "/" });
    return response;
  } catch (error) {
    return NextResponse.json({ success: false, message: "Erro ao excluir conta." }, { status: 500 });
  }
}