import { NextRequest, NextResponse } from "next/server";
import { pool } from "../../../lib/db";
import { getUserIdFromRequest } from "../../../lib/auth_server";

export async function PUT(req: NextRequest) {
  try {
    const userId = getUserIdFromRequest(req);

    if (!userId) {
      return NextResponse.json(
        { success: false, message: "Não autorizado." },
        { status: 401 }
      );
    }

    const { nome, email, cep } = await req.json();

    if (!nome || !email) {
      return NextResponse.json(
        { success: false, message: "Nome e e-mail não podem ficar vazios." },
        { status: 400 }
      );
    }

    // Verifica se o novo e-mail já pertence a outro usuário
    const [existente]: any = await pool.query(
      "SELECT id FROM usuarios WHERE email = ? AND id != ? LIMIT 1",
      [email, userId]
    );

    if (existente.length > 0) {
      return NextResponse.json(
        { success: false, message: "Este e-mail já pertence a outra conta." },
        { status: 409 }
      );
    }

    // 1. Atualiza dados principais
    await pool.query(
      "UPDATE usuarios SET nome = ?, email = ? WHERE id = ?",
      [nome, email, userId]
    );

    // 2. Atualiza ou insere o CEP
    if (cep !== undefined) {
      const [cepExistente]: any = await pool.query(
        "SELECT id FROM ceps WHERE usuario_id = ? LIMIT 1",
        [userId]
      );

      if (cepExistente.length > 0) {
        await pool.query(
          "UPDATE ceps SET cep = ? WHERE usuario_id = ?",
          [cep, userId]
        );
      } else if (cep) {
        await pool.query(
          "INSERT INTO ceps (usuario_id, cep) VALUES (?, ?)",
          [userId, cep]
        );
      }
    }

    return NextResponse.json({
      success: true,
      message: "Dados atualizados com sucesso!",
      user: { id: userId, nome, email, cep: cep || "" },
    });
  } catch (error: any) {
    console.error("Erro ao atualizar perfil:", error);
    return NextResponse.json(
      { success: false, message: "Erro interno ao atualizar." },
      { status: 500 }
    );
  }
}