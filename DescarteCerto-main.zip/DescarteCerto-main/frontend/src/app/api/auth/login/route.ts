import { NextRequest, NextResponse } from "next/server";
import { pool } from "../../../lib/db";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

const JWT_SECRET = process.env.JWT_SECRET || "chave_padrao_descarte_certo";

export async function POST(req: NextRequest) {
  try {
    const { email, senha } = await req.json();

    if (!email || !senha) {
      return NextResponse.json(
        { success: false, message: "E-mail e senha são obrigatórios." },
        { status: 400 }
      );
    }

    const [rows]: any = await pool.query(
      `SELECT u.id, u.nome, u.email, u.senha_hash, c.cep 
       FROM usuarios u 
       LEFT JOIN ceps c ON u.id = c.usuario_id 
       WHERE u.email = ? LIMIT 1`,
      [email]
    );

    if (rows.length === 0) {
      return NextResponse.json(
        { success: false, message: "Credenciais inválidas." },
        { status: 401 }
      );
    }

    const usuario = rows[0];
    const senhaValida = await bcrypt.compare(senha, usuario.senha_hash);

    if (!senhaValida) {
      return NextResponse.json(
        { success: false, message: "Credenciais inválidas." },
        { status: 401 }
      );
    }

    // Gera o token
    const token = jwt.sign(
      { id: usuario.id, email: usuario.email },
      JWT_SECRET,
      { expiresIn: "7d" }
    );

    const response = NextResponse.json({
      success: true,
      user: {
        id: usuario.id,
        nome: usuario.nome,
        email: usuario.email,
        cep: usuario.cep || "",
      },
    });

    // Salva cookie acessível pelo browser e backend
    response.cookies.set("token", token, {
      httpOnly: false, // permite leitura caso seu frontend use document.cookie
      secure: process.env.NODE_ENV === "production",
      maxAge: 60 * 60 * 24 * 7, // 7 dias
      path: "/",
    });

    return response;
  } catch (error: any) {
    console.error("Erro no login:", error);
    return NextResponse.json(
      { success: false, message: "Erro interno no servidor." },
      { status: 500 }
    );
  }
}