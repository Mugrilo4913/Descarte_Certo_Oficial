import { NextResponse } from "next/server";
import mysql from "mysql2/promise";

export async function GET() {
  try {
    // Conexão com o seu banco de dados
    const connection = await mysql.createConnection({
      host: process.env.DB_HOST || "localhost",
      user: process.env.DB_USER || "root",
      password: process.env.DB_PASSWORD || "14102011Sa", 
      database: process.env.DB_NAME || "descartecerto",
    });

    const [rows] = await connection.execute(`
      SELECT 
        l.id, 
        l.nome, 
        l.endereco, 
        l.bairro, 
        l.horario_funcionamento as horario,
        l.latitude, 
        l.longitude, 
        l.status_verificacao,
        GROUP_CONCAT(r.nome SEPARATOR ', ') as categorias
      FROM locais_descarte l
      LEFT JOIN locais_residuos lr ON l.id = lr.local_id
      LEFT JOIN tipos_residuos r ON lr.residuo_id = r.id
      WHERE l.tipo_local IN ('estacao_coleta', 'ponto_especial')
      GROUP BY l.id
    `);

    await connection.end();

    return NextResponse.json({ success: true, data: rows }, { status: 200 });
  } catch (error) {
    console.error("Erro no Banco de Dados:", error);
    return NextResponse.json({ success: false, message: "Erro ao buscar locais." }, { status: 500 });
  }
}