// Arquivo: src/app/api/escanear/route.ts
import { GoogleGenerativeAI } from "@google/generative-ai";
import { NextResponse } from "next/server";

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY as string);

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { image } = body;

    if (!image) {
      return NextResponse.json(
        { error: "Nenhuma imagem foi enviada." },
        { status: 400 }
      );
    }

    const base64Data = image.includes(",") ? image.split(",")[1] : image;

    const prompt = `
    Você é um assistente especialista em reciclagem.
    Identifique o resíduo em destaque nesta imagem. Caso tenha mais de um material, identifique-os, fale de cada um e separe em dois parágrafos.
    Retorne a resposta estritamente no seguinte formato JSON válido:
    {
      "nome": "Nome dos objetos (ex: Garrafa de Refrigerante)",
      "categoria": "As categorias: Plástico, Vidro, Papel, Metal, Orgânico, Eletrônicos, Madeira, Não Reciclável, Radiação, Saúde Domiciliar (Hospitalar), Outros",
      "instrucoes": "Instruções claras e objetivas de descarte. Deve incluir: 1) Se precisa de higienização ou retirada de resíduos orgânicos antes do descarte. 2) Como embalar caso seja cortante ou perigoso. 3) Se o item contiver dados pessoais (como caixas com etiquetas), instrua a destruir essas informações (LGPD)."
    }
    `;

    const model = genAI.getGenerativeModel({
      model: "gemini-3.8-flash",
      generationConfig: {
        responseMimeType: "application/json",
      },
    });

    const MAX_ATTEMPTS = 3;

    for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
      try {
        const result = await model.generateContent([
          prompt,
          {
            inlineData: {
              data: base64Data,
              mimeType: "image/jpeg",
            },
          },
        ]);

        const responseText = result.response.text();
        return NextResponse.json(JSON.parse(responseText));
      } catch (err: any) {
        // Se for erro de sobrecarga temporária da API da Google (503 ou 429)
        if (err?.status === 503 || err?.status === 429) {
          console.warn(
            `[gemini-3.8-flash] Servidor ocupado (${err.status}). Tentativa ${attempt} de ${MAX_ATTEMPTS}.`
          );

          if (attempt < MAX_ATTEMPTS) {
            // Espera 2.5s na 1ª tentativa e 5s na 2ª para dar tempo da fila esvaziar
            const waitTime = attempt * 2500;
            await sleep(waitTime);
            continue;
          }
        }

        // Se for outro erro ou se esgotaram as tentativas
        throw err;
      }
    }

    return NextResponse.json(
      { error: "Os servidores do Gemini estão sobrecarregados no momento. Tente novamente em instantes." },
      { status: 503 }
    );
  } catch (error: any) {
    console.error("Erro ao analisar imagem:", error);

    const status = error?.status && error.status >= 400 && error.status < 600 ? error.status : 500;
    const message =
      status === 503
        ? "Os servidores de IA estão sobrecarregados no momento. Tente novamente em instantes."
        : "Não foi possível identificar o resíduo na imagem.";

    return NextResponse.json({ error: message }, { status });
  }
}