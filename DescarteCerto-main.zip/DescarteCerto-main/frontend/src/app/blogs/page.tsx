"use client";

import { Suspense, useEffect } from "react";
import { useSearchParams } from "next/navigation";
import { BlogCard } from "@/components/ui/blogCard";
import { blogsData } from "../data/blogs";

function ListaBlogs() {
  const searchParams = useSearchParams();
  const blogIdUrl = searchParams.get("id");

  useEffect(() => {
    if (blogIdUrl) {
      const elemento = document.getElementById(blogIdUrl);
      if (elemento) {
        elemento.scrollIntoView({ behavior: "smooth", block: "center" });
      }
    }
  }, [blogIdUrl]);

  return (
    <section className="w-full columns-1 gap-6 md:columns-2">
      {blogsData.map((blog) => (
        <div key={blog.id} id={blog.id} className="break-inside-avoid mb-6">
          <BlogCard
            codigo={blog.codigo}
            icone={blog.icone}
            titulo={blog.titulo}
            descricao={blog.descricao}
            conteudo={blog.conteudo}
            dicas={blog.dicas}
            cor={blog.cor}
            defaultOpen={blog.id === blogIdUrl}
          />
        </div>
      ))}
    </section>
  );
}

export default function BlogsPage() {
  return (
    <div className="mx-auto flex min-h-screen w-full max-w-[1000px] flex-col gap-10 px-4 pb-12 pt-4">
      <section className="space-y-2">
        <h1 className="text-3xl font-extrabold tracking-tight text-[#1B2A21] md:text-4xl">
          Blogs
        </h1>
        <p className="max-w-[520px] text-sm text-[#5B665D] md:text-base">
          Guias rápidos para descartar cada material no lugar certo, sem complicação.
        </p>
      </section>

      <Suspense fallback={<div>Carregando...</div>}>
        <ListaBlogs />
      </Suspense>
    </div>
  );
}