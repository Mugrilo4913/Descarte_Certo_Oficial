"use client";

import Image from "next/image";
import Link from "next/link";
import {
  Scan,
  Battery,
  FileText,
  Wine,
  TreeDeciduous,
  Recycle,
  ArrowRight,
  Calendar,
  Apple,
  Camera,
  LayoutGrid,
  BookOpen,
  ChevronRight,
  Milk,
  Wrench,
  Radio,
  Cross,
  Trash2
} from "lucide-react";

import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
} from "@/components/ui/carousel";
import { useAuth } from "@/context/AuthContext";
import { blogsData } from "./data/blogs";

const categorias = [
  { id: 1, nome: "Plástico", slug: "plastico", icon: Milk, corTexto: "text-[#b03f3f]", corFundo: "bg-[#ff9696]/40" },
  { id: 2, nome: "Eletrônicos", slug: "eletronicos", icon: Battery, corTexto: "text-[#BC4700]", corFundo: "bg-[#F7D2B5]/60" },
  { id: 3, nome: "Madeira", slug: "madeira", icon: TreeDeciduous, corTexto: "text-[#4b4b4b]", corFundo: "bg-[#636262]/20" },
  { id: 4, nome: "Vidro", slug: "vidro", icon: Wine, corTexto: "text-[#4B7E1B]", corFundo: "bg-[#D9E8CD]" },
  { id: 5, nome: "Papel", slug: "papel", icon: FileText, corTexto: "text-[#1860B1]", corFundo: "bg-[#CFE2F5]" },
  { id: 6, nome: "Orgânicos", slug: "organicos", icon: Apple, corTexto: "text-[#8a5a3a]", corFundo: "bg-[#a87f61]/30" },
  { id: 7, nome: "Metal", slug: "metal", icon: Wrench, corTexto: "text-[#D9A406]", corFundo: "bg-[#FEF9E7]" },
  { id: 8, nome: "Radioativo", slug: "radiacao", icon: Radio, corTexto: "text-[#7E5AA9]", corFundo: "bg-[#F5EEF8]" },
  { id: 9, nome: "Saúde", slug: "saudeDomiciliar", icon: Cross, corTexto: "text-red-600", corFundo: "bg-red-50 border border-red-100" },
  { id: 10, nome: "Não Recicláveis", slug: "naoreciclavel", icon: Trash2, corTexto: "text-[#6C757D]", corFundo: "bg-[#E9ECEF]" },
];

export default function Home() {
  const { user } = useAuth();
  const userName = user?.nome || "Visitante";

  return (
    <div className="min-h-screen flex flex-col items-center">
      <div className="flex flex-col gap-8 max-w-[1250px] w-full px-4 sm:px-6 pb-12 pt-8">

        {/* Cabeçalho */}
        <section className="space-y-1">
          <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-2 tracking-tight">
            Olá, {userName}! <span className="text-3xl animate-bounce-slow">👋</span>
          </h1>
          <p className="text-slate-500 text-sm font-medium">
            Que bom te ver por aqui! Vamos fazer o descarte certo hoje?
          </p>
        </section>

        {/* Grid de 3 Cards Principais */}
        <section className="grid grid-cols-1 lg:grid-cols-3 gap-6">

          {/* Card 1 - Recicláveis */}
          <div className="bg-[#8CB861] rounded-[2rem] p-6 relative overflow-hidden min-h-[190px] flex flex-col justify-between shadow-sm group">
            <Link href="/mapa" className="bg-white/20 hover:bg-white/30 transition-colors text-white w-fit px-4 py-2 rounded-full text-xs font-semibold backdrop-blur-md z-20 flex items-center gap-2">
              Ver ponto de coleta <ArrowRight size={14} />
            </Link>

            <div className="z-10 mt-4">
              <h2 className="text-white text-2xl font-bold mb-1">Recicláveis</h2>
              <p className="text-white/90 text-sm max-w-[85%] leading-snug font-medium">
                Separe, reduza o impacto, valorize o futuro.
              </p>
            </div>

            <div className="absolute -bottom-10 -right-6 opacity-[0.15] group-hover:scale-110 transition-transform duration-500">
              <Recycle size={180} color="white" strokeWidth={1} />
            </div>
          </div>

          {/* Card 2 - Misto (Próxima coleta / Úmidos) */}
          <div className="bg-white rounded-[2rem] p-6 relative flex flex-col justify-between shadow-sm border border-slate-100 min-h-[190px]">
            <div className="flex flex-col items-start gap-1">
              <div className="flex items-center gap-2 text-slate-900 font-bold">
                <Calendar size={18} className="text-slate-700" />
                Próxima coleta
              </div>
              <p className="text-slate-500 text-[13px] font-medium">Não há coletas próximas na sua região.</p>
            </div>

            <div className="h-px w-full bg-slate-100 my-4"></div>

            <div className="flex items-center justify-between">
              <div className="flex flex-col gap-1">
                <div className="flex items-center gap-2 text-slate-900 font-bold">
                  <Apple size={18} className="text-slate-700" />
                  Úmidos
                </div>
                <p className="text-slate-500 text-[13px] font-medium">Restos de alimentos e orgânicos.</p>
              </div>
              <div className="text-5xl drop-shadow-md pr-2">🍎</div>
            </div>
          </div>

          {/* Card 3 - Escanear */}
          <div className="bg-[#2A2A2A] rounded-[2rem] p-6 relative overflow-hidden min-h-[190px] flex flex-col justify-between shadow-sm">
            <div className="relative z-20 space-y-2">
              <div className="flex items-center gap-3">
                <div className="p-2 border border-white/10 rounded-xl">
                  <Camera size={22} className="text-white" strokeWidth={1.5} />
                </div>
                <h2 className="text-white text-lg font-bold">Escanear resíduo</h2>
              </div>
              <p className="text-gray-300 text-[13px] leading-snug max-w-[90%] font-medium">
                Identifique corretamente o resíduo com a câmera do seu dispositivo.
              </p>
            </div>

            <Link
              href="/escanear"
              className="relative z-20 bg-[#D9F0A3] hover:bg-[#c9e48f] text-[#2b3a16] transition-colors rounded-full font-bold w-fit mt-4 h-10 px-5 flex items-center gap-2 text-sm shadow-sm"
            >
              <Camera size={16} /> Escanear agora
            </Link>

            <div className="absolute top-4 right-4 text-white/5 z-10 pointer-events-none">
              <Scan size={100} strokeWidth={1} />
            </div>
          </div>

        </section>

        {/* Seção Categorias */}
        <section>
          <h2 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
            <LayoutGrid size={20} className="text-slate-700" /> Categorias
          </h2>

          <Carousel opts={{ align: "start", dragFree: true }} className="w-full relative">
            <CarouselContent className="-ml-4 py-2">
              {categorias.map((cat) => (
                <CarouselItem key={cat.id} className="pl-4 basis-auto">
                  <Link href={`/categorias/${cat.slug}`}>
                    <div className="flex flex-col items-center gap-3 cursor-pointer group">
                      <div className={`w-[90px] h-[90px] sm:w-[100px] sm:h-[100px] ${cat.corFundo} rounded-3xl flex items-center justify-center transition-all duration-300 group-hover:scale-105 group-hover:shadow-sm border border-black/5`}>
                        <cat.icon className={`${cat.corTexto}`} size={32} strokeWidth={1.5} />
                      </div>
                      <span className="text-slate-700 font-bold text-[13px] group-hover:text-slate-900 transition-colors text-center max-w-[90px]">
                        {cat.nome}
                      </span>
                    </div>
                  </Link>
                </CarouselItem>
              ))}
            </CarouselContent>
          </Carousel>
        </section>

        {/* Seção Dicas e Blogs */}
        <section className="bg-white rounded-[2rem] p-6 sm:p-8 shadow-sm border border-slate-100">
          <h2 className="text-lg font-bold text-slate-900 mb-5 flex items-center gap-2">
            <BookOpen size={20} className="text-slate-700" /> Dicas de Descarte / Blogs
          </h2>

          <Carousel opts={{ align: "start", dragFree: true }} className="w-full">
            <CarouselContent className="-ml-4 py-2">
              {blogsData.map((blog) => (
                <CarouselItem key={blog.id} className="pl-4 basis-auto">
                  <Link href={`/blogs?id=${blog.id}`} className="block outline-none">
                    <div className="bg-white rounded-3xl p-3 flex items-center gap-4 hover:shadow-md transition-all border border-slate-100 w-[300px] sm:w-[380px] relative h-[130px]">

                      {/* Imagem */}
                      <div className="relative w-24 h-24 sm:w-28 sm:h-28 bg-slate-100 rounded-2xl overflow-hidden shrink-0">
                        <Image
                          src={blog.imagem}
                          alt={blog.titulo}
                          fill
                          className="object-cover"
                        />
                      </div>

                      {/* Textos */}
                      <div className="flex flex-col flex-1 h-full py-1 pr-6 justify-center">
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded w-fit mb-1.5 ${blog.tagCor}`}>
                          {blog.tag}
                        </span>
                        <h3 className="text-[13px] sm:text-sm font-bold text-slate-900 leading-snug mb-1 line-clamp-2">
                          {blog.titulo}
                        </h3>
                        <p className="text-[11px] sm:text-xs text-slate-500 leading-snug line-clamp-2 font-medium">
                          {blog.descricao}
                        </p>
                      </div>

                      {/* Setinha */}
                      <button className="absolute bottom-4 right-4 w-6 h-6 sm:w-7 sm:h-7 rounded-full bg-slate-50 flex items-center justify-center text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors">
                        <ChevronRight size={14} strokeWidth={2.5} />
                      </button>

                    </div>
                  </Link>
                </CarouselItem>
              ))}
            </CarouselContent>
            
            <div className="hidden lg:block">
              <CarouselNext className="-right-4 shadow-md border-slate-100 bg-white hover:bg-slate-50" />
            </div>
          </Carousel>
        </section>

      </div>
    </div>
  );
}