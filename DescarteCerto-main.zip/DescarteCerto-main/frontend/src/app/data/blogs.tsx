import { Battery, Recycle, Boxes, Cpu } from "lucide-react";

export const blogsData = [
  {
    id: "pilhas",
    codigo: "RP",
    icone: Battery,
    titulo: "Pilhas não vão no lixo comum",
    descricao: "Pilhas contêm componentes que precisam de coleta específica.",
    conteudo: [
      "Sabe aquele hábito de jogar a pilha fraca da TV direto na lixeira da cozinha? Esse é um dos maiores perigos para o meio ambiente!",
      "Dentro de uma pilha existem metais pesados como chumbo, mercúrio e cádmio. Quando ela vai para o aterro comum, a carcaça de metal enferruja e esses ácidos vazam contaminando o solo e lençóis freáticos.",
      "Como resolver de forma simples e rápida:",
    ],
    dicas: [
      "Junte pilhas e baterias velhas em um pote de sorvete ou caixa de papelão em casa.",
      "Quando for ao supermercado ou agência bancária, leve o pote. Eles possuem caixas coletoras na entrada.",
      "O fabricante recolhe e neutraliza os metais com segurança.",
    ],
    cor: "#E8622C",
    tag: "Dica",
    tagCor: "text-orange-700 bg-orange-100",
    imagem: "https://images.unsplash.com/photo-1550989460-0adf9ea622e2?q=80&w=400&auto=format&fit=crop"
  },
  {
    id: "plastico",
    codigo: "PL",
    icone: Recycle,
    titulo: "Como separar o plástico para reciclagem",
    descricao: "Um guia simples para limpar, separar e reduzir o volume.",
    conteudo: [
      "Não precisa virar um especialista para reciclar plástico. A regra de ouro é: plástico limpo vale dinheiro pra cooperativa, plástico engordurado vira lixo comum.",
      "Muitas pessoas acham que precisam lavar os potes com detergente até brilhar, mas economizar água também faz parte do processo sustentável.",
      "Passo a passo prático:",
    ],
    dicas: [
      "Passe apenas um fio de água de reuso para tirar o excesso pesado de molho ou gordura de potes.",
      "Amasse as garrafas PET. Tirar o ar de dentro reduz o volume em até 70%.",
      "Tampinhas de garrafa também são 100% recicláveis, guarde no mesmo saco.",
    ],
    cor: "#C23B3B",
    tag: "Guia",
    tagCor: "text-blue-700 bg-blue-100",
    imagem: "https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?q=80&w=400&auto=format&fit=crop"
  },
  {
    id: "coleta",
    codigo: "CS",
    icone: Boxes,
    titulo: "O que pode ir para a coleta seletiva?",
    descricao: "Entenda as categorias e evite contaminar materiais recicláveis.",
    conteudo: [
      "O maior erro na coleta seletiva é 'misturar tudo'. Quando um papelão limpo encosta em um resto de comida engordurado, o lote inteiro vai pro lixo.",
      "Divida a sua casa mentalmente em apenas dois grupos principais: secos e úmidos.",
      "O que entra em cada lado:",
    ],
    dicas: [
      "Secos, vão para a reciclagem: vidro, papelão, alumínio, papel e plásticos secos.",
      "Úmidos, não reciclam: restos de comida, papel higiênico, guardanapos sujos e fraldas.",
      "Se tiver dúvida sobre a limpeza do item, passe um pano seco antes de jogar na lixeira reciclável.",
    ],
    cor: "#2F6B4F",
    tag: "Conceito",
    tagCor: "text-green-700 bg-green-100",
    imagem: "https://images.unsplash.com/photo-1528183429752-a97d0bf99b5a?q=80&w=400&auto=format&fit=crop"
  },
  {
    id: "eletronicos",
    codigo: "EE",
    icone: Cpu,
    titulo: "Como descartar eletrônicos?",
    descricao: "Descubra onde levar aparelhos, cabos e pequenos componentes.",
    conteudo: [
      "Gaveta cheia de cabos USB velhos e celulares antigos? O famoso 'e-lixo' não pode apodrecer no armário nem ir para a lixeira da rua.",
      "Eletrônicos possuem placas ricas em metais nobres, como ouro e cobre, mas também contêm elementos altamente tóxicos se descartados na natureza.",
      "Como se livrar do e-lixo com segurança:",
    ],
    dicas: [
      "Antes de descartar celulares, faça o backup e restaure os padrões de fábrica.",
      "Grandes lojas de varejo e supermercados recebem eletrônicos velhos de graça.",
      "Fios, carregadores e peças quebradas devem ir para ecopontos municipais.",
    ],
    cor: "#35618C",
    tag: "Aviso",
    tagCor: "text-purple-700 bg-purple-100",
    imagem: "https://images.unsplash.com/photo-1555664424-778a1e5e1b48?q=80&w=400&auto=format&fit=crop"
  },
];