"use client";

import { useEffect, useRef } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

interface MapProps {
  locais: any[];
  localSelecionado: any | null;
  onSelect: (local: any) => void;
  posicaoUsuario?: { lat: number; lng: number; endereco: string } | null;
}

export default function Map({ locais = [], localSelecionado, onSelect, posicaoUsuario }: MapProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersLayerRef = useRef<L.LayerGroup | null>(null);

  // Inicialização do Mapa
  useEffect(() => {
    if (!mapRef.current) return;

    if (!mapInstanceRef.current) {
      const latCenter = -23.666692;
      const lngCenter = -46.546662;

      const map = L.map(mapRef.current, {
        zoomControl: false,
        attributionControl: false,
      }).setView([latCenter, lngCenter], 13);

      L.control.zoom({ position: "bottomright" }).addTo(map);

      L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
        maxZoom: 19,
      }).addTo(map);

      mapInstanceRef.current = map;
      markersLayerRef.current = L.layerGroup().addTo(map);
    }

    const timer = setTimeout(() => {
      mapInstanceRef.current?.invalidateSize();
    }, 250);

    return () => clearTimeout(timer);
  }, []);

  // Atualização dos Marcadores e Animação de Voo para CEP / Local Selecionado
  useEffect(() => {
    const map = mapInstanceRef.current;
    const markersLayer = markersLayerRef.current;

    if (!map || !markersLayer) return;

    markersLayer.clearLayers();

    // Ícone verde padrão para ecopontos
    const defaultIcon = L.divIcon({
      className: "custom-leaflet-marker",
      html: `
        <div style="
          background-color: #059669;
          width: 32px;
          height: 32px;
          border-radius: 50% 50% 50% 0;
          transform: rotate(-45deg);
          border: 2px solid white;
          box-shadow: 0 4px 10px rgba(0,0,0,0.25);
          display: flex;
          align-items: center;
          justify-content: center;
        ">
          <div style="
            width: 10px;
            height: 10px;
            background-color: white;
            border-radius: 50%;
            transform: rotate(45deg);
          "></div>
        </div>
      `,
      iconSize: [32, 32],
      iconAnchor: [16, 32],
      popupAnchor: [0, -32],
    });

    // Ícone escuro para o local selecionado
    const selectedIcon = L.divIcon({
      className: "custom-leaflet-marker-active",
      html: `
        <div style="
          background-color: #0f172a;
          width: 38px;
          height: 38px;
          border-radius: 50% 50% 50% 0;
          transform: rotate(-45deg);
          border: 3px solid #10b981;
          box-shadow: 0 6px 14px rgba(0,0,0,0.35);
          display: flex;
          align-items: center;
          justify-content: center;
        ">
          <div style="
            width: 12px;
            height: 12px;
            background-color: #10b981;
            border-radius: 50%;
            transform: rotate(45deg);
          "></div>
        </div>
      `,
      iconSize: [38, 38],
      iconAnchor: [19, 38],
      popupAnchor: [0, -38],
    });

    // Ícone azul pulsante para indicar a localização do CEP pesquisado / GPS
    const userIcon = L.divIcon({
      className: "custom-leaflet-marker-user",
      html: `
        <div style="
          background-color: #2563eb;
          width: 22px;
          height: 22px;
          border-radius: 50%;
          border: 3px solid white;
          box-shadow: 0 0 0 4px rgba(37, 99, 235, 0.4), 0 4px 10px rgba(0,0,0,0.3);
        "></div>
      `,
      iconSize: [22, 22],
      iconAnchor: [11, 11],
      popupAnchor: [0, -11],
    });

    const coordsParaBounds: L.LatLngExpression[] = [];

    // Renderiza o marcador do Usuário caso exista
    if (posicaoUsuario && posicaoUsuario.lat && posicaoUsuario.lng) {
      const userMarker = L.marker([posicaoUsuario.lat, posicaoUsuario.lng], {
        icon: userIcon,
        zIndexOffset: 2000,
      }).addTo(markersLayer);

      userMarker.bindPopup(`
        <div style="font-family: ui-sans-serif, system-ui, sans-serif; padding: 2px;">
          <strong style="color: #2563eb; font-size: 12px;">📍 Sua Localização / CEP</strong>
          <p style="margin: 2px 0 0 0; font-size: 11px; color: #475569;">${posicaoUsuario.endereco || "Sua posição pesquisada"}</p>
        </div>
      `);
    }

    // Renderiza os pontos de coleta
    locais.forEach((local, index) => {
      const lat = (!isNaN(Number(local.latitude)) && local.latitude !== 0)
        ? Number(local.latitude)
        : -23.666692 + (index * 0.005) * (index % 2 === 0 ? 1 : -1);

      const lng = (!isNaN(Number(local.longitude)) && local.longitude !== 0)
        ? Number(local.longitude)
        : -46.546662 + (index * 0.005) * (index % 3 === 0 ? 1 : -1);

      const isSelected = localSelecionado?.id === local.id;
      const marker = L.marker([lat, lng], { 
        icon: isSelected ? selectedIcon : defaultIcon,
        zIndexOffset: isSelected ? 1000 : 0
      }).addTo(markersLayer);

      coordsParaBounds.push([lat, lng]);

      const popupHtml = `
        <div style="min-width: 170px; font-family: ui-sans-serif, system-ui, sans-serif; padding: 2px;">
          <span style="background: #e6f4ea; color: #137333; font-size: 10px; font-weight: 700; padding: 2px 8px; border-radius: 12px; text-transform: uppercase;">
            ${local.categoria || 'Reciclagem'}
          </span>
          <h4 style="margin: 6px 0 2px 0; font-size: 13px; font-weight: 700; color: #1e293b;">
            ${local.nome}
          </h4>
          <p style="margin: 0; font-size: 11px; color: #64748b; line-height: 1.3;">
            ${local.endereco}
          </p>
        </div>
      `;

      marker.bindPopup(popupHtml, { closeButton: false, offset: [0, -4] });

      marker.on("click", () => {
        onSelect(local);
      });

      if (isSelected) {
        marker.openPopup();
      }
    });

    // MOVIMENTAÇÃO DO MAPA (Prioridades: 1. Local Clicado | 2. CEP Pesquisado | 3. Limites dos Pontos)
    if (localSelecionado && localSelecionado.latitude && localSelecionado.longitude) {
      map.flyTo([Number(localSelecionado.latitude), Number(localSelecionado.longitude)], 16, {
        duration: 1.2
      });
    } else if (posicaoUsuario && posicaoUsuario.lat && posicaoUsuario.lng) {
      map.flyTo([posicaoUsuario.lat, posicaoUsuario.lng], 15, {
        duration: 1.3
      });
    } else if (coordsParaBounds.length > 0) {
      const bounds = L.latLngBounds(coordsParaBounds);
      map.fitBounds(bounds, { padding: [40, 40], maxZoom: 15 });
    }

  }, [locais, localSelecionado, posicaoUsuario, onSelect]);

  return (
    <div
      ref={mapRef}
      className="w-full h-[360px] sm:h-[450px] lg:h-[530px] rounded-xl overflow-hidden z-0 shadow-inner"
    />
  );
}