
"use client";

import { useState } from "react";
import Image from "next/image";
import { ChevronDown } from "lucide-react";

interface AccordionItemProps {
  sigla: string;
  titulo: string;
  resumo?: string;
  corTexto?: string;
  oQueE?: string;
  usos: string;
  comoSeparar: string;
  imagem?: string;
}

export function AccordionItem({
  sigla,
  titulo,
  resumo,
  corTexto = "text-[#b03f3f]",
  oQueE,
  usos,
  comoSeparar,
  imagem,
}: AccordionItemProps) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="bg-[#F8F9FA] border border-gray-100 rounded-2xl overflow-hidden transition-colors duration-300">
      {/* Botão do Cabeçalho */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full p-5 md:p-6 flex items-center justify-between text-left hover:bg-gray-100/70 transition-colors outline-none cursor-pointer"
      >
        <div className="flex items-center gap-4">
          <div className="w-14 h-12 bg-white rounded-xl shadow-xs flex items-center justify-center shrink-0 border border-gray-200">
            <span className={`font-extrabold text-sm ${corTexto}`}>{sigla}</span>
          </div>
          <div>
            <h3 className="font-bold text-gray-900 text-base">{titulo}</h3>
            {resumo && (
              <p
                className={`text-gray-500 text-xs mt-0.5 line-clamp-1 max-w-md transition-opacity duration-300 ${
                  isOpen ? "opacity-0 h-0 overflow-hidden" : "opacity-100"
                }`}
              >
                {resumo}
              </p>
            )}
          </div>
        </div>

        <div
          className={`p-2 rounded-full bg-white transition-transform duration-300 ease-in-out ${
            isOpen ? "rotate-180 bg-gray-200" : ""
          }`}
        >
          <ChevronDown className="w-5 h-5 text-gray-600" />
        </div>
      </button>

      {/* Conteúdo Expandido com Animação Fluida (CSS Grid) */}
      <div
        className={`grid transition-all duration-500 ease-in-out ${
          isOpen
            ? "grid-rows-[1fr] opacity-100 border-t border-gray-200/60"
            : "grid-rows-[0fr] opacity-0"
        }`}
      >
        <div className="overflow-hidden">
          <div className="px-5 pb-6 md:px-6 md:pb-6 pt-4 grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
            {/* Lado Esquerdo: Textos */}
            <div className="md:col-span-2 space-y-4">
              {oQueE && (
                <div>
                  <h4 className="text-xs font-extrabold tracking-wider text-gray-400 uppercase mb-1">
                    O que é
                  </h4>
                  <p className="text-gray-700 text-sm leading-relaxed">
                    {oQueE}
                  </p>
                </div>
              )}

              <div>
                <h4 className="text-xs font-extrabold tracking-wider text-gray-400 uppercase mb-1">
                  Usos comuns
                </h4>
                <p className="text-gray-700 text-sm leading-relaxed">{usos}</p>
              </div>

              <div>
                <h4
                  className={`text-xs font-extrabold tracking-wider uppercase mb-1 ${corTexto}`}
                >
                  Como Separar
                </h4>
                <p className="text-gray-700 text-sm leading-relaxed bg-white p-3 rounded-xl border border-gray-200/80">
                  {comoSeparar}
                </p>
              </div>
            </div>

            {/* Lado Direito: Imagem */}
            <div className="flex flex-col items-center justify-center bg-white p-4 rounded-2xl border border-gray-200/80 h-full min-h-[160px]">
              <div className="relative w-full h-32 md:h-36">
                {imagem && (
                  <Image
                    src={imagem}
                    alt={`Ilustração ${sigla}`}
                    fill
                    className="object-contain rounded-lg"
                    onError={(e) => {
                      e.currentTarget.style.display = "none";
                    }}
                  />
                )}
                <div className="absolute inset-0 flex flex-col items-center justify-center bg-gray-50 rounded-xl text-gray-400 text-xs font-medium text-center p-2 border border-dashed border-gray-300 -z-10">
                  <span>Imagem ilustrativa</span>
                  <span className="font-bold text-gray-600 mt-1">{sigla}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}