"use client";

import { useState, useEffect } from "react";
import { ChevronDown } from "lucide-react";

interface BlogCardProps {
  codigo: string;
  icone: any;
  titulo: string;
  descricao: string;
  conteudo: string[];
  dicas: string[];
  cor: string;
  defaultOpen?: boolean;
}

export function BlogCard({
  codigo,
  icone: Icone,
  titulo,
  descricao,
  conteudo,
  dicas,
  cor,
  defaultOpen = false,
}: BlogCardProps) {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  useEffect(() => {
    if (defaultOpen) {
      setIsOpen(true);
    }
  }, [defaultOpen]);

  return (
    <div
      className="w-full bg-white rounded-3xl p-6 shadow-sm border border-slate-100 transition-all duration-300 cursor-pointer overflow-hidden mb-4"
      style={{ borderLeftColor: cor, borderLeftWidth: "6px" }}
      onClick={() => setIsOpen(!isOpen)}
    >
      {/* Cabeçalho do Card */}
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-start gap-4">
          <div
            className="w-12 h-12 rounded-2xl flex items-center justify-center shrink-0"
            style={{ backgroundColor: `${cor}15`, color: cor }}
          >
            {Icone && <Icone size={24} />}
          </div>

          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span
                className="text-xs font-extrabold px-2 py-0.5 rounded-md"
                style={{ backgroundColor: `${cor}20`, color: cor }}
              >
                {codigo}
              </span>
              <h3 className="font-bold text-slate-900 text-base md:text-lg">
                {titulo}
              </h3>
            </div>
            <p className="text-slate-500 text-xs md:text-sm font-medium">
              {descricao}
            </p>
          </div>
        </div>

        {/* Botão da Setinha com Rotação Suave */}
        <button
          type="button"
          className="p-2 rounded-full bg-slate-50 hover:bg-slate-100 text-slate-500 transition-colors shrink-0"
          aria-label="Expandir card"
        >
          <ChevronDown
            size={20}
            className={`transition-transform duration-300 ease-in-out ${
              isOpen ? "rotate-180" : "rotate-0"
            }`}
          />
        </button>
      </div>

      {/* Animação de Expansão Suave com CSS Grid */}
      <div
        className={`grid transition-all duration-300 ease-in-out ${
          isOpen
            ? "grid-rows-[1fr] opacity-100 mt-6 pt-6 border-t border-slate-100"
            : "grid-rows-[0fr] opacity-0 mt-0 pt-0 border-t-0"
        }`}
      >
        <div
          className="overflow-hidden space-y-4 text-slate-700 text-sm leading-relaxed"
          onClick={(e) => e.stopPropagation()}
        >
          {conteudo.map((paragrafo, idx) => (
            <p key={idx}>{paragrafo}</p>
          ))}

          {dicas && dicas.length > 0 && (
            <div className="bg-slate-50 p-4 rounded-2xl space-y-2 mt-4">
              <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wider">
                Dicas Práticas:
              </h4>
              <ul className="list-disc list-inside space-y-1 text-slate-600 text-xs md:text-sm">
                {dicas.map((dica, idx) => (
                  <li key={idx}>{dica}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}