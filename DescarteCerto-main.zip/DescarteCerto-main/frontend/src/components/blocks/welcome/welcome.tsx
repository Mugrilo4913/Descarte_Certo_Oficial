// src/components/blocks/welcome/WelcomeModal.tsx
"use client";

import { useState, useEffect } from "react";
import { Sparkles, ShieldCheck, CheckCircle2, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

export function Welcome() {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    // Exibe apenas se o usuário ainda não tiver visto
    const jaVisualizado = localStorage.getItem("@descarte_certo:boas_vindas");
    if (!jaVisualizado) {
      setOpen(true);
    }
  }, []);

  const fecharModal = () => {
    localStorage.setItem("@descarte_certo:boas_vindas", "true");
    setOpen(false);
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-300">
      <div className="bg-white w-full max-w-md rounded-[32px] p-6 sm:p-8 shadow-2xl border border-gray-100 flex flex-col items-center text-center">
        
        {/* Ícone de Destaque */}
        <div className="w-16 h-16 bg-[#D9F0A3]/50 rounded-full flex items-center justify-center text-[#2b3a16] mb-5">
          <Sparkles size={32} />
        </div>

        <h2 className="text-2xl font-black text-gray-900 tracking-tight mb-2">
          Bem-vindo ao DescarteCerto! 🌿
        </h2>

        <p className="text-gray-600 text-sm leading-relaxed mb-6">
          Sua plataforma de apoio ao descarte consciente de resíduos, localização de pontos de coleta e guias práticos de reciclagem.
        </p>

        {/* Caixinha explicativa sobre o login */}
        <div className="bg-gray-50 border border-gray-100 rounded-2xl p-4 text-left space-y-3 mb-6 w-full">
          <div className="flex items-start gap-3">
            <ShieldCheck className="text-[#98C270] shrink-0 mt-0.5" size={20} />
            <div>
              <h4 className="text-xs font-bold text-gray-900 uppercase tracking-wide">
                Login Opcional e Sem Coleta de Dados
              </h4>
              <p className="text-xs text-gray-500 mt-1 leading-relaxed">
                Você pode utilizar todo o conteúdo livremente. O login serve unicamente para salvar suas preferências e acessar as <strong>Configurações</strong> personalizadas. Não solicitamos dados sensíveis como e-mail ou telefone.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs font-medium text-gray-700 pt-1 border-t border-gray-200/60">
            <CheckCircle2 size={16} className="text-[#98C270]" />
            Navegue por categorias, mapa e IA sem restrições.
          </div>
        </div>

        <Button
          onClick={fecharModal}
          className="w-full bg-[#98C270] hover:bg-[#85b15d] text-white font-bold h-12 rounded-xl flex items-center justify-center gap-2 shadow-md shadow-[#98C270]/20 transition-all hover:translate-y-[-1px]"
        >
          Começar a Explorar <ArrowRight size={18} />
        </Button>
      </div>
    </div>
  );
}