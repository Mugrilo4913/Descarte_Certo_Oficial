import { Bookmark, ChevronDown, MapPinOff, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function ListaLocais({ 
  locais = [], 
  localSelecionado, 
  onSelect 
}: { 
  locais: any[]; 
  localSelecionado: any | null; 
  onSelect: (local: any) => void;
}) {
  
  if (!locais || locais.length === 0) {
    return (
      <section className="bg-white p-6 rounded-[2.5rem] shadow-sm border border-slate-200/60 flex flex-col items-center justify-center text-center min-h-[300px]">
        <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mb-4">
          <MapPinOff size={28} className="text-slate-400" />
        </div>
        <h2 className="font-bold text-slate-900 text-lg">Nenhum ponto de coleta encontrado</h2>
        <p className="text-slate-500 text-sm mt-1 max-w-xs">
          Não conseguimos encontrar locais na sua região com os filtros atuais.
        </p>
      </section>
    );
  }

  return (
    <section className="bg-white p-6 rounded-[2.5rem] shadow-sm border border-slate-200/60">
      <h2 className="font-semibold text-slate-900 mb-5 text-lg">{locais.length} locais encontrados</h2>
      
      <div className="flex flex-col gap-2 max-h-[600px] overflow-y-auto pr-2 custom-scrollbar">
        {locais.map((local) => {
          const Icone = local.icone || MapPin;

          return (
            <div 
              key={local.id}
              onClick={() => onSelect(local)}
              className={`group flex flex-col sm:flex-row sm:items-center justify-between p-4 rounded-2xl cursor-pointer transition-all duration-200
                ${localSelecionado?.id === local.id 
                  ? 'bg-emerald-50/50 ring-1 ring-emerald-500/50' 
                  : 'hover:bg-slate-50 border border-transparent hover:border-slate-100'}`}
            >
              <div className="flex items-center gap-4 mb-3 sm:mb-0 w-full sm:w-2/3">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center shrink-0 ${local.bgIcone || 'bg-slate-100'} ${local.corIcone || 'text-slate-500'}`}>
                  <Icone size={22} strokeWidth={2.5} />
                </div>
                
                <div className="flex flex-col gap-1 w-full">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="font-semibold text-slate-900 group-hover:text-emerald-700 transition-colors line-clamp-1">
                      {local.nome}
                    </h3>
                    <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full ${local.bgIcone || 'bg-slate-100'} ${local.corIcone || 'text-slate-500'} bg-opacity-50`}>
                      {local.categoria || 'Geral'}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 line-clamp-1">{local.endereco}</p>
                </div>
              </div>

              <div className="flex items-center justify-between sm:justify-end gap-6 sm:w-auto w-full pl-16 sm:pl-0 shrink-0">
                <span className={`text-xs font-medium ${local.statusCor || 'text-slate-500'}`}>
                  {local.status || 'Consultar'}
                </span>
                <button 
                  className="text-slate-300 hover:text-emerald-600 transition-colors p-2 -mr-2"
                  onClick={(e) => e.stopPropagation()}
                >
                  <Bookmark size={20} />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}