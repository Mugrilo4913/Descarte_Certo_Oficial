"use client";

import { useState, useEffect } from "react";
import Image from "next/image";
import { X, MapPin, Copy, ArrowRight, Bookmark, PersonStanding, ChevronDown, ImageOff } from "lucide-react";
import { Button } from "@/components/ui/button";

// Imagem padrão caso o banco venha sem foto ou a foto quebre
const IMAGEM_PADRAO = "https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?auto=format&fit=crop&w=800&q=80";

export default function SidebarLocal({ local, onClose }: { local: any; onClose: () => void }) {
  // 1. Declarar todos os Hooks SEMPRE no topo do componente
  const [imgSrc, setImgSrc] = useState<string>(local?.imagem || IMAGEM_PADRAO);
  const [imgError, setImgError] = useState(false);

  // 2. Atualiza a imagem sempre que um novo local for selecionado
  useEffect(() => {
    if (local) {
      setImgSrc(local.imagem || IMAGEM_PADRAO);
      setImgError(false);
    }
  }, [local]);

  // 3. O retorno condicional deve vir DEPOIS de todas as chamadas de Hooks
  if (!local) return null;

  const Icone = local.icone;

  return (
    <aside className="w-full xl:w-[420px] bg-white rounded-[2.5rem] shadow-xl shadow-slate-200/50 border border-slate-200/60 flex flex-col overflow-hidden shrink-0 animate-in slide-in-from-right-8 duration-300 sticky top-8 z-20 h-[calc(100vh-4rem)]">
      
      {/* Imagem de Capa com Proteção contra Falhas */}
      <div className="relative h-56 w-full bg-slate-100 shrink-0 overflow-hidden">
        {imgError ? (
          <div className="w-full h-full flex flex-col items-center justify-center bg-slate-100 text-slate-400 gap-2">
            <ImageOff size={28} />
            <span className="text-xs font-medium">Sem imagem disponível</span>
          </div>
        ) : (
          <Image 
            src={imgSrc} 
            alt={local.nome || "Ponto de coleta"}
            fill
            sizes="(max-width: 1280px) 100vw, 420px"
            unoptimized // Permite carregar de qualquer domínio/banco sem dar erro de configuração
            onError={() => {
              if (imgSrc !== IMAGEM_PADRAO) {
                setImgSrc(IMAGEM_PADRAO);
              } else {
                setImgError(true);
              }
            }}
            className="object-cover transition-opacity duration-300"
          />
        )}

        <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent pointer-events-none" />
        
        <button 
          onClick={onClose}
          type="button"
          aria-label="Fechar detalhes"
          className="absolute top-5 right-5 bg-white/90 backdrop-blur-sm p-2.5 rounded-full hover:bg-white hover:scale-105 transition-all shadow-sm z-30"
        >
          <X size={18} className="text-slate-700" strokeWidth={2.5} />
        </button>

        <div className="absolute -bottom-8 left-6 z-20">
          <div className="bg-white p-1.5 rounded-[1.2rem] shadow-sm">
            <div className={`w-14 h-14 rounded-xl flex items-center justify-center ${local.bgIcone || 'bg-slate-100'} ${local.corIcone || 'text-slate-700'}`}>
              {Icone ? <Icone size={28} strokeWidth={2} /> : <MapPin size={28} />}
            </div>
          </div>
        </div>
      </div>

      <div className="p-6 md:p-8 pt-10 md:pt-12 flex flex-col gap-7 overflow-y-auto scrollbar-hide pb-10">
        
        <div>
          <h2 className="font-bold text-2xl text-slate-900 mb-2">{local.nome}</h2>
          <span className={`inline-block text-xs font-bold px-3 py-1 rounded-full ${local.bgIcone || 'bg-slate-100'} ${local.corIcone || 'text-slate-700'}`}>
            {local.categoria}
          </span>
        </div>

        {/* Endereço e Distância */}
        <div className="flex justify-between items-start border-b border-slate-100 pb-5 gap-3">
          <p className="text-sm text-slate-500 max-w-[75%] leading-relaxed">
            {local.endereco}
          </p>
          {local.distancia && (
            <div className="flex items-center gap-1 text-slate-700 font-bold bg-slate-50 px-3 py-1.5 rounded-xl shrink-0">
              {local.distancia}
              <PersonStanding size={18} className="text-emerald-600" />
            </div>
          )}
        </div>

        {/* Status e Horário */}
        <div className="bg-slate-50/80 p-4 rounded-2xl space-y-3 border border-slate-100">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className={`w-2.5 h-2.5 rounded-full ${local.status === "Aberto agora" || local.status === "Aberto para descarte" ? 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.4)]' : 'bg-orange-500'}`}></div>
              <span className={`text-sm font-semibold ${local.statusCor || 'text-slate-700'}`}>{local.status}</span>
            </div>
            <ChevronDown size={18} className="text-slate-400" />
          </div>
          {local.horario && (
            <p className="text-xs text-slate-500 whitespace-pre-line pl-5 leading-relaxed font-medium">
              {local.horario}
            </p>
          )}
        </div>

        {/* Resíduos aceitos */}
        {local.aceita && local.aceita.length > 0 && (
          <div>
            <h3 className="font-semibold text-sm text-slate-900 mb-3">Aceita este tipo de resíduo</h3>
            <div className="flex flex-wrap gap-2">
              {local.aceita.map((item: string, i: number) => (
                <span key={i} className="bg-indigo-50/80 border border-indigo-100/50 text-indigo-700 text-xs px-3.5 py-1.5 rounded-full font-semibold">
                  {item}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Sobre */}
        <div>
          <h3 className="font-semibold text-sm text-slate-900 mb-2">Sobre o local</h3>
          <p className="text-sm text-slate-500 leading-relaxed">
            {local.descricao}
          </p>
        </div>

        {/* Como Chegar */}
        <div>
          <h3 className="font-semibold text-sm text-slate-900 mb-3">Como chegar</h3>
          <div className="space-y-2.5">
            {local.latitude && local.longitude && (
              <a
                href={`https://www.google.com/maps/dir/?api=1&destination=${local.latitude},${local.longitude}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full flex items-center gap-3 p-3.5 rounded-2xl border border-slate-200 hover:border-emerald-200 hover:bg-emerald-50/30 transition-all text-sm font-medium text-slate-700 group"
              >
                <MapPin size={18} className="text-slate-400 group-hover:text-emerald-500 transition-colors" />
                Ver rota no Google Maps
              </a>
            )}
            <button 
              type="button"
              onClick={() => {
                if (local.endereco) navigator.clipboard.writeText(local.endereco);
              }}
              className="w-full flex items-center gap-3 p-3.5 rounded-2xl border border-slate-200 hover:border-emerald-200 hover:bg-emerald-50/30 transition-all text-sm font-medium text-slate-700 group"
            >
              <Copy size={18} className="text-slate-400 group-hover:text-emerald-500 transition-colors" />
              Copiar endereço
            </button>
          </div>
        </div>

        {/* Botões Finais */}
        <div className="space-y-3 pt-2 mt-auto">
          <Button className="w-full bg-[#f97316] hover:bg-[#ea580c] shadow-lg shadow-orange-500/20 text-white rounded-2xl h-14 flex justify-between px-6 text-base font-semibold transition-all hover:scale-[1.02]">
            Ver detalhes do local
            <ArrowRight size={20} />
          </Button>
          <Button variant="outline" className="w-full rounded-2xl h-14 flex gap-2 border-slate-200 hover:bg-slate-50 text-slate-700 font-medium">
            <Bookmark size={18} />
            Salvar nos favoritos
          </Button>
        </div>

      </div>
    </aside>
  );
}