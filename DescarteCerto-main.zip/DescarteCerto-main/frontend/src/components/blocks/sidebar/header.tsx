"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import {
  Home,
  Maximize,
  LayoutGrid,
  MapPin,
  Settings,
  HelpCircle,
  BookOpen,
  Menu,
  X
} from "lucide-react";
import { cn } from "@/lib/utils";
import Logo from "../../../../public/images/logo.png";
import { useAuth } from "@/context/AuthContext";

export default function Sidebar() {
  const pathname = usePathname();
  const [isOpen, setIsOpen] = useState(false);
  const { user } = useAuth();
  // Fecha a sidebar no celular quando a rota muda
  useEffect(() => {
    setIsOpen(false);
  }, [pathname]);

  return (
    <>
      {/* Botão de abrir menu no mobile */}
      <button
        onClick={() => setIsOpen(true)}
        className="md:hidden fixed top-4 left-4 z-40 p-2 bg-white rounded-lg shadow-md border border-gray-100 text-gray-700 hover:text-[#558023] focus:outline-none"
        aria-label="Abrir menu"
      >
        <Menu className="w-6 h-6" />
      </button>

      {/* Overlay escuro de fundo no mobile */}
      {isOpen && (
        <div
          className="md:hidden fixed inset-0 z-40 bg-black/50 backdrop-blur-sm transition-opacity"
          onClick={() => setIsOpen(false)}
        />
      )}

      {/* Menu Sidebar */}
      <aside
        className={cn(
          "fixed top-0 left-0 z-50 h-screen w-[260px] bg-white border-r border-gray-100 flex flex-col py-4 shadow-[4px_0_24px_rgba(0,0,0,0.02)] font-sans transition-transform duration-300 ease-in-out",
          isOpen ? "translate-x-0" : "-translate-x-full",
          "md:translate-x-0"
        )}
      >
        {/* Logo e Botão Fechar */}
        <div className="flex items-center justify-between px-5 mb-6">
          <div className="flex items-center gap-2">
            <div className="relative w-8 h-8">
              <Image
                src={Logo}
                alt="Logo"
                fill
                sizes="32px"
                className="object-contain"
              />
            </div>
            <span className="text-lg font-bold tracking-tight">
              <span className="text-gray-800">Descarte</span>
              <span className="text-[#649234]">Certo</span>
            </span>
          </div>

          <button
            onClick={() => setIsOpen(false)}
            className="md:hidden p-1 text-gray-400 hover:text-gray-700 rounded-md bg-gray-50 focus:outline-none"
            aria-label="Fechar menu"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Menu de Navegação */}
        <nav className="flex-1 overflow-y-auto px-3 flex flex-col justify-between no-scrollbar">
          <div className="flex flex-col space-y-1">
            <NavItem href="/" icon={Home} label="Início" isActive={pathname === "/"} />
            <NavItem href="/escanear" icon={Maximize} label="Escanear resíduo" isActive={pathname === "/escanear"} />
            <NavItem href="/mapa" icon={MapPin} label="Mapa de descarte" isActive={pathname === "/mapa"} />
            <NavItem href="/categorias" icon={LayoutGrid} label="Categorias" isActive={pathname === "/categorias"} />
            <NavItem href="/blogs" icon={BookOpen} label="Blogs" isActive={pathname === "/blogs"} />

            <hr className="my-4 mx-2 border-gray-100" />
            {user && (
                <NavItem href="/configuracoes" icon={Settings} label="Configurações" isActive={pathname === "/configuracoes"} />
            )}
            <NavItem href="/sobre" icon={HelpCircle} label="Sobre nós / Ajuda" isActive={pathname === "/sobre"} />
          </div>

          {/* Card Inferior */}
          <div className="mt-6 mb-2 mx-2 bg-[#F6F8F1] rounded-2xl p-4 flex flex-col items-center text-center border border-[#e8efe0]">
            <div className="bg-[#E4ECCC] w-12 h-12 rounded-full flex items-center justify-center mb-2">
              <span className="text-xl">🌱</span>
            </div>
            <h4 className="text-[#558023] font-bold text-sm mb-1 leading-tight">
              Pequenas atitudes,<br /> grandes mudanças.
            </h4>
            <p className="text-[11px] text-gray-500 leading-relaxed">
              Faça o descarte certo e contribua com um futuro melhor!
            </p>
          </div>
        </nav>
      </aside>
    </>
  );
}

interface NavItemProps {
  href: string;
  icon: React.ElementType;
  label: string;
  isActive?: boolean;
}

function NavItem({ href, icon: Icon, label, isActive }: NavItemProps) {
  return (
    <Link
      href={href}
      className={cn(
        "flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 group",
        isActive
          ? "bg-[#F3F6EC] text-[#558023] font-semibold"
          : "text-gray-600 hover:bg-gray-50 hover:text-gray-900 font-medium"
      )}
    >
      <Icon
        className={cn(
          "w-5 h-5 transition-colors",
          isActive ? "text-[#558023]" : "text-gray-400 group-hover:text-gray-600"
        )}
        strokeWidth={isActive ? 2.5 : 2}
      />
      <span className="text-sm">{label}</span>
    </Link>
  );
}