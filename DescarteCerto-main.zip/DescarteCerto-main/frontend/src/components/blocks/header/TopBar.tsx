// src/components/blocks/header/TopBar.tsx
"use client";

import { useState, useRef, useEffect } from "react";
import Link from "next/link";
import { useAuth } from "@/context/AuthContext";
import { 
  User, 
  LogIn, 
  LogOut, 
  Settings, 
  Lock, 
  Mail, 
  MapPin, 
  X, 
  Loader2 
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export function TopBar() {
  const { user, login, logout } = useAuth();
  const [modalOpen, setModalOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [abaAtiva, setAbaAtiva] = useState<"login" | "cadastro">("login");

  // Campos do formulário
  const [nome, setNome] = useState("");
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [cep, setCep] = useState("");

  // Estados de feedback
  const [carregando, setCarregando] = useState(false);
  const [erro, setErro] = useState("");
  const [sucessoMsg, setSucessoMsg] = useState("");

  const menuRef = useRef<HTMLDivElement>(null);

  // Fecha o menu dropdown ao clicar fora
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setMenuOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const limparCampos = () => {
    setNome("");
    setEmail("");
    setSenha("");
    setCep("");
    setErro("");
    setSucessoMsg("");
  };

  const handleOpenModal = (modo: "login" | "cadastro" = "login") => {
    limparCampos();
    setAbaAtiva(modo);
    setModalOpen(true);
  };

  // Submissão do Login
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErro("");
    setSucessoMsg("");

    if (!email.trim() || !senha.trim()) {
      setErro("Preencha o e-mail e a senha.");
      return;
    }

    setCarregando(true);
    try {
      const res = await login(email, senha);
      if (res.success) {
        setModalOpen(false);
        limparCampos();
      } else {
        setErro(res.message || "E-mail ou senha incorretos.");
      }
    } catch {
      setErro("Erro de conexão ao tentar entrar.");
    } finally {
      setCarregando(false);
    }
  };

  // Submissão do Cadastro
  const handleCadastroSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErro("");
    setSucessoMsg("");

    if (!nome.trim() || !email.trim() || !senha.trim()) {
      setErro("Preencha todos os campos obrigatórios (*).");
      return;
    }

    setCarregando(true);
    try {
      const response = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nome, email, senha, cep }),
      });

      const data = await response.json();

      if (response.ok && data.success) {
        // Faz o login automático após cadastrar
        const loginRes = await login(email, senha);
        if (loginRes.success) {
          setModalOpen(false);
          limparCampos();
        } else {
          setSucessoMsg("Conta criada com sucesso! Faça login com suas credenciais.");
          setAbaAtiva("login");
        }
      } else {
        setErro(data.message || "Erro ao criar conta.");
      }
    } catch {
      setErro("Erro de comunicação com o servidor.");
    } finally {
      setCarregando(false);
    }
  };

  return (
    <div className="absolute top-4 right-4 md:top-6 md:right-8 z-40">
      {user ? (
        /* Dropdown do Usuário Autenticado */
        <div className="relative" ref={menuRef}>
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className="flex items-center gap-2.5 bg-white/95 backdrop-blur-sm py-1.5 px-3 rounded-full border border-gray-200 shadow-xs hover:border-gray-300 transition-all focus:outline-none"
          >
            <div className="w-8 h-8 rounded-full bg-[#98C270] text-white font-bold flex items-center justify-center text-sm shadow-inner uppercase">
              {user.nome?.charAt(0) || "U"}
            </div>
            <span className="text-sm font-semibold text-gray-800 pr-1 max-w-[120px] truncate">
              {user.nome}
            </span>
          </button>

          {menuOpen && (
            <div className="absolute right-0 mt-2 w-52 bg-white border border-gray-100 rounded-2xl shadow-xl py-2 z-50 animate-in fade-in slide-in-from-top-2">
              <div className="px-4 py-2 border-b border-gray-100">
                <p className="text-xs text-gray-400 font-medium">Conectado como</p>
                <p className="text-sm font-bold text-gray-900 truncate">{user.nome}</p>
                <p className="text-xs text-gray-500 truncate">{user.email}</p>
              </div>

              <Link
                href="/configuracoes"
                onClick={() => setMenuOpen(false)}
                className="flex items-center gap-2.5 px-4 py-2.5 text-sm text-gray-700 hover:bg-gray-50 transition-colors"
              >
                <Settings size={16} className="text-gray-500" />
                Configurações
              </Link>

              <button
                onClick={() => {
                  setMenuOpen(false);
                  logout();
                }}
                className="w-full flex items-center gap-2.5 px-4 py-2.5 text-sm text-red-600 hover:bg-red-50 transition-colors text-left"
              >
                <LogOut size={16} />
                Sair
              </button>
            </div>
          )}
        </div>
      ) : (
        /* Botão Entrar para Visitantes */
        <Button
          onClick={() => handleOpenModal("login")}
          className="bg-white/90 backdrop-blur-sm hover:bg-white text-gray-800 border border-gray-200/90 rounded-full px-4 h-9 shadow-xs font-semibold text-xs sm:text-sm flex items-center gap-1.5 transition-all hover:scale-[1.02]"
        >
          <LogIn size={15} className="text-[#98C270]" />
          Entrar
        </Button>
      )}

      {/* Modal / Dialog de Autenticação (Login e Cadastro) */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white w-full max-w-sm rounded-[28px] p-6 shadow-2xl border border-gray-100 relative">
            
            {/* Botão Fechar */}
            <button
              onClick={() => setModalOpen(false)}
              className="absolute right-4 top-4 p-1.5 rounded-full text-gray-400 hover:text-gray-700 hover:bg-gray-100 transition-colors"
            >
              <X size={18} />
            </button>

            {/* Cabeçalho do Modal */}
            <div className="text-center space-y-1 mb-5">
              <div className="w-12 h-12 bg-[#98C270]/10 rounded-2xl flex items-center justify-center text-[#98C270] mx-auto mb-2">
                <User size={24} />
              </div>
              <h3 className="text-xl font-bold text-gray-900">
                {abaAtiva === "login" ? "Acessar Conta" : "Criar Nova Conta"}
              </h3>
              <p className="text-xs text-gray-500">
                {abaAtiva === "login" 
                  ? "Entre para gerenciar seus descartes e preferências." 
                  : "Cadastre-se para ter rotas e pontos de descarte salvos."}
              </p>
            </div>

            {/* Alternador de Abas (Entrar / Cadastrar) */}
            <div className="grid grid-cols-2 bg-gray-100 p-1 rounded-xl mb-4">
              <button
                type="button"
                onClick={() => {
                  setAbaAtiva("login");
                  setErro("");
                }}
                className={`py-1.5 text-xs font-bold rounded-lg transition-all ${
                  abaAtiva === "login"
                    ? "bg-white text-gray-900 shadow-xs"
                    : "text-gray-500 hover:text-gray-700"
                }`}
              >
                Entrar
              </button>
              <button
                type="button"
                onClick={() => {
                  setAbaAtiva("cadastro");
                  setErro("");
                }}
                className={`py-1.5 text-xs font-bold rounded-lg transition-all ${
                  abaAtiva === "cadastro"
                    ? "bg-white text-gray-900 shadow-xs"
                    : "text-gray-500 hover:text-gray-700"
                }`}
              >
                Cadastre-se
              </button>
            </div>

            {/* Alertas de Erro ou Sucesso */}
            {erro && (
              <div className="mb-4 text-xs font-semibold text-red-600 bg-red-50 p-2.5 rounded-xl border border-red-100 text-center">
                {erro}
              </div>
            )}
            {sucessoMsg && (
              <div className="mb-4 text-xs font-semibold text-emerald-700 bg-emerald-50 p-2.5 rounded-xl border border-emerald-100 text-center">
                {sucessoMsg}
              </div>
            )}

            {/* Formulário: LOGIN */}
            {abaAtiva === "login" && (
              <form onSubmit={handleLoginSubmit} className="space-y-3.5">
                <div className="space-y-1">
                  <Label htmlFor="login-email" className="text-xs font-bold text-gray-700 flex items-center gap-1">
                    <Mail size={13} className="text-gray-400" /> E-mail
                  </Label>
                  <Input
                    id="login-email"
                    type="email"
                    placeholder="exemplo@email.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="rounded-xl h-10 bg-gray-50 border-gray-200 focus:bg-white text-sm"
                    autoFocus
                  />
                </div>

                <div className="space-y-1">
                  <Label htmlFor="login-senha" className="text-xs font-bold text-gray-700 flex items-center gap-1">
                    <Lock size={13} className="text-gray-400" /> Senha
                  </Label>
                  <Input
                    id="login-senha"
                    type="password"
                    placeholder="••••••••"
                    value={senha}
                    onChange={(e) => setSenha(e.target.value)}
                    className="rounded-xl h-10 bg-gray-50 border-gray-200 focus:bg-white text-sm"
                  />
                </div>

                <div className="pt-2 flex flex-col gap-2">
                  <Button
                    type="submit"
                    disabled={carregando}
                    className="w-full h-11 bg-[#98C270] hover:bg-[#85b15d] text-white font-bold rounded-xl transition-all shadow-md shadow-[#98C270]/20 flex items-center justify-center gap-2"
                  >
                    {carregando ? (
                      <>
                        <Loader2 size={16} className="animate-spin" />
                        Acessando...
                      </>
                    ) : (
                      "Entrar"
                    )}
                  </Button>
                  <Button
                    type="button"
                    variant="ghost"
                    onClick={() => setModalOpen(false)}
                    className="w-full h-9 text-gray-500 hover:text-gray-800 rounded-xl text-xs"
                  >
                    Continuar navegando sem login
                  </Button>
                </div>
              </form>
            )}

            {/* Formulário: CADASTRO */}
            {abaAtiva === "cadastro" && (
              <form onSubmit={handleCadastroSubmit} className="space-y-3">
                <div className="space-y-1">
                  <Label htmlFor="cad-nome" className="text-xs font-bold text-gray-700">
                    Nome Completo *
                  </Label>
                  <Input
                    id="cad-nome"
                    type="text"
                    placeholder="Gabriel Silva"
                    value={nome}
                    onChange={(e) => setNome(e.target.value)}
                    className="rounded-xl h-10 bg-gray-50 border-gray-200 focus:bg-white text-sm"
                    autoFocus
                  />
                </div>

                <div className="space-y-1">
                  <Label htmlFor="cad-email" className="text-xs font-bold text-gray-700 flex items-center gap-1">
                    <Mail size={13} className="text-gray-400" /> E-mail *
                  </Label>
                  <Input
                    id="cad-email"
                    type="email"
                    placeholder="exemplo@email.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="rounded-xl h-10 bg-gray-50 border-gray-200 focus:bg-white text-sm"
                  />
                </div>

                <div className="space-y-1">
                  <Label htmlFor="cad-senha" className="text-xs font-bold text-gray-700 flex items-center gap-1">
                    <Lock size={13} className="text-gray-400" /> Senha *
                  </Label>
                  <Input
                    id="cad-senha"
                    type="password"
                    placeholder="Mínimo 6 caracteres"
                    value={senha}
                    onChange={(e) => setSenha(e.target.value)}
                    className="rounded-xl h-10 bg-gray-50 border-gray-200 focus:bg-white text-sm"
                  />
                </div>

                <div className="space-y-1">
                  <Label htmlFor="cad-cep" className="text-xs font-bold text-gray-700 flex items-center gap-1">
                    <MapPin size={13} className="text-gray-400" /> CEP (Opcional)
                  </Label>
                  <Input
                    id="cad-cep"
                    type="text"
                    placeholder="00000-000"
                    maxLength={9}
                    value={cep}
                    onChange={(e) => setCep(e.target.value)}
                    className="rounded-xl h-10 bg-gray-50 border-gray-200 focus:bg-white text-sm"
                  />
                </div>

                <div className="pt-2 flex flex-col gap-2">
                  <Button
                    type="submit"
                    disabled={carregando}
                    className="w-full h-11 bg-[#98C270] hover:bg-[#85b15d] text-white font-bold rounded-xl transition-all shadow-md shadow-[#98C270]/20 flex items-center justify-center gap-2"
                  >
                    {carregando ? (
                      <>
                        <Loader2 size={16} className="animate-spin" />
                        Criando conta...
                      </>
                    ) : (
                      "Cadastrar e Entrar"
                    )}
                  </Button>
                </div>
              </form>
            )}

          </div>
        </div>
      )}
    </div>
  );
}